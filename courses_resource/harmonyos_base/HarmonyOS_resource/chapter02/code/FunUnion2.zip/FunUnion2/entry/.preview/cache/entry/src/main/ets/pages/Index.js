"use strict";
const TAG = "----->";
function __Span__mySpanStyle() {
    Span.fontColor({ "id": 16777225, "type": 10001, params: [], "bundleName": "com.snkey.sl1", "moduleName": "entry" });
    Span.decoration({
        type: TextDecorationType.Underline,
        color: { "id": 16777225, "type": 10001, params: [], "bundleName": "com.snkey.sl1", "moduleName": "entry" }
    });
}
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.usernmae = "";
        this.password = "";
        this.isSelected = false;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.usernmae !== undefined) {
            this.usernmae = params.usernmae;
        }
        if (params.password !== undefined) {
            this.password = params.password;
        }
        if (params.isSelected !== undefined) {
            this.isSelected = params.isSelected;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    myInputArea(parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Index.ets(34:5)");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create({
                placeholder: "请输入用户名"
            });
            TextInput.debugLine("pages/Index.ets(35:7)");
            TextInput.type(InputType.Normal);
            TextInput.width("90%");
            TextInput.height(50);
            TextInput.onChange((value) => {
                // console.info(TAG, "用户名=" + value)
                this.usernmae = value;
            });
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create({
                placeholder: "请输入密码"
            });
            TextInput.debugLine("pages/Index.ets(45:7)");
            TextInput.type(InputType.Password);
            TextInput.width("90%");
            TextInput.height(50);
            TextInput.margin({
                top: 15
            });
            TextInput.onChange((value) => {
                // console.info(TAG, "密码=" + value)
                this.password = value;
            });
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Column.pop();
    }
    myCheckbox(parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Index.ets(61:5)");
            Row.width("100%");
            Row.justifyContent(FlexAlign.Center);
            Row.margin({
                top: 10,
                bottom: 10
            });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Checkbox.create();
            Checkbox.debugLine("pages/Index.ets(62:7)");
            Checkbox.selectedColor({ "id": 16777225, "type": 10001, params: [], "bundleName": "com.snkey.sl1", "moduleName": "entry" });
            Checkbox.onChange((value) => {
                // console.info(TAG, "勾选协议=" + value)
                this.isSelected = value;
            });
            if (!isInitialRender) {
                Checkbox.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Checkbox.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create();
            Text.debugLine("pages/Index.ets(68:7)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Span.create("请勾选");
            Span.debugLine("pages/Index.ets(69:9)");
            if (!isInitialRender) {
                Span.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Span.create("用户协议");
            Span.debugLine("pages/Index.ets(70:9)");
            __Span__mySpanStyle();
            Span.onClick(() => {
                console.info(TAG, "点击了用户协议");
            });
            if (!isInitialRender) {
                Span.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Span.create("和");
            Span.debugLine("pages/Index.ets(75:9)");
            if (!isInitialRender) {
                Span.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Span.create("隐私政策");
            Span.debugLine("pages/Index.ets(76:9)");
            __Span__mySpanStyle();
            Span.onClick(() => {
                console.info(TAG, "点击了隐私政策");
            });
            if (!isInitialRender) {
                Span.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Index.ets(91:5)");
            Column.width("100%");
            Column.height("100%");
            Column.justifyContent(FlexAlign.Start);
            Column.alignItems(HorizontalAlign.Center);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //图片
            Image.create({ "id": 16777222, "type": 20000, params: [], "bundleName": "com.snkey.sl1", "moduleName": "entry" });
            Image.debugLine("pages/Index.ets(93:7)");
            //图片
            Image.width(150);
            //图片
            Image.height(150);
            //图片
            Image.margin({
                top: 100,
                bottom: 20
            });
            if (!isInitialRender) {
                //图片
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        //输入区域
        this.myInputArea.bind(this)();
        //checkbox
        this.myCheckbox.bind(this)();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //登录按钮
            Button.createWithLabel("登录");
            Button.debugLine("pages/Index.ets(101:7)");
            //登录按钮
            Button.width("90%");
            //登录按钮
            Button.height(50);
            //登录按钮
            Button.backgroundColor({ "id": 16777225, "type": 10001, params: [], "bundleName": "com.snkey.sl1", "moduleName": "entry" });
            //登录按钮
            Button.fontSize(22);
            //登录按钮
            Button.onClick(() => {
                console.info(TAG, "用户名=" + this.usernmae);
                console.info(TAG, "密码=" + this.password);
                console.info(TAG, "勾选协议=" + this.isSelected);
            });
            if (!isInitialRender) {
                //登录按钮
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        //登录按钮
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Blank.create();
            Blank.debugLine("pages/Index.ets(111:7)");
            if (!isInitialRender) {
                Blank.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Blank.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("蒙友 V1.0");
            Text.debugLine("pages/Index.ets(112:7)");
            Text.margin({
                bottom: 10
            });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new Index(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=Index.js.map