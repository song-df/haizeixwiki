const TAG = "----->[RegisterPage]";
import { CommonHeader } from '@bundle:com.snkey.sl1/entry/ets/common/components/CommonHeader';
import vm from '@bundle:com.snkey.sl1/entry/ets/ViewModel/MainVideModel';
class MyText extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.content = "内容";
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.content !== undefined) {
            this.content = params.content;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create();
            Text.debugLine("pages/RegisterPage.ets(13:5)");
            Text.width("25%");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Span.create(this.content);
            Span.debugLine("pages/RegisterPage.ets(14:7)");
            if (!isInitialRender) {
                Span.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Span.create("*");
            Span.debugLine("pages/RegisterPage.ets(15:7)");
            Span.fontColor(Color.Red);
            if (!isInitialRender) {
                Span.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class RegisterPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.username = "";
        this.password = "";
        this.password2 = "";
        this.age = 0;
        this.sex = 0 //0-男，1-女
        ;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.username !== undefined) {
            this.username = params.username;
        }
        if (params.password !== undefined) {
            this.password = params.password;
        }
        if (params.password2 !== undefined) {
            this.password2 = params.password2;
        }
        if (params.age !== undefined) {
            this.age = params.age;
        }
        if (params.sex !== undefined) {
            this.sex = params.sex;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 10 });
            Column.debugLine("pages/RegisterPage.ets(34:5)");
            Column.width("100%");
            Column.height("100%");
            Column.justifyContent(FlexAlign.Start);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new CommonHeader(this, { title: "注册账号" }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //输入用户名
            Row.create();
            Row.debugLine("pages/RegisterPage.ets(38:7)");
            //输入用户名
            Row.width("100%");
            //输入用户名
            Row.height(50);
            //输入用户名
            Row.justifyContent(FlexAlign.Start);
            //输入用户名
            Row.padding({
                left: 10,
                right: 10
            });
            if (!isInitialRender) {
                //输入用户名
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new MyText(this, { content: "用户名" }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create({
                placeholder: "请输入用户名"
            });
            TextInput.debugLine("pages/RegisterPage.ets(40:9)");
            TextInput.height(50);
            TextInput.width("75%");
            TextInput.onChange((value) => {
                this.username = value;
            });
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        //输入用户名
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //输入密码
            Row.create();
            Row.debugLine("pages/RegisterPage.ets(56:7)");
            //输入密码
            Row.width("100%");
            //输入密码
            Row.height(50);
            //输入密码
            Row.justifyContent(FlexAlign.Start);
            //输入密码
            Row.padding({
                left: 10,
                right: 10
            });
            if (!isInitialRender) {
                //输入密码
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new MyText(this, { content: "密码" }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create({
                placeholder: "请输入密码"
            });
            TextInput.debugLine("pages/RegisterPage.ets(58:9)");
            TextInput.height(50);
            TextInput.width("75%");
            TextInput.type(InputType.Password);
            TextInput.onChange((value) => {
                this.password = value;
            });
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        //输入密码
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //确认密码
            Row.create();
            Row.debugLine("pages/RegisterPage.ets(75:7)");
            //确认密码
            Row.width("100%");
            //确认密码
            Row.height(50);
            //确认密码
            Row.justifyContent(FlexAlign.Start);
            //确认密码
            Row.padding({
                left: 10,
                right: 10
            });
            if (!isInitialRender) {
                //确认密码
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new MyText(this, { content: "确认密码" }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create({
                placeholder: "请再次输入密码"
            });
            TextInput.debugLine("pages/RegisterPage.ets(77:9)");
            TextInput.height(50);
            TextInput.width("75%");
            TextInput.type(InputType.Password);
            TextInput.onChange((value) => {
                this.password2 = value;
            });
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        //确认密码
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //年龄
            Row.create();
            Row.debugLine("pages/RegisterPage.ets(94:7)");
            //年龄
            Row.width("100%");
            //年龄
            Row.justifyContent(FlexAlign.Start);
            //年龄
            Row.padding({
                left: 10,
                right: 10
            });
            if (!isInitialRender) {
                //年龄
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new MyText(this, { content: "年龄" }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Select.create(vm.getAgeData());
            Select.debugLine("pages/RegisterPage.ets(96:9)");
            Select.value("选择你的年龄");
            Select.onSelect((index, value) => {
                this.age = Number.parseInt(value);
            });
            if (!isInitialRender) {
                Select.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Select.pop();
        //年龄
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //性别
            Row.create();
            Row.debugLine("pages/RegisterPage.ets(109:7)");
            //性别
            Row.width("100%");
            //性别
            Row.justifyContent(FlexAlign.Start);
            //性别
            Row.padding({
                left: 10,
                right: 10
            });
            if (!isInitialRender) {
                //性别
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new MyText(this, { content: "性别" }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Radio.create({ value: "male", group: "sex" });
            Radio.debugLine("pages/RegisterPage.ets(111:9)");
            Radio.checked(true);
            Radio.onChange((isSelect) => {
                if (isSelect) {
                    this.sex = 0;
                }
            });
            if (!isInitialRender) {
                Radio.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("男");
            Text.debugLine("pages/RegisterPage.ets(118:9)");
            Text.margin({ right: 20 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Radio.create({ value: "female", group: "sex" });
            Radio.debugLine("pages/RegisterPage.ets(120:9)");
            Radio.onChange((isSelect) => {
                if (isSelect) {
                    this.sex = 1;
                }
            });
            if (!isInitialRender) {
                Radio.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("女");
            Text.debugLine("pages/RegisterPage.ets(126:9)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        //性别
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //个人简介
            Text.create("个人简介");
            Text.debugLine("pages/RegisterPage.ets(134:7)");
            //个人简介
            Text.width("100%");
            //个人简介
            Text.textAlign(TextAlign.Start);
            //个人简介
            Text.margin({
                left: 15
            });
            if (!isInitialRender) {
                //个人简介
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        //个人简介
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextArea.create({
                placeholder: "请输入个人简介"
            });
            TextArea.debugLine("pages/RegisterPage.ets(140:7)");
            TextArea.width("95%");
            TextArea.height(200);
            if (!isInitialRender) {
                TextArea.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel("注册");
            Button.debugLine("pages/RegisterPage.ets(145:7)");
            Button.width("90%");
            Button.height(50);
            Button.fontSize(22);
            Button.backgroundColor({ "id": 16777233, "type": 10001, params: [], "bundleName": "com.snkey.sl1", "moduleName": "entry" });
            Button.onClick(() => {
                console.info(TAG, "username=" + this.username);
                console.info(TAG, "password=" + this.password);
                console.info(TAG, "password2=" + this.password2);
                console.info(TAG, "age=" + this.age);
                console.info(TAG, "sex=" + this.sex);
                if (this.username.length <= 3
                    || this.password.length <= 3
                    || this.password2.length <= 3) {
                    AlertDialog.show({ message: "用户名或者密码长度不符合规范，要求长度大于3！" });
                    return;
                }
                if (this.password !== this.password2) {
                    AlertDialog.show({ message: "两次输入的密码不一致，请重新输入！" });
                    return;
                }
                vm.axiosRegister(this.username, this.password, this.age, this.sex);
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new RegisterPage(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=RegisterPage.js.map