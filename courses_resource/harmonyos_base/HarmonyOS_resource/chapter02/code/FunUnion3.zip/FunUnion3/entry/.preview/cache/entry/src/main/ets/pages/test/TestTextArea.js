"use strict";
class TestTextArea extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__message = new ObservedPropertySimplePU('测试多行文本组件的使用', this, "message");
        this.myController = new TextAreaController();
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.message !== undefined) {
            this.message = params.message;
        }
        if (params.myController !== undefined) {
            this.myController = params.myController;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__message.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__message.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get message() {
        return this.__message.get();
    }
    set message(newValue) {
        this.__message.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/test/TestTextArea.ets(7:5)");
            Row.height('100%');
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/test/TestTextArea.ets(8:7)");
            Column.width('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.message);
            Text.debugLine("pages/test/TestTextArea.ets(9:9)");
            Text.fontSize(24);
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextArea.create({
                placeholder: "请输入个人简介",
                // text:"我是xx",
                controller: this.myController
            });
            TextArea.debugLine("pages/test/TestTextArea.ets(13:9)");
            TextArea.height(300);
            TextArea.placeholderColor(Color.Orange);
            TextArea.placeholderFont({
                size: 22,
                style: FontStyle.Italic,
                weight: FontWeight.Bold
            });
            TextArea.fontColor(Color.Red);
            TextArea.fontSize(22);
            TextArea.fontStyle(FontStyle.Normal);
            TextArea.fontWeight(800);
            TextArea.caretColor(Color.Black);
            TextArea.textAlign(TextAlign.Center);
            TextArea.onChange((value) => {
                console.info("----->用户输入的内容：" + value);
            });
            TextArea.onCopy((value) => {
                console.info("----->复制:" + value);
            });
            TextArea.onCut((value) => {
                console.info("----->剪切：" + value);
                //剪切修改了内容，会触发onChange
            });
            TextArea.onPaste((value) => {
                console.info("----->粘贴：" + value);
                //粘贴修改了内容，会触发onChange
            });
            if (!isInitialRender) {
                TextArea.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel("修改光标的位置");
            Button.debugLine("pages/test/TestTextArea.ets(53:9)");
            Button.onClick(() => {
                this.myController.caretPosition(0);
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        Column.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new TestTextArea(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=TestTextArea.js.map