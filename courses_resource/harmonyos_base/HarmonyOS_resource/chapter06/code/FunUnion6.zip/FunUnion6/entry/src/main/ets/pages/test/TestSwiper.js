"use strict";
struct TestSwiper extends   {
    constructor() { }
    build() {
        .width("100%")
            .height("100%");
    }
}
//# sourceMappingURL=TestSwiper.js.map