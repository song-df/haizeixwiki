import { MyText } from './TestScroll';
struct TestScroll2 extends   {
    constructor() { }
    build() {
            .scrollable(ScrollDirection.Horizontal)
            .scrollBar(BarState.Auto)
            .scrollBarWidth(50)
            .scrollBarColor(Color.Blue)
            /**
             * xOffset，向左滚动为正数，向右滚动为负数，滚动的越多，偏离量的绝对值越大
             */
            .onScroll((xOffset, yOffset) => {
            console.info("xOffset=" + xOffset + ",yOffset=" + yOffset);
        });
    }
}
//# sourceMappingURL=TestScroll2.js.map