export struct Message extends   {
    constructor() { }
    build() {
            .fontSize(30);
    }
}
//# sourceMappingURL=Message.js.map