"use strict";
struct TestGrid extends   {
    constructor() { }
    build() {
        .alignContent(Alignment.TopEnd);
    }
}
//# sourceMappingURL=TestGrid.js.map