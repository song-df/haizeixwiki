struct TestScroll extends   {
    constructor() { }
    build() {
        .scrollable(ScrollDirection.Vertical)
            .scrollBar(BarState.Auto)
            .scrollBarColor(Color.Blue)
            .scrollBarWidth(50)
            /**
             * 滚动时触发的事件方法
             * xOffset:x轴的偏移量
             * yOffset：y轴的偏移量，向上滚动的时候，正数；向下的时候，是负数
             */
            .onScroll((xOffset, yOffset) => {
            console.info("xOffset=" + xOffset + ", yOffset=" + yOffset);
        })
            .onScrollStart(() => {
            console.info("开始滚动");
        })
            .onScrollStop(() => {
            console.info("结束滚动");
        })
            //滚动到容器的边缘会触发的事件方法，顶部0，底部2
            .onScrollEdge((edge) => {
            console.info("滚动边缘,edge:" + edge.toString());
        });
    }
}
export struct MyText extends  {
    constructor() { }
    build() {
            .fontColor(Color.White)
            .fontSize(50)
            .width("100%")
            .textAlign(TextAlign.Center);
    }
}
//# sourceMappingURL=TestScroll.js.map