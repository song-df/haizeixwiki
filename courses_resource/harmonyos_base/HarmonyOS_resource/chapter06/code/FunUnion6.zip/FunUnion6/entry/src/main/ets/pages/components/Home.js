import router from '@ohos.router';
export struct Home extends  {
    constructor() { }
    build() {
        .width("100%")
            .height("100%")
            .barWidth(200);
    }
}
struct Recommend extends  {
    constructor() { }
    build() {
        .columnsTemplate("1fr 1fr")
            .columnsGap(5)
            .rowsGap(5);
    }
}
struct MyItem extends  {
    constructor() { }
    build() {
        ;
    }
}
//# sourceMappingURL=Home.js.map