import { Home } from "./components/Home";
import { Shopping } from "./components/Shopping";
import { Personal } from "./components/Personal";
import { Message } from "./components/Message";
struct MainPage extends   {
    constructor() { }
    build() {
        .width("100%")
            .height("100%")
            .backgroundColor("#f1f1f1")
            .barWidth("100%")
            .barHeight(55);
    }
}
//# sourceMappingURL=MainPage.js.map