import router from '@ohos.router';
const TAG = "----->";
import vm from "../ViewModel/MainVideModel";
function myImageStyle() {
    
  
        .width(150)
        .height(150)
        .margin({
        top: 100,
        bottom: 20
    });
}
function commonSize() {
    
  
        .width("90%")
        .height(50);
}
function mySpanStyle() {
    
  
        .fontColor($r("app.color.theme_color_main"))
        .decoration({
        type: TextDecorationType.Underline,
        color: $r("app.color.theme_color_main")
    });
}
struct Login extends   {
    constructor() { }
    myInputArea() {
        ;
    }
    myCheckbox() {
        .width("100%")
            .justifyContent(FlexAlign.Center)
            .margin({
            top: 10,
            bottom: 10
        });
    }
    build() {
        .width("100%")
            .height("100%")
            .justifyContent(FlexAlign.Start)
            .alignItems(HorizontalAlign.Center);
    }
    checkSystem() {
        if (!this.isSelected) {
            //给一个对话框
            AlertDialog.show({ message: "请勾选用户协议和隐私政策" });
            return;
        }
        if (this.username.length > 3 && this.password.length > 3) {
            router.pushUrl({
                url: "pages/MainPage",
                params: {
                    "username": this.username,
                    "password": this.password
                }
            });
        }
        else {
            AlertDialog.show({ message: "用户名或密码不符合" });
        }
    }
    onlineCheckSystem() {
        if (!this.isSelected) {
            //给一个对话框
            AlertDialog.show({ message: "请勾选用户协议和隐私政策" });
            return;
        }
        if (this.username.length <= 3 || this.password.length <= 3) {
            AlertDialog.show({ message: "账号或密码不符合规则" });
            return;
        }
        vm.login(this.username, this.password);
        //  //get、post
        //  //1、导包
        //  //2、创建一个 httpRequest 对象
        // let httpRequest : http.HttpRequest=  http.createHttp()
        //  //3、发起请求
        //  httpRequest.request("http://localhost:8080/user/login",{
        //    method: http.RequestMethod.POST,
        //    readTimeout:60000,
        //    connectTimeout:60000,
        //    usingCache:true,
        //    extraData:{
        //      "username":this.username,
        //      "password":this.password
        //    }
        //  }, (err,data)=>{
        //    console.info(TAG, "err=" + JSON.stringify(err))
        //    console.info(TAG, "result=" + JSON.stringify(data.result))
        //    AlertDialog.show({message:JSON.stringify(data.result)})
        //    console.info(TAG, "header=" + JSON.stringify(data.header))
        //    console.info(TAG, "responseCode=" + data.responseCode)
        //
        //    try {
        //      if(typeof data.result === "string"){
        //        let userResponse:UserResponse = JSON.parse(data.result)
        //        console.info(TAG, userResponse.msg)
        //        if(userResponse.data){
        //          console.info(TAG, userResponse.data.username)
        //        }
        //      }
        //    }catch(err){
        //      console.error(TAG, JSON.stringify(err))
        //    }
        //  })
        //  //4、销毁请求
        //  httpRequest.destroy()
    }
    axiosOnlineCheckSystem() {
        if (!this.isSelected) {
            //给一个对话框
            AlertDialog.show({ message: "请勾选用户协议和隐私政策" });
            return;
        }
        if (this.username.length <= 3 || this.password.length <= 3) {
            AlertDialog.show({ message: "账号或密码不符合规则" });
            return;
        }
        vm.axiosLogin(this.username, this.password);
    }
}
//# sourceMappingURL=Login.js.map