export struct Personal extends  {
    constructor() { }
    build() {
            .fontSize(30);
    }
}
//# sourceMappingURL=Personal.js.map