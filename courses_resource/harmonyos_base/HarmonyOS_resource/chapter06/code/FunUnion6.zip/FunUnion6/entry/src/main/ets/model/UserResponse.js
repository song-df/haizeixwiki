export {};
//# sourceMappingURL=UserResponse.js.map