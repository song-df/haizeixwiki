export struct Shopping extends  {
    constructor() { }
    build() {
            .fontSize(30);
    }
}
//# sourceMappingURL=Shopping.js.map