import router from '@ohos.router';
export struct CommonHeader extends   {
    constructor() { }
    build() {
        .width("100%")
            .padding({
            left: 5,
            top: 10,
            bottom: 10
        });
    }
}
//# sourceMappingURL=CommonHeader.js.map