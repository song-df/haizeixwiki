import { MyText } from './TestScroll';
struct TestList extends   {
    constructor() { }
    build() {
        ;
    }
}
//# sourceMappingURL=TestList.js.map