"use strict";
class TestSwiper extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.myController = new SwiperController();
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.myController !== undefined) {
            this.myController = params.myController;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/test/TestSwiper.ets(8:5)");
            Column.width("100%");
            Column.height("100%");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //默认是水平方向， 而且是自动循环
            Swiper.create(this.myController);
            Swiper.debugLine("pages/test/TestSwiper.ets(10:7)");
            //默认是水平方向， 而且是自动循环
            Swiper.width("100%");
            //默认是水平方向， 而且是自动循环
            Swiper.height(300);
            //默认是水平方向， 而且是自动循环
            Swiper.autoPlay(true);
            //默认是水平方向， 而且是自动循环
            Swiper.index(0);
            //默认是水平方向， 而且是自动循环
            Swiper.interval(3000);
            //默认是水平方向， 而且是自动循环
            Swiper.loop(true);
            //默认是水平方向， 而且是自动循环
            Swiper.indicatorStyle({
                color: Color.White,
                selectedColor: Color.Red //轮播当前的小点点的颜色
            });
            //默认是水平方向， 而且是自动循环
            Swiper.displayMode(SwiperDisplayMode.AutoLinear);
            //默认是水平方向， 而且是自动循环
            Swiper.displayCount(1);
            //默认是水平方向， 而且是自动循环
            Swiper.onChange((index) => {
                console.info("index=" + index);
            });
            //默认是水平方向， 而且是自动循环
            Swiper.onAnimationStart((index) => {
                console.info("动画开始,index=" + index);
            });
            //默认是水平方向， 而且是自动循环
            Swiper.onAnimationEnd((index) => {
                console.info("动画结束,index=" + index);
            });
            if (!isInitialRender) {
                //默认是水平方向， 而且是自动循环
                Swiper.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777243, "type": 20000, params: [], "bundleName": "com.snkey.sl1", "moduleName": "entry" });
            Image.debugLine("pages/test/TestSwiper.ets(11:9)");
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777241, "type": 20000, params: [], "bundleName": "com.snkey.sl1", "moduleName": "entry" });
            Image.debugLine("pages/test/TestSwiper.ets(12:9)");
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777235, "type": 20000, params: [], "bundleName": "com.snkey.sl1", "moduleName": "entry" });
            Image.debugLine("pages/test/TestSwiper.ets(13:9)");
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        //默认是水平方向， 而且是自动循环
        Swiper.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/test/TestSwiper.ets(41:7)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel("显示上一张");
            Button.debugLine("pages/test/TestSwiper.ets(42:9)");
            Button.onClick(() => {
                this.myController.showPrevious();
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel("显示下一张");
            Button.debugLine("pages/test/TestSwiper.ets(46:9)");
            Button.onClick(() => {
                this.myController.showNext();
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Swiper.create(this.myController);
            Swiper.debugLine("pages/test/TestSwiper.ets(52:7)");
            Swiper.width("100%");
            Swiper.height(300);
            Swiper.vertical(true);
            Swiper.autoPlay(true);
            Swiper.loop(true);
            Swiper.interval(3000);
            if (!isInitialRender) {
                Swiper.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777243, "type": 20000, params: [], "bundleName": "com.snkey.sl1", "moduleName": "entry" });
            Image.debugLine("pages/test/TestSwiper.ets(53:9)");
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777241, "type": 20000, params: [], "bundleName": "com.snkey.sl1", "moduleName": "entry" });
            Image.debugLine("pages/test/TestSwiper.ets(54:9)");
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777235, "type": 20000, params: [], "bundleName": "com.snkey.sl1", "moduleName": "entry" });
            Image.debugLine("pages/test/TestSwiper.ets(55:9)");
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Swiper.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new TestSwiper(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=TestSwiper.js.map