"use strict";
struct TestSelect extends   {
    constructor() { }
    build() {
            .height('100%');
    }
}
//# sourceMappingURL=TestSelect.js.map