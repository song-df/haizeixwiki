import { CommonHeader } from "../common/components/CommonHeader";
import vm from "../ViewModel/MainVideModel";
function myInputStyle() {
    
  
        .width("75%")
        .height(45);
}
struct RegisterPage extends   {
    constructor() { }
    MyText(title) {
            .width("25%");
    }
    build() {
        .justifyContent(FlexAlign.Start)
            .width("100%")
            .height("100%")
            .padding({
            left: 10,
            right: 10
        });
    }
}
//# sourceMappingURL=RegisterPage.js.map