"use strict";
struct TestTab extends   {
    constructor() { }
    build() {
            .width("100%")
            .height("100%")
            // .barPosition()
            .vertical(false)
            // .barMode(BarMode.Scrollable)
            // .barWidth(200)
            .barHeight(55)
            .backgroundColor("#f1f1f1")
            .onChange((index) => {
            console.info("----->index=" + index);
        });
    }
}
//# sourceMappingURL=TestTab.js.map