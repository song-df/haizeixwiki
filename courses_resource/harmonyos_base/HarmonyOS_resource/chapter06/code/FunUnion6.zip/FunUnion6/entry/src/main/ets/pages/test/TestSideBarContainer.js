"use strict";
const BAR_HEIGHT = 55;
struct TestSideBarContainer extends   {
    constructor() { }
    build() {
        /**
         * SideBarContainerType.Overlay，上层显示
         * SideBarContainerType.Embed,默认值，并列显示
         */
            .showSideBar(false) //设置是否默认显示侧边栏
            .controlButton({
            left: 10,
            top: 10,
            height: 32
        })
            //设置侧边栏的宽度尺寸
            .sideBarWidth(100)
            //设置侧边栏的滑出位置
            .sideBarPosition(SideBarPosition.Start)
            .onChange((value) => {
            console.info("----->显示或隐藏:" + value);
        });
    }
}
//# sourceMappingURL=TestSideBarContainer.js.map