"use strict";
struct preview extends  {
    constructor() { }
    build() {
        .width("100%")
            .height("100%");
    }
}
//# sourceMappingURL=preview.js.map