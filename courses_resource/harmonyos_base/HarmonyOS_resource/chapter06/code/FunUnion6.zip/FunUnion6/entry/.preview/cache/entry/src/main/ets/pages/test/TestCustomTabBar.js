"use strict";
class TestCustomTabBar extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__currentIndex = new ObservedPropertySimplePU(0, this, "currentIndex");
        this.myController = new TabsController();
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.currentIndex !== undefined) {
            this.currentIndex = params.currentIndex;
        }
        if (params.myController !== undefined) {
            this.myController = params.myController;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__currentIndex.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__currentIndex.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get currentIndex() {
        return this.__currentIndex.get();
    }
    set currentIndex(newValue) {
        this.__currentIndex.set(newValue);
    }
    /**
     * 自定义我们的 TabBar
     * @param targetIndex  TabBar的索引
     * @param title  TabBar的内容
     * @param selectedImg  TabBar选中时的 icon
     * @param normalImage  TabBar 未选中时的 icon
     */
    TabBuilder(targetIndex, title, selectedImg, normalImage, parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/test/TestCustomTabBar.ets(16:5)");
            Column.height(50);
            Column.justifyContent(FlexAlign.SpaceAround);
            Column.onClick(() => {
                this.myController.changeIndex(targetIndex);
                this.currentIndex = targetIndex;
            });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //一个是选中时显示的图标，一个是未选中时的图标
            Image.create(this.currentIndex === targetIndex ? selectedImg : normalImage);
            Image.debugLine("pages/test/TestCustomTabBar.ets(18:7)");
            //一个是选中时显示的图标，一个是未选中时的图标
            Image.width(25);
            //一个是选中时显示的图标，一个是未选中时的图标
            Image.height(25);
            if (!isInitialRender) {
                //一个是选中时显示的图标，一个是未选中时的图标
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(title);
            Text.debugLine("pages/test/TestCustomTabBar.ets(21:7)");
            Text.fontColor(this.currentIndex === targetIndex ? "#24b574" : "#444444");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Tabs.create({
                controller: this.myController
            });
            Tabs.debugLine("pages/test/TestCustomTabBar.ets(34:5)");
            Tabs.width("100%");
            Tabs.height("100%");
            Tabs.barPosition(BarPosition.End);
            Tabs.scrollable(false);
            Tabs.backgroundColor("#f1f3f5");
            if (!isInitialRender) {
                Tabs.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TabContent.create(() => {
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create("我是首页");
                    Text.debugLine("pages/test/TestCustomTabBar.ets(38:9)");
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
            });
            TabContent.tabBar({ builder: () => {
                    this.TabBuilder.call(this, 0, "首页", { "id": 16777227, "type": 20000, params: [], "bundleName": "com.snkey.sl1", "moduleName": "entry" }, { "id": 16777231, "type": 20000, params: [], "bundleName": "com.snkey.sl1", "moduleName": "entry" });
                } });
            TabContent.backgroundColor(Color.White);
            TabContent.debugLine("pages/test/TestCustomTabBar.ets(37:7)");
            if (!isInitialRender) {
                TabContent.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        TabContent.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TabContent.create(() => {
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create("我是添加");
                    Text.debugLine("pages/test/TestCustomTabBar.ets(43:9)");
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
            });
            TabContent.tabBar({ builder: () => {
                    this.TabBuilder.call(this, 1, "添加", { "id": 16777225, "type": 20000, params: [], "bundleName": "com.snkey.sl1", "moduleName": "entry" }, { "id": 16777221, "type": 20000, params: [], "bundleName": "com.snkey.sl1", "moduleName": "entry" });
                } });
            TabContent.debugLine("pages/test/TestCustomTabBar.ets(42:7)");
            if (!isInitialRender) {
                TabContent.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        TabContent.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TabContent.create(() => {
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create("我是运动");
                    Text.debugLine("pages/test/TestCustomTabBar.ets(47:9)");
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
            });
            TabContent.tabBar({ builder: () => {
                    this.TabBuilder.call(this, 2, "运动", { "id": 16777226, "type": 20000, params: [], "bundleName": "com.snkey.sl1", "moduleName": "entry" }, { "id": 16777228, "type": 20000, params: [], "bundleName": "com.snkey.sl1", "moduleName": "entry" });
                } });
            TabContent.debugLine("pages/test/TestCustomTabBar.ets(46:7)");
            if (!isInitialRender) {
                TabContent.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        TabContent.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TabContent.create(() => {
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create("我是我的");
                    Text.debugLine("pages/test/TestCustomTabBar.ets(51:9)");
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
            });
            TabContent.tabBar({ builder: () => {
                    this.TabBuilder.call(this, 3, "我的", { "id": 16777237, "type": 20000, params: [], "bundleName": "com.snkey.sl1", "moduleName": "entry" }, { "id": 16777229, "type": 20000, params: [], "bundleName": "com.snkey.sl1", "moduleName": "entry" });
                } });
            TabContent.debugLine("pages/test/TestCustomTabBar.ets(50:7)");
            if (!isInitialRender) {
                TabContent.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        TabContent.pop();
        Tabs.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new TestCustomTabBar(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=TestCustomTabBar.js.map