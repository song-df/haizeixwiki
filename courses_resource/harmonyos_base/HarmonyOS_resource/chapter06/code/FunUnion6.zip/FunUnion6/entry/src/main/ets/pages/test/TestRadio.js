"use strict";
struct TestRadio extends   {
    constructor() { }
    build() {
            .height('100%');
    }
}
//# sourceMappingURL=TestRadio.js.map