"use strict";
const BAR_HEIGHT = 55;
class TestSideBarContainer extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            /**
             * SideBarContainerType.Overlay，上层显示
             * SideBarContainerType.Embed,默认值，并列显示
             */
            SideBarContainer.create(SideBarContainerType.Overlay);
            SideBarContainer.debugLine("pages/test/TestSideBarContainer.ets(13:5)");
            /**
             * SideBarContainerType.Overlay，上层显示
             * SideBarContainerType.Embed,默认值，并列显示
             */
            SideBarContainer.showSideBar(false);
            /**
             * SideBarContainerType.Overlay，上层显示
             * SideBarContainerType.Embed,默认值，并列显示
             */
            SideBarContainer.controlButton({
                left: 10,
                top: 10,
                height: 32
            });
            /**
             * SideBarContainerType.Overlay，上层显示
             * SideBarContainerType.Embed,默认值，并列显示
             */
            SideBarContainer.sideBarWidth(100);
            /**
             * SideBarContainerType.Overlay，上层显示
             * SideBarContainerType.Embed,默认值，并列显示
             */
            SideBarContainer.sideBarPosition(SideBarPosition.Start);
            /**
             * SideBarContainerType.Overlay，上层显示
             * SideBarContainerType.Embed,默认值，并列显示
             */
            SideBarContainer.onChange((value) => {
                console.info("----->显示或隐藏:" + value);
            });
            if (!isInitialRender) {
                /**
                 * SideBarContainerType.Overlay，上层显示
                 * SideBarContainerType.Embed,默认值，并列显示
                 */
                SideBarContainer.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //里面需要有2个子组件
            //第一个子组件是侧边栏的内容
            //第二个子组件是主页面内容
            //侧边栏区域
            Column.create({ space: 20 });
            Column.debugLine("pages/test/TestSideBarContainer.ets(19:7)");
            //里面需要有2个子组件
            //第一个子组件是侧边栏的内容
            //第二个子组件是主页面内容
            //侧边栏区域
            Column.backgroundColor("#f1f1f1");
            //里面需要有2个子组件
            //第一个子组件是侧边栏的内容
            //第二个子组件是主页面内容
            //侧边栏区域
            Column.margin({
                top: BAR_HEIGHT
            });
            //里面需要有2个子组件
            //第一个子组件是侧边栏的内容
            //第二个子组件是主页面内容
            //侧边栏区域
            Column.padding({
                left: 10,
                top: 20,
                right: 10,
                bottom: 20
            });
            if (!isInitialRender) {
                //里面需要有2个子组件
                //第一个子组件是侧边栏的内容
                //第二个子组件是主页面内容
                //侧边栏区域
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("我是侧边栏");
            Text.debugLine("pages/test/TestSideBarContainer.ets(20:9)");
            Text.onClick(() => {
                AlertDialog.show({ message: "我被点击了" });
            });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("我是侧边栏");
            Text.debugLine("pages/test/TestSideBarContainer.ets(24:9)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("我是侧边栏");
            Text.debugLine("pages/test/TestSideBarContainer.ets(25:9)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("我是侧边栏");
            Text.debugLine("pages/test/TestSideBarContainer.ets(26:9)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("我是侧边栏");
            Text.debugLine("pages/test/TestSideBarContainer.ets(27:9)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("我是侧边栏");
            Text.debugLine("pages/test/TestSideBarContainer.ets(28:9)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("我是侧边栏");
            Text.debugLine("pages/test/TestSideBarContainer.ets(29:9)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        //里面需要有2个子组件
        //第一个子组件是侧边栏的内容
        //第二个子组件是主页面内容
        //侧边栏区域
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //主页面区域
            Column.create();
            Column.debugLine("pages/test/TestSideBarContainer.ets(41:7)");
            //主页面区域
            Column.backgroundColor(Color.White);
            if (!isInitialRender) {
                //主页面区域
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //标题栏
            Row.create();
            Row.debugLine("pages/test/TestSideBarContainer.ets(43:9)");
            //标题栏
            Row.width("100%");
            //标题栏
            Row.height(BAR_HEIGHT);
            //标题栏
            Row.justifyContent(FlexAlign.Center);
            if (!isInitialRender) {
                //标题栏
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("标题");
            Text.debugLine("pages/test/TestSideBarContainer.ets(44:13)");
            Text.fontSize(30);
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        //标题栏
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //内容区域
            Column.create({ space: 20 });
            Column.debugLine("pages/test/TestSideBarContainer.ets(53:9)");
            //内容区域
            Column.margin({
                top: 20
            });
            if (!isInitialRender) {
                //内容区域
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel("我是主页面的按钮");
            Button.debugLine("pages/test/TestSideBarContainer.ets(54:11)");
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel("我是主页面的按钮");
            Button.debugLine("pages/test/TestSideBarContainer.ets(55:11)");
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel("我是主页面的按钮");
            Button.debugLine("pages/test/TestSideBarContainer.ets(56:11)");
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel("我是主页面的按钮");
            Button.debugLine("pages/test/TestSideBarContainer.ets(57:11)");
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel("我是主页面的按钮");
            Button.debugLine("pages/test/TestSideBarContainer.ets(58:11)");
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        //内容区域
        Column.pop();
        //主页面区域
        Column.pop();
        /**
         * SideBarContainerType.Overlay，上层显示
         * SideBarContainerType.Embed,默认值，并列显示
         */
        SideBarContainer.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new TestSideBarContainer(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=TestSideBarContainer.js.map