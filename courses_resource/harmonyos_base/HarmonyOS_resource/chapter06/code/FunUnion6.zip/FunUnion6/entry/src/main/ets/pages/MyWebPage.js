import router from '@ohos.router';
import webview from '@ohos.web.webview';
const USER_AGREEMENT = "developer.harmonyos.com";
const PRIVACY_POLICY = "www.baidu.com";
const TAG = "----->";
struct MyWebPage extends   {
    constructor() { }
    aboutToAppear() {
        this.flag = router.getParams()["flag"];
        console.info("flag=" + this.flag);
    }
    build() {
        ;
    }
}
//# sourceMappingURL=MyWebPage.js.map