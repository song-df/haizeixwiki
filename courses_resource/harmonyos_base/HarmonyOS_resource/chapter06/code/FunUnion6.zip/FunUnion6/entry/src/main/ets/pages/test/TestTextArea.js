"use strict";
struct TestTextArea extends   {
    constructor() { }
    build() {
            .height('100%');
    }
}
//# sourceMappingURL=TestTextArea.js.map