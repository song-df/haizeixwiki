"use strict";
class TestSelect extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__message = new ObservedPropertySimplePU('测试单选框组件的使用', this, "message");
        this.data = [
            {
                value: "关羽",
                icon: { "id": 16777232, "type": 20000, params: [], "bundleName": "com.snkey.sl1", "moduleName": "entry" }
            },
            {
                value: "张飞",
                icon: { "id": 16777221, "type": 20000, params: [], "bundleName": "com.snkey.sl1", "moduleName": "entry" }
            },
            {
                value: "赵云",
                icon: { "id": 16777230, "type": 20000, params: [], "bundleName": "com.snkey.sl1", "moduleName": "entry" }
            },
            {
                value: "马超",
                icon: { "id": 16777229, "type": 20000, params: [], "bundleName": "com.snkey.sl1", "moduleName": "entry" }
            },
            {
                value: "黄忠",
                icon: { "id": 16777225, "type": 20000, params: [], "bundleName": "com.snkey.sl1", "moduleName": "entry" }
            }
        ];
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.message !== undefined) {
            this.message = params.message;
        }
        if (params.data !== undefined) {
            this.data = params.data;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__message.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__message.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get message() {
        return this.__message.get();
    }
    set message(newValue) {
        this.__message.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/test/TestSelect.ets(30:5)");
            Row.height('100%');
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/test/TestSelect.ets(31:7)");
            Column.width('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.message);
            Text.debugLine("pages/test/TestSelect.ets(32:9)");
            Text.fontSize(24);
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Select.create(this.data);
            Select.debugLine("pages/test/TestSelect.ets(36:9)");
            Select.value("===选择英雄===");
            Select.fontColor(Color.Brown);
            Select.optionFontColor(Color.Pink);
            Select.selectedOptionFontColor(Color.Red);
            Select.selectedOptionBgColor(Color.Orange);
            Select.onSelect((index, value) => {
                console.info("index=" + index);
                console.info("value=" + value);
            });
            if (!isInitialRender) {
                Select.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Select.pop();
        Column.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new TestSelect(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=TestSelect.js.map