struct DetailPage extends   {
    constructor() { }
    // aboutToAppear(){
    //   let index:number = router.getParams()['index']
    //   console.info("----->index=" + index)
    //   //发起网络请求
    // }
    build() {
        .width("100%")
            .height("100%");
    }
}
struct Title extends  {
    constructor() { }
    build() {
        .width("100%")
            .margin({
            left: 5,
            top: 10,
            right: 5,
            bottom: 10
        });
    }
}
struct MySwiper extends  {
    constructor() { }
    build() {
    }
}
struct MyContent extends  {
    constructor() { }
    build() {
    }
}
struct MyComment extends  {
    constructor() { }
    build() {
    }
}
export {};
//# sourceMappingURL=DetailPage.js.map