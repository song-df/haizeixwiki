"use strict";
struct TestStack extends   {
    constructor() { }
    build() {
        .width("100%")
            .height("100%")
            .alignContent(Alignment.TopStart);
    }
}
//# sourceMappingURL=TestStack.js.map