import http from '@ohos.net.http';
import axios from '@ohos/axios';
import router from '@ohos.router';
const TAG = "----->【MainViewModel】";
import dataPreferences from "@ohos.data.preferences";
export class MainViewModel {
    login(username, password) {
        let httpRequest = http.createHttp();
        //3、发起请求
        httpRequest.request("http://localhost:8080/user/login", {
            method: http.RequestMethod.POST,
            readTimeout: 60000,
            connectTimeout: 60000,
            usingCache: true,
            extraData: {
                "username": username,
                "password": password
            }
        }, (err, data) => {
            console.info(TAG, "err=" + JSON.stringify(err));
            console.info(TAG, "result=" + JSON.stringify(data.result));
            AlertDialog.show({ message: JSON.stringify(data.result) });
            console.info(TAG, "header=" + JSON.stringify(data.header));
            console.info(TAG, "responseCode=" + data.responseCode);
            try {
                if (typeof data.result === "string") {
                    let userResponse = JSON.parse(data.result);
                    console.info(TAG, userResponse.msg);
                    if (userResponse.data) {
                        console.info(TAG, userResponse.data.username);
                    }
                }
            }
            catch (err) {
                console.error(TAG, JSON.stringify(err));
            }
        });
        //4、销毁请求
        httpRequest.destroy();
    }
    axiosLogin(username, password) {
        let user = {
            username: username,
            password: password
        };
        axios.post("http://192.168.1.33:8080/user/login", user)
            //Promise
            .then((response) => {
            console.info(TAG, "请求成功：" + JSON.stringify(response));
            console.info(TAG, "msg=" + response.data.msg);
            if (response.data.code == 200 && response.data.data) {
                let resultUser = response.data.data;
                console.info(TAG, "user=" + JSON.stringify(resultUser));
                //格式化代码：ctrl+alt+L/command+alt+L
                AppStorage.SetOrCreate("user", resultUser);
                //保存用户登录的状态，已经登录，-true,false
                this.saveLoginStatus();
                router.pushUrl({
                    url: "pages/MainPage"
                });
            }
            else {
                AlertDialog.show({ message: response.data.msg });
            }
        })
            .catch((err) => {
            console.error(TAG, "请求失败" + JSON.stringify(err));
        });
    }
    saveLoginStatus() {
        dataPreferences.getPreferences(getContext(), "user", (err, myPreferences) => {
            if (err) {
                console.info(TAG, "获取 Preferences 实例失败");
                return;
            }
            myPreferences.put("isLogin", true, (err, data) => {
                if (err) {
                    console.info(TAG, "保存数据失败");
                    return;
                }
                myPreferences.flush();
                console.info(TAG, "保存登陆状态数据成功");
            });
        });
    }
    //获取下拉菜单的年龄数据
    //18~100,100-17=83
    getAgeData() {
        //索引0~82，index+18
        let ageData = Array.from({ length: 83 }, (_, index) => {
            return {
                value: (index + 18).toString()
            };
        });
        return ageData;
    }
    axiosRegister(username, password, age, gender) {
        let params = {
            username: username,
            password: password,
            age: age,
            gender: gender
        };
        axios.post("http://localhost:8080/user/register", params)
            .then((response) => {
            console.info(TAG, "注册请求成功，response=" + JSON.stringify(response));
            if (response.data.code == 200 && response.data.data) {
                console.info(TAG, "注册成功，用户信息：" + JSON.stringify(response.data.data));
                router.pushUrl({
                    url: "pages/Login"
                });
            }
            else {
                AlertDialog.show({ message: response.data.msg });
            }
        })
            .catch((error) => {
            console.info(TAG, "注册请求失败, error=" + JSON.stringify(error));
        });
    }
}
export default new MainViewModel();
//# sourceMappingURL=MainVideModel.js.map