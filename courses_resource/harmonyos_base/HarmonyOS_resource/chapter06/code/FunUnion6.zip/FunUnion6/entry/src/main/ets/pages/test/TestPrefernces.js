import dataPreferences from "@ohos.data.preferences";
struct TestPrefernces extends   {
    constructor() { }
    build() {
        .width("100%")
            .height("100%")
            .justifyContent(FlexAlign.Center)
            .alignItems(HorizontalAlign.Start);
    }
}
//# sourceMappingURL=TestPrefernces.js.map