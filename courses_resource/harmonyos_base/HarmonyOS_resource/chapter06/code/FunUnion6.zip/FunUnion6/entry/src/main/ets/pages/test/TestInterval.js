"use strict";
struct TestInterval extends   {
    constructor() { }
    build() {
            .height('100%');
    }
}
//# sourceMappingURL=TestInterval.js.map