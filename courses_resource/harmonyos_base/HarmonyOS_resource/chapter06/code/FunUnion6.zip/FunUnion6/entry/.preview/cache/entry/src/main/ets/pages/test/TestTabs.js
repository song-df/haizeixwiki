"use strict";
class TestTabs extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    // controller:TabsController = new TabsController()
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Tabs.create({
                barPosition: BarPosition.End,
                index: 1
                // controller: this.controller
            });
            Tabs.debugLine("pages/test/TestTabs.ets(8:5)");
            Tabs.width("100%");
            Tabs.height("100%");
            Tabs.vertical(false);
            Tabs.scrollable(true);
            Tabs.barMode(BarMode.Fixed);
            Tabs.barWidth(200);
            Tabs.barHeight(50);
            Tabs.backgroundColor("#f1f3f5");
            Tabs.onChange((index) => {
                console.info("----->index=" + index);
            });
            if (!isInitialRender) {
                Tabs.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TabContent.create(() => {
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    //首页的页面内容
                    Column.create();
                    Column.debugLine("pages/test/TestTabs.ets(15:9)");
                    if (!isInitialRender) {
                        //首页的页面内容
                        Column.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create("我是首页页面");
                    Text.debugLine("pages/test/TestTabs.ets(16:11)");
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                //首页的页面内容
                Column.pop();
            });
            TabContent.tabBar("首页");
            TabContent.debugLine("pages/test/TestTabs.ets(13:7)");
            if (!isInitialRender) {
                TabContent.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        TabContent.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TabContent.create(() => {
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create("我是消息页面");
                    Text.debugLine("pages/test/TestTabs.ets(27:9)");
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
            });
            TabContent.tabBar("消息");
            TabContent.backgroundColor(Color.White);
            TabContent.debugLine("pages/test/TestTabs.ets(26:7)");
            if (!isInitialRender) {
                TabContent.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        TabContent.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TabContent.create(() => {
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create("我是我的页面");
                    Text.debugLine("pages/test/TestTabs.ets(32:9)");
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
            });
            TabContent.tabBar("我的");
            TabContent.debugLine("pages/test/TestTabs.ets(31:7)");
            if (!isInitialRender) {
                TabContent.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        TabContent.pop();
        Tabs.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new TestTabs(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=TestTabs.js.map