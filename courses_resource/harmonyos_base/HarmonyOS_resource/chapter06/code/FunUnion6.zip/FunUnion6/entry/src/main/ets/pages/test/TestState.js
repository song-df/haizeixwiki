"use strict";
struct TestState extends   {
    constructor() { }
    build() {
        .width("100%")
            .height("100%")
            .justifyContent(FlexAlign.Center);
    }
}
struct ChildComponent1 extends  {
    constructor() { }
    build() {
        .width("100%")
            .height("30%")
            .backgroundColor("#f1f3f5");
    }
}
struct ChildComponent2 extends  {
    constructor() { }
    build() {
        .width("100%")
            .height("30%")
            .backgroundColor(Color.Orange);
    }
}
//# sourceMappingURL=TestState.js.map