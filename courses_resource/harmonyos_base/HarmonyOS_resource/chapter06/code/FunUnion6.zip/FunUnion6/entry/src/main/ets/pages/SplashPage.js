import router from '@ohos.router';
import dataPreferences from "@ohos.data.preferences";
struct SplashPage extends   {
    constructor() { }
    aboutToAppear() {
        this.intervalID = setInterval(() => {
            this.countdownTime--;
            if (this.countdownTime <= 0) {
                clearInterval(this.intervalID);
                this.jump();
            }
        }, 1000); //间隔的时间单位是毫秒
    }
    //页面跳转的逻辑
    jump() {
        dataPreferences.getPreferences(getContext(), 'user', (err, myPreferences) => {
            if (err) {
                console.info("----->获取Preferences实例失败");
                return;
            }
            myPreferences.get("isLogin", false, (err, status) => {
                if (err) {
                    console.info("----->获取失败");
                    return;
                }
                console.info("----->status=" + status);
                if (status) {
                    //已经登录过
                    router.pushUrl({
                        url: "pages/MainPage"
                    });
                }
                else {
                    //没有登录过
                    router.pushUrl({
                        url: "pages/Login"
                    });
                }
            });
        });
    }
    build() {
        .width("100%")
            .height("100%")
            .alignContent(Alignment.TopEnd);
    }
}
//# sourceMappingURL=SplashPage.js.map