import router from '@ohos:router';
import webview from '@ohos:web.webview';
const USER_AGREEMENT = "developer.harmonyos.com";
const PRIVACY_POLICY = "www.baidu.com";
const TAG = "----->";
class MyWebPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.flag = 1;
        this.myController = new webview.WebviewController();
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.flag !== undefined) {
            this.flag = params.flag;
        }
        if (params.myController !== undefined) {
            this.myController = params.myController;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    aboutToAppear() {
        this.flag = router.getParams()["flag"];
        console.info("flag=" + this.flag);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/MyWebPage.ets(17:7)");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/MyWebPage.ets(18:9)");
            Row.width("100%");
            Row.height(50);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777220, "type": 20000, params: [], "bundleName": "com.snkey.sl1", "moduleName": "entry" });
            Image.debugLine("pages/MyWebPage.ets(19:11)");
            Image.width(35);
            Image.height(35);
            Image.onClick(() => {
                router.back();
            });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            if (this.flag == 1) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create("用户协议");
                        Text.debugLine("pages/MyWebPage.ets(26:13)");
                        Text.fontSize(20);
                        Text.width("90%");
                        Text.textAlign(TextAlign.Center);
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                });
            }
            else if (this.flag == 2) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create("隐私政策");
                        Text.debugLine("pages/MyWebPage.ets(31:13)");
                        Text.fontSize(20);
                        Text.width("90%");
                        Text.textAlign(TextAlign.Center);
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                });
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            //条件渲染 、三目运算符来实现
            if (this.flag == 1) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Web.create({
                            src: { "id": 0, "type": 30000, params: ["user_agreement.html"], "bundleName": "com.snkey.sl1", "moduleName": "entry" },
                            controller: this.myController
                        });
                        Web.debugLine("pages/MyWebPage.ets(43:11)");
                        if (!isInitialRender) {
                            Web.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                });
            }
            else if (this.flag == 2) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Web.create({
                            src: { "id": 0, "type": 30000, params: ["privacy_policy.html"], "bundleName": "com.snkey.sl1", "moduleName": "entry" },
                            controller: this.myController
                        });
                        Web.debugLine("pages/MyWebPage.ets(63:11)");
                        if (!isInitialRender) {
                            Web.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                });
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new MyWebPage(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=MyWebPage.js.map