import router from '@ohos:router';
import dataPreferences from '@ohos:data.preferences';
class SplashPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__countdownTime = new ObservedPropertySimplePU(5, this, "countdownTime");
        this.intervalID = 0;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.countdownTime !== undefined) {
            this.countdownTime = params.countdownTime;
        }
        if (params.intervalID !== undefined) {
            this.intervalID = params.intervalID;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__countdownTime.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__countdownTime.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get countdownTime() {
        return this.__countdownTime.get();
    }
    set countdownTime(newValue) {
        this.__countdownTime.set(newValue);
    }
    aboutToAppear() {
        this.intervalID = setInterval(() => {
            this.countdownTime--;
            if (this.countdownTime <= 0) {
                clearInterval(this.intervalID);
                this.jump();
            }
        }, 1000); //间隔的时间单位是毫秒
    }
    //页面跳转的逻辑
    jump() {
        dataPreferences.getPreferences(getContext(), 'user', (err, myPreferences) => {
            if (err) {
                console.info("----->获取Preferences实例失败");
                return;
            }
            myPreferences.get("isLogin", false, (err, status) => {
                if (err) {
                    console.info("----->获取失败");
                    return;
                }
                console.info("----->status=" + status);
                if (status) {
                    //已经登录过
                    router.pushUrl({
                        url: "pages/MainPage"
                    });
                }
                else {
                    //没有登录过
                    router.pushUrl({
                        url: "pages/Login"
                    });
                }
            });
        });
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Stack.create();
            Stack.debugLine("pages/SplashPage.ets(51:7)");
            Stack.width("100%");
            Stack.height("100%");
            Stack.alignContent(Alignment.TopEnd);
            if (!isInitialRender) {
                Stack.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //
            Image.create({ "id": 16777224, "type": 20000, params: [], "bundleName": "com.snkey.sl1", "moduleName": "entry" });
            Image.debugLine("pages/SplashPage.ets(53:9)");
            //
            Image.width("100%");
            //
            Image.height("100%");
            //
            Image.objectFit(ImageFit.Cover);
            if (!isInitialRender) {
                //
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //自定义按钮
            Button.createWithChild();
            Button.debugLine("pages/SplashPage.ets(59:9)");
            //自定义按钮
            Button.width(85);
            //自定义按钮
            Button.height(40);
            //自定义按钮
            Button.backgroundColor("#f1f1f1");
            //自定义按钮
            Button.margin({
                top: 10,
                right: 10
            });
            //自定义按钮
            Button.onClick(() => {
                this.jump();
            });
            if (!isInitialRender) {
                //自定义按钮
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create({ space: 10 });
            Row.debugLine("pages/SplashPage.ets(60:11)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.countdownTime.toString());
            Text.debugLine("pages/SplashPage.ets(61:13)");
            Text.backgroundColor(Color.White);
            Text.width(30);
            Text.height(30);
            Text.textAlign(TextAlign.Center);
            Text.borderRadius(15);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("跳过");
            Text.debugLine("pages/SplashPage.ets(67:13)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        //自定义按钮
        Button.pop();
        Stack.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new SplashPage(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=SplashPage.js.map