import dataPreferences from '@ohos:data.preferences';
class TestPrefernces extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.myPreference = undefined;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.myPreference !== undefined) {
            this.myPreference = params.myPreference;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/test/TestPrefernces.ets(9:5)");
            Column.width("100%");
            Column.height("100%");
            Column.justifyContent(FlexAlign.Center);
            Column.alignItems(HorizontalAlign.Start);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel("获取Preferences 实例");
            Button.debugLine("pages/test/TestPrefernces.ets(10:7)");
            Button.onClick(() => {
                dataPreferences.getPreferences(getContext(), "user_test", (err, data) => {
                    if (err) {
                        console.info("----->获取实例失败, err" + JSON.stringify(err));
                        return;
                    }
                    console.info("------->获取Preferences实例成功");
                    this.myPreference = data;
                });
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel("保存数据");
            Button.debugLine("pages/test/TestPrefernces.ets(20:7)");
            Button.onClick(() => {
                if (this.myPreference) {
                    this.myPreference.put("name", "jack", (err, data) => {
                        if (err) {
                            console.info("保存数据失败， err=" + JSON.stringify(err));
                            return;
                        }
                        console.info("保存成功");
                    });
                    this.myPreference.put("age", 30, (err, data) => {
                        if (err) {
                            AlertDialog.show({ message: "保存失败" });
                            console.info("保存数据失败， err=" + JSON.stringify(err));
                            return;
                        }
                        console.info("保存成功");
                        AlertDialog.show({ message: "保存成功" });
                    });
                    this.myPreference.flush(); //持久到到本地文件
                }
                else {
                    console.info("----->Preference实例 undefined");
                }
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel("读取数据");
            Button.debugLine("pages/test/TestPrefernces.ets(46:7)");
            Button.onClick(() => {
                if (this.myPreference) {
                    this.myPreference.get("name", "default_name", (err, data) => {
                        if (err) {
                            console.info("----->读取数据失败,err=" + JSON.stringify(err));
                            AlertDialog.show({ message: "读取失败" });
                            return;
                        }
                        console.info("读取成功，data=" + data.toString());
                        AlertDialog.show({ message: "读取成功" });
                    });
                }
                else {
                    console.info("----->Preference实例 undefined");
                }
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel("删除数据");
            Button.debugLine("pages/test/TestPrefernces.ets(61:7)");
            Button.onClick(() => {
                if (this.myPreference) {
                    this.myPreference.delete("name", (err, data) => {
                        if (err) {
                            console.info("----->删除数据失败,err=" + JSON.stringify(err));
                            AlertDialog.show({ message: "删除失败" });
                            return;
                        }
                        console.info("删除成功");
                        AlertDialog.show({ message: "删除成功" });
                    });
                }
                else {
                    console.info("----->Preference实例 undefined");
                }
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new TestPrefernces(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=TestPrefernces.js.map