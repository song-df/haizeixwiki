import { CommonHeader } from '@bundle:com.snkey.sl1/entry/ets/common/components/CommonHeader';
import vm from '@bundle:com.snkey.sl1/entry/ets/ViewModel/MainVideModel';
class RegisterPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.username = "";
        this.password = "";
        this.password2 = "";
        this.age = 0 //18~100
        ;
        this.gender = 0 //0-表示男，1-表示女
        ;
        this.introduce = "";
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.username !== undefined) {
            this.username = params.username;
        }
        if (params.password !== undefined) {
            this.password = params.password;
        }
        if (params.password2 !== undefined) {
            this.password2 = params.password2;
        }
        if (params.age !== undefined) {
            this.age = params.age;
        }
        if (params.gender !== undefined) {
            this.gender = params.gender;
        }
        if (params.introduce !== undefined) {
            this.introduce = params.introduce;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    MyText(title, parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create();
            Text.debugLine("pages/RegisterPage.ets(22:5)");
            Text.width("25%");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Span.create(title);
            Span.debugLine("pages/RegisterPage.ets(23:7)");
            if (!isInitialRender) {
                Span.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Span.create("*");
            Span.debugLine("pages/RegisterPage.ets(24:7)");
            Span.fontColor(Color.Red);
            if (!isInitialRender) {
                Span.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/RegisterPage.ets(31:5)");
            Column.justifyContent(FlexAlign.Start);
            Column.width("100%");
            Column.height("100%");
            Column.padding({
                left: 10,
                right: 10
            });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new 
                    //标题栏
                    CommonHeader(this, { title: "注册" }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //输入用户名
            Row.create();
            Row.debugLine("pages/RegisterPage.ets(35:7)");
            //输入用户名
            Row.width("100%");
            //输入用户名
            Row.margin({
                bottom: 10
            });
            if (!isInitialRender) {
                //输入用户名
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.MyText.bind(this)("用户名");
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create();
            TextInput.debugLine("pages/RegisterPage.ets(37:9)");
            TextInput.width("75%");
            TextInput.height(45);
            TextInput.onChange((value) => {
                this.username = value;
            });
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        //输入用户名
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //输入密码
            Row.create();
            Row.debugLine("pages/RegisterPage.ets(47:7)");
            //输入密码
            Row.width("100%");
            //输入密码
            Row.margin({
                bottom: 10
            });
            if (!isInitialRender) {
                //输入密码
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.MyText.bind(this)("密码");
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create();
            TextInput.debugLine("pages/RegisterPage.ets(49:9)");
            TextInput.width("75%");
            TextInput.height(45);
            TextInput.type(InputType.Password);
            TextInput.onChange((value) => {
                this.password = value;
            });
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        //输入密码
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //输入确认密码
            Row.create();
            Row.debugLine("pages/RegisterPage.ets(60:7)");
            //输入确认密码
            Row.width("100%");
            //输入确认密码
            Row.margin({
                bottom: 10
            });
            if (!isInitialRender) {
                //输入确认密码
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.MyText.bind(this)("确认密码");
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create();
            TextInput.debugLine("pages/RegisterPage.ets(62:9)");
            TextInput.width("75%");
            TextInput.height(45);
            TextInput.type(InputType.Password);
            TextInput.onChange((value) => {
                this.password2 = value;
            });
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        //输入确认密码
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //选择年龄
            Row.create();
            Row.debugLine("pages/RegisterPage.ets(73:7)");
            //选择年龄
            Row.width("100%");
            //选择年龄
            Row.margin({
                bottom: 10
            });
            if (!isInitialRender) {
                //选择年龄
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("年龄");
            Text.debugLine("pages/RegisterPage.ets(74:9)");
            Text.width("25%");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Select.create(vm.getAgeData());
            Select.debugLine("pages/RegisterPage.ets(75:9)");
            Select.value("选择您的年龄");
            Select.onSelect((index, value) => {
                this.age = Number.parseInt(value);
            });
            if (!isInitialRender) {
                Select.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Select.pop();
        //选择年龄
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //选择性别
            Row.create();
            Row.debugLine("pages/RegisterPage.ets(85:7)");
            //选择性别
            Row.width("100%");
            //选择性别
            Row.margin({
                bottom: 10
            });
            if (!isInitialRender) {
                //选择性别
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("性别");
            Text.debugLine("pages/RegisterPage.ets(86:9)");
            Text.width("25%");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Radio.create({ value: "male", group: "sex" });
            Radio.debugLine("pages/RegisterPage.ets(89:9)");
            Radio.checked(true);
            Radio.onChange((isChecked) => {
                this.gender = isChecked ? 0 : 1;
            });
            if (!isInitialRender) {
                Radio.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("男");
            Text.debugLine("pages/RegisterPage.ets(94:9)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Radio.create({ value: "female", group: "sex" });
            Radio.debugLine("pages/RegisterPage.ets(95:9)");
            Radio.margin({
                left: 30
            });
            Radio.onChange((isChecked) => {
                this.gender = isChecked ? 1 : 0;
            });
            if (!isInitialRender) {
                Radio.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("女");
            Text.debugLine("pages/RegisterPage.ets(102:9)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        //选择性别
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //填写个人简介
            Text.create("个人简介");
            Text.debugLine("pages/RegisterPage.ets(108:7)");
            //填写个人简介
            Text.width("100%");
            //填写个人简介
            Text.textAlign(TextAlign.Start);
            //填写个人简介
            Text.margin({
                bottom: 10
            });
            if (!isInitialRender) {
                //填写个人简介
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        //填写个人简介
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextArea.create({
                placeholder: "请输入个人简介"
            });
            TextArea.debugLine("pages/RegisterPage.ets(114:7)");
            TextArea.height(300);
            TextArea.margin({
                bottom: 10
            });
            TextArea.onChange((value) => {
                this.introduce = value;
            });
            if (!isInitialRender) {
                TextArea.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //注册按钮
            Button.createWithLabel("注册");
            Button.debugLine("pages/RegisterPage.ets(126:7)");
            //注册按钮
            Button.width("95%");
            //注册按钮
            Button.height(50);
            //注册按钮
            Button.backgroundColor({ "id": 16777223, "type": 10001, params: [], "bundleName": "com.snkey.sl1", "moduleName": "entry" });
            //注册按钮
            Button.fontSize(22);
            //注册按钮
            Button.onClick(() => {
                console.info("用户名：" + this.username);
                console.info("密码1：" + this.password);
                console.info("密码2：" + this.password2);
                console.info("年龄：" + this.age);
                console.info("性别：" + this.gender);
                console.info("个人简介:" + this.introduce);
                if (this.password === this.password2) {
                    vm.axiosRegister(this.username, this.password, this.age, this.gender);
                }
                else {
                    AlertDialog.show({ message: "两次密码输入不一致" });
                }
            });
            if (!isInitialRender) {
                //注册按钮
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        //注册按钮
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new RegisterPage(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=RegisterPage.js.map