import router from '@ohos:router';
const TAG = "----->";
import vm from '@bundle:com.snkey.sl1/entry/ets/ViewModel/MainVideModel';
function __Span__mySpanStyle() {
    Span.fontColor({ "id": 16777223, "type": 10001, params: [], "bundleName": "com.snkey.sl1", "moduleName": "entry" });
    Span.decoration({
        type: TextDecorationType.Underline,
        color: { "id": 16777223, "type": 10001, params: [], "bundleName": "com.snkey.sl1", "moduleName": "entry" }
    });
}
class Login extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.username = "";
        this.password = "";
        this.isSelected = false;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.username !== undefined) {
            this.username = params.username;
        }
        if (params.password !== undefined) {
            this.password = params.password;
        }
        if (params.isSelected !== undefined) {
            this.isSelected = params.isSelected;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    myInputArea(parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Login.ets(39:5)");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create({
                placeholder: "请输入用户名"
            });
            TextInput.debugLine("pages/Login.ets(40:7)");
            TextInput.type(InputType.Normal);
            TextInput.width("90%");
            TextInput.height(50);
            TextInput.onChange((value) => {
                // console.info(TAG, "用户名=" + value)
                this.username = value;
            });
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create({
                placeholder: "请输入密码"
            });
            TextInput.debugLine("pages/Login.ets(50:7)");
            TextInput.type(InputType.Password);
            TextInput.width("90%");
            TextInput.height(50);
            TextInput.margin({
                top: 15
            });
            TextInput.onChange((value) => {
                // console.info(TAG, "密码=" + value)
                this.password = value;
            });
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Column.pop();
    }
    myCheckbox(parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Login.ets(66:5)");
            Row.width("100%");
            Row.justifyContent(FlexAlign.Center);
            Row.margin({
                top: 10,
                bottom: 10
            });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Checkbox.create();
            Checkbox.debugLine("pages/Login.ets(67:7)");
            Checkbox.selectedColor({ "id": 16777223, "type": 10001, params: [], "bundleName": "com.snkey.sl1", "moduleName": "entry" });
            Checkbox.onChange((value) => {
                // console.info(TAG, "勾选协议=" + value)
                this.isSelected = value;
            });
            if (!isInitialRender) {
                Checkbox.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Checkbox.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create();
            Text.debugLine("pages/Login.ets(73:7)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Span.create("请勾选");
            Span.debugLine("pages/Login.ets(74:9)");
            if (!isInitialRender) {
                Span.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Span.create("用户协议");
            Span.debugLine("pages/Login.ets(75:9)");
            __Span__mySpanStyle();
            Span.onClick(() => {
                // console.info(TAG, "点击了用户协议")
                router.pushUrl({
                    url: "pages/MyWebPage",
                    params: {
                        flag: 1
                    }
                });
            });
            if (!isInitialRender) {
                Span.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Span.create("和");
            Span.debugLine("pages/Login.ets(86:9)");
            if (!isInitialRender) {
                Span.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Span.create("隐私政策");
            Span.debugLine("pages/Login.ets(87:9)");
            __Span__mySpanStyle();
            Span.onClick(() => {
                // console.info(TAG, "点击了隐私政策")
                router.pushUrl({
                    url: "pages/MyWebPage",
                    params: {
                        flag: 2
                    }
                });
            });
            if (!isInitialRender) {
                Span.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Login.ets(108:5)");
            Column.width("100%");
            Column.height("100%");
            Column.justifyContent(FlexAlign.Start);
            Column.alignItems(HorizontalAlign.Center);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //图片
            Image.create({ "id": 16777226, "type": 20000, params: [], "bundleName": "com.snkey.sl1", "moduleName": "entry" });
            Image.debugLine("pages/Login.ets(110:7)");
            //图片
            Image.width(150);
            //图片
            Image.height(150);
            //图片
            Image.margin({
                top: 100,
                bottom: 20
            });
            if (!isInitialRender) {
                //图片
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        //输入区域
        this.myInputArea.bind(this)();
        //checkbox
        this.myCheckbox.bind(this)();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //登录按钮
            Button.createWithLabel("登录");
            Button.debugLine("pages/Login.ets(118:7)");
            //登录按钮
            Button.width("90%");
            //登录按钮
            Button.height(50);
            //登录按钮
            Button.backgroundColor({ "id": 16777223, "type": 10001, params: [], "bundleName": "com.snkey.sl1", "moduleName": "entry" });
            //登录按钮
            Button.fontSize(22);
            //登录按钮
            Button.onClick(() => {
                // console.info(TAG, "用户名=" + this.username)
                // console.info(TAG, "密码=" + this.password)
                // console.info(TAG, "勾选协议=" + this.isSelected)
                // this.checkSystem()
                // this.onlineCheckSystem()
                this.axiosOnlineCheckSystem();
            });
            if (!isInitialRender) {
                //登录按钮
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        //登录按钮
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Login.ets(130:7)");
            Row.width("100%");
            Row.justifyContent(FlexAlign.Center);
            Row.margin({
                top: 10
            });
            Row.onClick(() => {
                router.pushUrl({
                    url: "pages/RegisterPage"
                });
            });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("没有账号，去注册");
            Text.debugLine("pages/Login.ets(131:9)");
            Text.decoration({
                type: TextDecorationType.Underline
            });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777219, "type": 20000, params: [], "bundleName": "com.snkey.sl1", "moduleName": "entry" });
            Image.debugLine("pages/Login.ets(135:9)");
            Image.width(25);
            Image.height(25);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Blank.create();
            Blank.debugLine("pages/Login.ets(147:7)");
            if (!isInitialRender) {
                Blank.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Blank.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("蒙友 V1.0");
            Text.debugLine("pages/Login.ets(148:7)");
            Text.margin({
                bottom: 10
            });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
    }
    checkSystem() {
        if (!this.isSelected) {
            //给一个对话框
            AlertDialog.show({ message: "请勾选用户协议和隐私政策" });
            return;
        }
        if (this.username.length > 3 && this.password.length > 3) {
            router.pushUrl({
                url: "pages/MainPage",
                params: {
                    "username": this.username,
                    "password": this.password
                }
            });
        }
        else {
            AlertDialog.show({ message: "用户名或密码不符合" });
        }
    }
    onlineCheckSystem() {
        if (!this.isSelected) {
            //给一个对话框
            AlertDialog.show({ message: "请勾选用户协议和隐私政策" });
            return;
        }
        if (this.username.length <= 3 || this.password.length <= 3) {
            AlertDialog.show({ message: "账号或密码不符合规则" });
            return;
        }
        vm.login(this.username, this.password);
        //  //get、post
        //  //1、导包
        //  //2、创建一个 httpRequest 对象
        // let httpRequest : http.HttpRequest=  http.createHttp()
        //  //3、发起请求
        //  httpRequest.request("http://localhost:8080/user/login",{
        //    method: http.RequestMethod.POST,
        //    readTimeout:60000,
        //    connectTimeout:60000,
        //    usingCache:true,
        //    extraData:{
        //      "username":this.username,
        //      "password":this.password
        //    }
        //  }, (err,data)=>{
        //    console.info(TAG, "err=" + JSON.stringify(err))
        //    console.info(TAG, "result=" + JSON.stringify(data.result))
        //    AlertDialog.show({message:JSON.stringify(data.result)})
        //    console.info(TAG, "header=" + JSON.stringify(data.header))
        //    console.info(TAG, "responseCode=" + data.responseCode)
        //
        //    try {
        //      if(typeof data.result === "string"){
        //        let userResponse:UserResponse = JSON.parse(data.result)
        //        console.info(TAG, userResponse.msg)
        //        if(userResponse.data){
        //          console.info(TAG, userResponse.data.username)
        //        }
        //      }
        //    }catch(err){
        //      console.error(TAG, JSON.stringify(err))
        //    }
        //  })
        //  //4、销毁请求
        //  httpRequest.destroy()
    }
    axiosOnlineCheckSystem() {
        if (!this.isSelected) {
            //给一个对话框
            AlertDialog.show({ message: "请勾选用户协议和隐私政策" });
            return;
        }
        if (this.username.length <= 3 || this.password.length <= 3) {
            AlertDialog.show({ message: "账号或密码不符合规则" });
            return;
        }
        vm.axiosLogin(this.username, this.password);
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new Login(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=Login.js.map