/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 85);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports) {

var core = module.exports = { version: '2.5.3' };
if (typeof __e == 'number') __e = core; // eslint-disable-line no-undef


/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

var store = __webpack_require__(42)('wks');
var uid = __webpack_require__(26);
var Symbol = __webpack_require__(5).Symbol;
var USE_SYMBOL = typeof Symbol == 'function';

var $exports = module.exports = function (name) {
  return store[name] || (store[name] =
    USE_SYMBOL && Symbol[name] || (USE_SYMBOL ? Symbol : uid)('Symbol.' + name));
};

$exports.store = store;


/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

var global = __webpack_require__(5);
var core = __webpack_require__(0);
var ctx = __webpack_require__(17);
var hide = __webpack_require__(7);
var PROTOTYPE = 'prototype';

var $export = function (type, name, source) {
  var IS_FORCED = type & $export.F;
  var IS_GLOBAL = type & $export.G;
  var IS_STATIC = type & $export.S;
  var IS_PROTO = type & $export.P;
  var IS_BIND = type & $export.B;
  var IS_WRAP = type & $export.W;
  var exports = IS_GLOBAL ? core : core[name] || (core[name] = {});
  var expProto = exports[PROTOTYPE];
  var target = IS_GLOBAL ? global : IS_STATIC ? global[name] : (global[name] || {})[PROTOTYPE];
  var key, own, out;
  if (IS_GLOBAL) source = name;
  for (key in source) {
    // contains in native
    own = !IS_FORCED && target && target[key] !== undefined;
    if (own && key in exports) continue;
    // export native or passed
    out = own ? target[key] : source[key];
    // prevent global pollution for namespaces
    exports[key] = IS_GLOBAL && typeof target[key] != 'function' ? source[key]
    // bind timers to global for call from export context
    : IS_BIND && own ? ctx(out, global)
    // wrap global constructors for prevent change them in library
    : IS_WRAP && target[key] == out ? (function (C) {
      var F = function (a, b, c) {
        if (this instanceof C) {
          switch (arguments.length) {
            case 0: return new C();
            case 1: return new C(a);
            case 2: return new C(a, b);
          } return new C(a, b, c);
        } return C.apply(this, arguments);
      };
      F[PROTOTYPE] = C[PROTOTYPE];
      return F;
    // make static versions for prototype methods
    })(out) : IS_PROTO && typeof out == 'function' ? ctx(Function.call, out) : out;
    // export proto methods to core.%CONSTRUCTOR%.methods.%NAME%
    if (IS_PROTO) {
      (exports.virtual || (exports.virtual = {}))[key] = out;
      // export proto methods to core.%CONSTRUCTOR%.prototype.%NAME%
      if (type & $export.R && expProto && !expProto[key]) hide(expProto, key, out);
    }
  }
};
// type bitmap
$export.F = 1;   // forced
$export.G = 2;   // global
$export.S = 4;   // static
$export.P = 8;   // proto
$export.B = 16;  // bind
$export.W = 32;  // wrap
$export.U = 64;  // safe
$export.R = 128; // real proto method for `library`
module.exports = $export;


/***/ }),
/* 3 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export extend */
/* harmony export (immutable) */ __webpack_exports__["m"] = isDisposable;
/* unused harmony export Comparer */
/* harmony export (immutable) */ __webpack_exports__["g"] = comparerFromEqualityComparer;
/* unused harmony export containsValue */
/* harmony export (immutable) */ __webpack_exports__["r"] = tryGetValue;
/* harmony export (immutable) */ __webpack_exports__["a"] = addToSet;
/* unused harmony export assertEqual */
/* unused harmony export assertNotEqual */
/* unused harmony export Lazy */
/* unused harmony export lazyFromValue */
/* harmony export (immutable) */ __webpack_exports__["p"] = padWithZeros;
/* harmony export (immutable) */ __webpack_exports__["i"] = dateOffset;
/* unused harmony export int16ToString */
/* unused harmony export int32ToString */
/* unused harmony export ObjectRef */
/* unused harmony export stringHash */
/* harmony export (immutable) */ __webpack_exports__["o"] = numberHash;
/* harmony export (immutable) */ __webpack_exports__["b"] = combineHashCodes;
/* harmony export (immutable) */ __webpack_exports__["l"] = identityHash;
/* harmony export (immutable) */ __webpack_exports__["q"] = structuralHash;
/* unused harmony export isArray */
/* unused harmony export isIterable */
/* unused harmony export equalArraysWith */
/* harmony export (immutable) */ __webpack_exports__["j"] = equalArrays;
/* harmony export (immutable) */ __webpack_exports__["k"] = equals;
/* harmony export (immutable) */ __webpack_exports__["e"] = compareDates;
/* harmony export (immutable) */ __webpack_exports__["f"] = comparePrimitives;
/* unused harmony export compareArraysWith */
/* harmony export (immutable) */ __webpack_exports__["d"] = compareArrays;
/* unused harmony export compareObjects */
/* harmony export (immutable) */ __webpack_exports__["c"] = compare;
/* unused harmony export min */
/* harmony export (immutable) */ __webpack_exports__["n"] = max;
/* harmony export (immutable) */ __webpack_exports__["h"] = createAtom;
/* unused harmony export createObj */
/* unused harmony export jsOptions */
/* unused harmony export round */
/* unused harmony export sign */
/* unused harmony export randomNext */
/* unused harmony export unescapeDataString */
/* unused harmony export escapeDataString */
/* unused harmony export escapeUriString */
/* unused harmony export count */
/* unused harmony export clear */
/* unused harmony export uncurry */
/* unused harmony export curry */
/* unused harmony export partialApply */
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_is_iterable__ = __webpack_require__(73);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_is_iterable___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_is_iterable__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_typeof__ = __webpack_require__(67);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_typeof___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_typeof__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_weak_map__ = __webpack_require__(117);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_weak_map___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_weak_map__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_babel_runtime_helpers_createClass__ = __webpack_require__(52);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_babel_runtime_helpers_createClass___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_babel_runtime_helpers_createClass__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_object_assign__ = __webpack_require__(130);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_object_assign___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_object_assign__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_babel_runtime_helpers_classCallCheck__ = __webpack_require__(54);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_babel_runtime_helpers_classCallCheck___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5_babel_runtime_helpers_classCallCheck__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_babel_runtime_core_js_object_get_own_property_descriptor__ = __webpack_require__(133);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_babel_runtime_core_js_object_get_own_property_descriptor___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_6_babel_runtime_core_js_object_get_own_property_descriptor__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7_babel_runtime_core_js_object_define_property__ = __webpack_require__(53);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7_babel_runtime_core_js_object_define_property___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_7_babel_runtime_core_js_object_define_property__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8_babel_runtime_core_js_object_keys__ = __webpack_require__(78);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8_babel_runtime_core_js_object_keys___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_8_babel_runtime_core_js_object_keys__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9_babel_runtime_core_js_get_iterator__ = __webpack_require__(21);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9_babel_runtime_core_js_get_iterator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_9_babel_runtime_core_js_get_iterator__);










// tslint:disable:ban-types
// Object.assign flattens getters and setters
// See https://stackoverflow.com/questions/37054596/js-es5-how-to-assign-objects-with-setters-and-getters
function extend(target) {
    for (var _len = arguments.length, sources = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
        sources[_key - 1] = arguments[_key];
    }

    var _iteratorNormalCompletion = true;
    var _didIteratorError = false;
    var _iteratorError = undefined;

    try {
        for (var _iterator = __WEBPACK_IMPORTED_MODULE_9_babel_runtime_core_js_get_iterator___default()(sources), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
            var source = _step.value;
            var _iteratorNormalCompletion2 = true;
            var _didIteratorError2 = false;
            var _iteratorError2 = undefined;

            try {
                for (var _iterator2 = __WEBPACK_IMPORTED_MODULE_9_babel_runtime_core_js_get_iterator___default()(__WEBPACK_IMPORTED_MODULE_8_babel_runtime_core_js_object_keys___default()(source)), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
                    var key = _step2.value;

                    __WEBPACK_IMPORTED_MODULE_7_babel_runtime_core_js_object_define_property___default()(target, key, __WEBPACK_IMPORTED_MODULE_6_babel_runtime_core_js_object_get_own_property_descriptor___default()(source, key));
                }
            } catch (err) {
                _didIteratorError2 = true;
                _iteratorError2 = err;
            } finally {
                try {
                    if (!_iteratorNormalCompletion2 && _iterator2.return) {
                        _iterator2.return();
                    }
                } finally {
                    if (_didIteratorError2) {
                        throw _iteratorError2;
                    }
                }
            }
        }
    } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
    } finally {
        try {
            if (!_iteratorNormalCompletion && _iterator.return) {
                _iterator.return();
            }
        } finally {
            if (_didIteratorError) {
                throw _iteratorError;
            }
        }
    }

    return target;
}
function isDisposable(x) {
    return x != null && typeof x.Dispose === "function";
}
var Comparer = function Comparer(f) {
    __WEBPACK_IMPORTED_MODULE_5_babel_runtime_helpers_classCallCheck___default()(this, Comparer);

    this.Compare = f || compare;
};
function comparerFromEqualityComparer(comparer) {
    // Sometimes IEqualityComparer also implements IComparer
    if (typeof comparer.Compare === "function") {
        return new Comparer(comparer.Compare);
    } else {
        return new Comparer(function (x, y) {
            var xhash = comparer.GetHashCode(x);
            var yhash = comparer.GetHashCode(y);
            if (xhash === yhash) {
                return comparer.Equals(x, y) ? 0 : -1;
            } else {
                return xhash < yhash ? -1 : 1;
            }
        });
    }
}
// TODO: Move these three methods to Map and Set modules
function containsValue(v, map) {
    var _iteratorNormalCompletion3 = true;
    var _didIteratorError3 = false;
    var _iteratorError3 = undefined;

    try {
        for (var _iterator3 = __WEBPACK_IMPORTED_MODULE_9_babel_runtime_core_js_get_iterator___default()(map), _step3; !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true) {
            var kv = _step3.value;

            if (equals(v, kv[1])) {
                return true;
            }
        }
    } catch (err) {
        _didIteratorError3 = true;
        _iteratorError3 = err;
    } finally {
        try {
            if (!_iteratorNormalCompletion3 && _iterator3.return) {
                _iterator3.return();
            }
        } finally {
            if (_didIteratorError3) {
                throw _iteratorError3;
            }
        }
    }

    return false;
}
function tryGetValue(map, key, defaultValue) {
    return map.has(key) ? [true, map.get(key)] : [false, defaultValue];
}
function addToSet(v, set) {
    if (set.has(v)) {
        return false;
    }
    set.add(v);
    return true;
}
function assertEqual(actual, expected, msg) {
    if (!equals(actual, expected)) {
        throw __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_object_assign___default()(new Error(msg || "Expected: " + expected + " - Actual: " + actual), {
            actual: actual,
            expected: expected
        });
    }
}
function assertNotEqual(actual, expected, msg) {
    if (equals(actual, expected)) {
        throw __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_object_assign___default()(new Error(msg || "Expected: " + expected + " - Actual: " + actual), {
            actual: actual,
            expected: expected
        });
    }
}
var Lazy = function () {
    function Lazy(factory) {
        __WEBPACK_IMPORTED_MODULE_5_babel_runtime_helpers_classCallCheck___default()(this, Lazy);

        this.factory = factory;
        this.isValueCreated = false;
    }

    __WEBPACK_IMPORTED_MODULE_3_babel_runtime_helpers_createClass___default()(Lazy, [{
        key: "Value",
        get: function get() {
            if (!this.isValueCreated) {
                this.createdValue = this.factory();
                this.isValueCreated = true;
            }
            return this.createdValue;
        }
    }, {
        key: "IsValueCreated",
        get: function get() {
            return this.isValueCreated;
        }
    }]);

    return Lazy;
}();
function lazyFromValue(v) {
    return new Lazy(function () {
        return v;
    });
}
function padWithZeros(i, length) {
    var str = i.toString(10);
    while (str.length < length) {
        str = "0" + str;
    }
    return str;
}
function dateOffset(date) {
    var date1 = date;
    return typeof date1.offset === "number" ? date1.offset : date.kind === 1 /* UTC */
    ? 0 : date.getTimezoneOffset() * -60000;
}
function int16ToString(i, radix) {
    i = i < 0 && radix != null && radix !== 10 ? 0xFFFF + i + 1 : i;
    return i.toString(radix);
}
function int32ToString(i, radix) {
    i = i < 0 && radix != null && radix !== 10 ? 0xFFFFFFFF + i + 1 : i;
    return i.toString(radix);
}
var ObjectRef = function () {
    function ObjectRef() {
        __WEBPACK_IMPORTED_MODULE_5_babel_runtime_helpers_classCallCheck___default()(this, ObjectRef);
    }

    __WEBPACK_IMPORTED_MODULE_3_babel_runtime_helpers_createClass___default()(ObjectRef, null, [{
        key: "id",
        value: function id(o) {
            if (!ObjectRef.idMap.has(o)) {
                ObjectRef.idMap.set(o, ++ObjectRef.count);
            }
            return ObjectRef.idMap.get(o);
        }
    }]);

    return ObjectRef;
}();
ObjectRef.idMap = new __WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_weak_map___default.a();
ObjectRef.count = 0;
function stringHash(s) {
    var i = 0;
    var h = 5381;
    var len = s.length;
    while (i < len) {
        h = h * 33 ^ s.charCodeAt(i++);
    }
    return h;
}
function numberHash(x) {
    return x * 2654435761 | 0;
}
// From https://stackoverflow.com/a/37449594
function combineHashCodes(hashes) {
    if (hashes.length === 0) {
        return 0;
    }
    return hashes.reduce(function (h1, h2) {
        return (h1 << 5) + h1 ^ h2;
    });
}
function identityHash(x) {
    if (x == null) {
        return 0;
    }
    switch (typeof x === "undefined" ? "undefined" : __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_typeof___default()(x)) {
        case "boolean":
            return x ? 1 : 0;
        case "number":
            return numberHash(x);
        case "string":
            return stringHash(x);
        default:
            return numberHash(ObjectRef.id(x));
    }
}
function structuralHash(x) {
    if (x == null) {
        return 0;
    }
    switch (typeof x === "undefined" ? "undefined" : __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_typeof___default()(x)) {
        case "boolean":
            return x ? 1 : 0;
        case "number":
            return numberHash(x);
        case "string":
            return stringHash(x);
        default:
            {
                if (typeof x.GetHashCode === "function") {
                    return x.GetHashCode();
                } else if (isArray(x)) {
                    var ar = x;
                    var len = ar.length;
                    var hashes = new Array(len);
                    for (var i = 0; i < len; i++) {
                        hashes[i] = structuralHash(ar[i]);
                    }
                    return combineHashCodes(hashes);
                } else {
                    return stringHash(String(x));
                }
            }
    }
}
function isArray(x) {
    return Array.isArray(x) || ArrayBuffer.isView(x);
}
function isIterable(x) {
    return x != null && (typeof x === "undefined" ? "undefined" : __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_typeof___default()(x)) === "object" && __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_is_iterable___default()(x);
}
function equalArraysWith(x, y, eq) {
    if (x == null) {
        return y == null;
    }
    if (y == null) {
        return false;
    }
    if (x.length !== y.length) {
        return false;
    }
    for (var i = 0; i < x.length; i++) {
        if (!eq(x[i], y[i])) {
            return false;
        }
    }
    return true;
}
function equalArrays(x, y) {
    return equalArraysWith(x, y, equals);
}
// export function equalObjects(x: { [k: string]: any }, y: { [k: string]: any }): boolean {
//   if (x == null) { return y == null; }
//   if (y == null) { return false; }
//   const xKeys = Object.keys(x);
//   const yKeys = Object.keys(y);
//   if (xKeys.length !== yKeys.length) {
//     return false;
//   }
//   xKeys.sort();
//   yKeys.sort();
//   for (let i = 0; i < xKeys.length; i++) {
//     if (xKeys[i] !== yKeys[i] || !equals(x[xKeys[i]], y[yKeys[i]])) {
//       return false;
//     }
//   }
//   return true;
// }
function equals(x, y) {
    if (x === y) {
        return true;
    } else if (x == null) {
        return y == null;
    } else if (y == null) {
        return false;
    } else if ((typeof x === "undefined" ? "undefined" : __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_typeof___default()(x)) !== "object") {
        return false;
    } else if (typeof x.Equals === "function") {
        return x.Equals(y);
    } else if (isArray(x)) {
        return isArray(y) && equalArrays(x, y);
    } else if (x instanceof Date) {
        return y instanceof Date && compareDates(x, y) === 0;
    } else {
        return false;
    }
}
function compareDates(x, y) {
    var xtime = void 0;
    var ytime = void 0;
    // DateTimeOffset and DateTime deals with equality differently.
    if ("offset" in x && "offset" in y) {
        xtime = x.getTime();
        ytime = y.getTime();
    } else {
        xtime = x.getTime() + dateOffset(x);
        ytime = y.getTime() + dateOffset(y);
    }
    return xtime === ytime ? 0 : xtime < ytime ? -1 : 1;
}
function comparePrimitives(x, y) {
    return x === y ? 0 : x < y ? -1 : 1;
}
function compareArraysWith(x, y, comp) {
    if (x == null) {
        return y == null ? 0 : 1;
    }
    if (y == null) {
        return -1;
    }
    if (x.length !== y.length) {
        return x.length < y.length ? -1 : 1;
    }
    for (var i = 0, j = 0; i < x.length; i++) {
        j = comp(x[i], y[i]);
        if (j !== 0) {
            return j;
        }
    }
    return 0;
}
function compareArrays(x, y) {
    return compareArraysWith(x, y, compare);
}
function compareObjects(x, y) {
    if (x == null) {
        return y == null ? 0 : 1;
    }
    if (y == null) {
        return -1;
    }
    var xKeys = __WEBPACK_IMPORTED_MODULE_8_babel_runtime_core_js_object_keys___default()(x);
    var yKeys = __WEBPACK_IMPORTED_MODULE_8_babel_runtime_core_js_object_keys___default()(y);
    if (xKeys.length !== yKeys.length) {
        return xKeys.length < yKeys.length ? -1 : 1;
    }
    xKeys.sort();
    yKeys.sort();
    for (var i = 0, j = 0; i < xKeys.length; i++) {
        var key = xKeys[i];
        if (key !== yKeys[i]) {
            return key < yKeys[i] ? -1 : 1;
        } else {
            j = compare(x[key], y[key]);
            if (j !== 0) {
                return j;
            }
        }
    }
    return 0;
}
function compare(x, y) {
    if (x === y) {
        return 0;
    } else if (x == null) {
        return y == null ? 0 : -1;
    } else if (y == null) {
        return 1;
    } else if ((typeof x === "undefined" ? "undefined" : __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_typeof___default()(x)) !== "object") {
        return x < y ? -1 : 1;
    } else if (typeof x.CompareTo === "function") {
        return x.CompareTo(y);
    } else if (isArray(x)) {
        return isArray(y) && compareArrays(x, y);
    } else if (x instanceof Date) {
        return y instanceof Date && compareDates(x, y);
    } else {
        return 1;
    }
}
function min(comparer, x, y) {
    return comparer(x, y) < 0 ? x : y;
}
function max(comparer, x, y) {
    return comparer(x, y) > 0 ? x : y;
}
function createAtom(value) {
    var atom = value;
    return function (value) {
        if (value === void 0) {
            return atom;
        } else {
            atom = value;
            return void 0;
        }
    };
}
var CaseRules = {
    None: 0,
    LowerFirst: 1
};
function changeCase(str, caseRule) {
    switch (caseRule) {
        case CaseRules.LowerFirst:
            return str.charAt(0).toLowerCase() + str.slice(1);
        case CaseRules.None:
        default:
            return str;
    }
}
function createObj(fields) {
    var caseRule = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : CaseRules.None;

    function fail(kvPair) {
        throw new Error("Cannot infer key and value of " + String(kvPair));
    }
    var o = {};
    var definedCaseRule = caseRule;
    var _iteratorNormalCompletion4 = true;
    var _didIteratorError4 = false;
    var _iteratorError4 = undefined;

    try {
        for (var _iterator4 = __WEBPACK_IMPORTED_MODULE_9_babel_runtime_core_js_get_iterator___default()(fields), _step4; !(_iteratorNormalCompletion4 = (_step4 = _iterator4.next()).done); _iteratorNormalCompletion4 = true) {
            var kvPair = _step4.value;

            var _caseRule = CaseRules.None;
            if (kvPair == null) {
                fail(kvPair);
            }
            // Deflate unions and use the defined case rule
            if (typeof kvPair.toJSON === "function") {
                kvPair = kvPair.toJSON();
                _caseRule = definedCaseRule;
            }
            if (Array.isArray(kvPair)) {
                switch (kvPair.length) {
                    case 0:
                        fail(kvPair);
                        break;
                    case 1:
                        o[changeCase(kvPair[0], _caseRule)] = true;
                        break;
                    case 2:
                        var value = kvPair[1];
                        o[changeCase(kvPair[0], _caseRule)] = value;
                        break;
                    default:
                        o[changeCase(kvPair[0], _caseRule)] = kvPair.slice(1);
                }
            } else if (typeof kvPair === "string") {
                o[changeCase(kvPair, _caseRule)] = true;
            } else {
                fail(kvPair);
            }
        }
    } catch (err) {
        _didIteratorError4 = true;
        _iteratorError4 = err;
    } finally {
        try {
            if (!_iteratorNormalCompletion4 && _iterator4.return) {
                _iterator4.return();
            }
        } finally {
            if (_didIteratorError4) {
                throw _iteratorError4;
            }
        }
    }

    return o;
}
function jsOptions(mutator) {
    var opts = {};
    mutator(opts);
    return opts;
}
function round(value) {
    var digits = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;

    var m = Math.pow(10, digits);
    var n = +(digits ? value * m : value).toFixed(8);
    var i = Math.floor(n);
    var f = n - i;
    var e = 1e-8;
    var r = f > 0.5 - e && f < 0.5 + e ? i % 2 === 0 ? i : i + 1 : Math.round(n);
    return digits ? r / m : r;
}
function sign(x) {
    return x > 0 ? 1 : x < 0 ? -1 : 0;
}
function randomNext(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
}
function unescapeDataString(s) {
    // https://stackoverflow.com/a/4458580/524236
    return decodeURIComponent(s.replace(/\+/g, "%20"));
}
function escapeDataString(s) {
    return encodeURIComponent(s).replace(/!/g, "%21").replace(/'/g, "%27").replace(/\(/g, "%28").replace(/\)/g, "%29").replace(/\*/g, "%2A");
}
function escapeUriString(s) {
    return encodeURI(s);
}
// ICollection.Clear and Count members can be called on Arrays
// or Dictionaries so we need a runtime check (see #1120)
function count(col) {
    return isArray(col) ? col.length : col.size;
}
function clear(col) {
    if (isArray(col)) {
        col.splice(0);
    } else {
        col.clear();
    }
}
function uncurry(arity, f) {
    // f may be a function option with None value
    if (f == null) {
        return null;
    }
    // return (...args: any[]) => {
    //   // In some cases there may be more arguments applied than necessary
    //   // (e.g. index when mapping an array), discard them
    //   args = args.slice(0, arity);
    //   let res = f;
    //   while (args.length > 0) {
    //       const curArgs = args.splice(0, res.length);
    //       res = res.apply(null, curArgs);
    //   }
    //   return res;
    // };
    switch (arity) {
        case 2:
            return function (a1, a2) {
                return f(a1)(a2);
            };
        case 3:
            return function (a1, a2, a3) {
                return f(a1)(a2)(a3);
            };
        case 4:
            return function (a1, a2, a3, a4) {
                return f(a1)(a2)(a3)(a4);
            };
        case 5:
            return function (a1, a2, a3, a4, a5) {
                return f(a1)(a2)(a3)(a4)(a5);
            };
        case 6:
            return function (a1, a2, a3, a4, a5, a6) {
                return f(a1)(a2)(a3)(a4)(a5)(a6);
            };
        case 7:
            return function (a1, a2, a3, a4, a5, a6, a7) {
                return f(a1)(a2)(a3)(a4)(a5)(a6)(a7);
            };
        case 8:
            return function (a1, a2, a3, a4, a5, a6, a7, a8) {
                return f(a1)(a2)(a3)(a4)(a5)(a6)(a7)(a8);
            };
        default:
            throw new Error("Uncurrying to more than 8-arity is not supported: " + arity);
    }
}
function curry(arity, f) {
    if (f == null) {
        return null;
    }
    switch (arity) {
        case 2:
            return function (a1) {
                return function (a2) {
                    return f(a1, a2);
                };
            };
        case 3:
            return function (a1) {
                return function (a2) {
                    return function (a3) {
                        return f(a1, a2, a3);
                    };
                };
            };
        case 4:
            return function (a1) {
                return function (a2) {
                    return function (a3) {
                        return function (a4) {
                            return f(a1, a2, a3, a4);
                        };
                    };
                };
            };
        case 5:
            return function (a1) {
                return function (a2) {
                    return function (a3) {
                        return function (a4) {
                            return function (a5) {
                                return f(a1, a2, a3, a4, a5);
                            };
                        };
                    };
                };
            };
        case 6:
            return function (a1) {
                return function (a2) {
                    return function (a3) {
                        return function (a4) {
                            return function (a5) {
                                return function (a6) {
                                    return f(a1, a2, a3, a4, a5, a6);
                                };
                            };
                        };
                    };
                };
            };
        case 7:
            return function (a1) {
                return function (a2) {
                    return function (a3) {
                        return function (a4) {
                            return function (a5) {
                                return function (a6) {
                                    return function (a7) {
                                        return f(a1, a2, a3, a4, a5, a6, a7);
                                    };
                                };
                            };
                        };
                    };
                };
            };
        case 8:
            return function (a1) {
                return function (a2) {
                    return function (a3) {
                        return function (a4) {
                            return function (a5) {
                                return function (a6) {
                                    return function (a7) {
                                        return function (a8) {
                                            return f(a1, a2, a3, a4, a5, a6, a7, a8);
                                        };
                                    };
                                };
                            };
                        };
                    };
                };
            };
        default:
            throw new Error("Currying to more than 8-arity is not supported: " + arity);
    }
}
function partialApply(arity, f, args) {
    if (f == null) {
        return null;
    } else {
        switch (arity) {
            case 1:
                // Wrap arguments to make sure .concat doesn't destruct arrays. Example
                // [1,2].concat([3,4],5)   --> [1,2,3,4,5]    // fails
                // [1,2].concat([[3,4],5]) --> [1,2,[3,4],5]  // ok
                return function (a1) {
                    return f.apply(null, args.concat([a1]));
                };
            case 2:
                return function (a1) {
                    return function (a2) {
                        return f.apply(null, args.concat([a1, a2]));
                    };
                };
            case 3:
                return function (a1) {
                    return function (a2) {
                        return function (a3) {
                            return f.apply(null, args.concat([a1, a2, a3]));
                        };
                    };
                };
            case 4:
                return function (a1) {
                    return function (a2) {
                        return function (a3) {
                            return function (a4) {
                                return f.apply(null, args.concat([a1, a2, a3, a4]));
                            };
                        };
                    };
                };
            case 5:
                return function (a1) {
                    return function (a2) {
                        return function (a3) {
                            return function (a4) {
                                return function (a5) {
                                    return f.apply(null, args.concat([a1, a2, a3, a4, a5]));
                                };
                            };
                        };
                    };
                };
            case 6:
                return function (a1) {
                    return function (a2) {
                        return function (a3) {
                            return function (a4) {
                                return function (a5) {
                                    return function (a6) {
                                        return f.apply(null, args.concat([a1, a2, a3, a4, a5, a6]));
                                    };
                                };
                            };
                        };
                    };
                };
            case 7:
                return function (a1) {
                    return function (a2) {
                        return function (a3) {
                            return function (a4) {
                                return function (a5) {
                                    return function (a6) {
                                        return function (a7) {
                                            return f.apply(null, args.concat([a1, a2, a3, a4, a5, a6, a7]));
                                        };
                                    };
                                };
                            };
                        };
                    };
                };
            case 8:
                return function (a1) {
                    return function (a2) {
                        return function (a3) {
                            return function (a4) {
                                return function (a5) {
                                    return function (a6) {
                                        return function (a7) {
                                            return function (a8) {
                                                return f.apply(null, args.concat([a1, a2, a3, a4, a5, a6, a7, a8]));
                                            };
                                        };
                                    };
                                };
                            };
                        };
                    };
                };
            default:
                throw new Error("Partially applying to more than 8-arity is not supported: " + arity);
        }
    }
}

/***/ }),
/* 4 */
/***/ (function(module, exports) {

module.exports = function (it) {
  return typeof it === 'object' ? it !== null : typeof it === 'function';
};


/***/ }),
/* 5 */
/***/ (function(module, exports) {

// https://github.com/zloirock/core-js/issues/86#issuecomment-115759028
var global = module.exports = typeof window != 'undefined' && window.Math == Math
  ? window : typeof self != 'undefined' && self.Math == Math ? self
  // eslint-disable-next-line no-new-func
  : Function('return this')();
if (typeof __g == 'number') __g = global; // eslint-disable-line no-undef


/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

var anObject = __webpack_require__(8);
var IE8_DOM_DEFINE = __webpack_require__(60);
var toPrimitive = __webpack_require__(36);
var dP = Object.defineProperty;

exports.f = __webpack_require__(9) ? Object.defineProperty : function defineProperty(O, P, Attributes) {
  anObject(O);
  P = toPrimitive(P, true);
  anObject(Attributes);
  if (IE8_DOM_DEFINE) try {
    return dP(O, P, Attributes);
  } catch (e) { /* empty */ }
  if ('get' in Attributes || 'set' in Attributes) throw TypeError('Accessors not supported!');
  if ('value' in Attributes) O[P] = Attributes.value;
  return O;
};


/***/ }),
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

var dP = __webpack_require__(6);
var createDesc = __webpack_require__(18);
module.exports = __webpack_require__(9) ? function (object, key, value) {
  return dP.f(object, key, createDesc(1, value));
} : function (object, key, value) {
  object[key] = value;
  return object;
};


/***/ }),
/* 8 */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(4);
module.exports = function (it) {
  if (!isObject(it)) throw TypeError(it + ' is not an object!');
  return it;
};


/***/ }),
/* 9 */
/***/ (function(module, exports, __webpack_require__) {

// Thank's IE8 for his funny defineProperty
module.exports = !__webpack_require__(10)(function () {
  return Object.defineProperty({}, 'a', { get: function () { return 7; } }).a != 7;
});


/***/ }),
/* 10 */
/***/ (function(module, exports) {

module.exports = function (exec) {
  try {
    return !!exec();
  } catch (e) {
    return true;
  }
};


/***/ }),
/* 11 */
/***/ (function(module, exports) {

var hasOwnProperty = {}.hasOwnProperty;
module.exports = function (it, key) {
  return hasOwnProperty.call(it, key);
};


/***/ }),
/* 12 */
/***/ (function(module, exports, __webpack_require__) {

// to indexed object, toObject with fallback for non-array-like ES3 strings
var IObject = __webpack_require__(39);
var defined = __webpack_require__(34);
module.exports = function (it) {
  return IObject(defined(it));
};


/***/ }),
/* 13 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(87), __esModule: true };

/***/ }),
/* 14 */
/***/ (function(module, exports) {

module.exports = {};


/***/ }),
/* 15 */
/***/ (function(module, exports, __webpack_require__) {

// 7.1.13 ToObject(argument)
var defined = __webpack_require__(34);
module.exports = function (it) {
  return Object(defined(it));
};


/***/ }),
/* 16 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["e"] = declare;
/* unused harmony export SystemObject */
/* harmony export (immutable) */ __webpack_exports__["b"] = List;
/* harmony export (immutable) */ __webpack_exports__["d"] = Union;
/* harmony export (immutable) */ __webpack_exports__["c"] = Record;
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return FSharpRef; });
/* unused harmony export Exception */
/* unused harmony export isException */
/* unused harmony export FSharpException */
/* unused harmony export MatchFailureException */
/* unused harmony export Attribute */
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_symbol_iterator__ = __webpack_require__(20);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_symbol_iterator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_symbol_iterator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_array_from__ = __webpack_require__(13);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_array_from___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_array_from__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_object_keys__ = __webpack_require__(78);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_object_keys___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_object_keys__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_babel_runtime_core_js_object_create__ = __webpack_require__(142);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_babel_runtime_core_js_object_create___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_babel_runtime_core_js_object_create__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_object_get_prototype_of__ = __webpack_require__(145);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_object_get_prototype_of___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_object_get_prototype_of__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__Util__ = __webpack_require__(3);






function sameType(x, y) {
    return y != null && __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_object_get_prototype_of___default()(x).constructor === __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_object_get_prototype_of___default()(y).constructor;
}
// Taken from Babel helpers
function inherits(subClass, superClass) {
    // if (typeof superClass !== "function" && superClass !== null) {
    //   throw new TypeError(
    //     "Super expression must either be null or a function, not " +
    //       typeof superClass
    //   );
    // }
    subClass.prototype = __WEBPACK_IMPORTED_MODULE_3_babel_runtime_core_js_object_create___default()(superClass && superClass.prototype, {
        constructor: {
            value: subClass,
            enumerable: false,
            writable: true,
            configurable: true
        }
    });
    // if (superClass)
    //   Object.setPrototypeOf
    //     ? Object.setPrototypeOf(subClass, superClass)
    //     : (subClass.__proto__ = superClass);
}
function declare(cons, superClass) {
    inherits(cons, superClass || SystemObject);
    return cons;
}
function SystemObject() {}
SystemObject.prototype.toString = function () {
    var _this = this;

    return "{" + __WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_object_keys___default()(this).map(function (k) {
        return k + " = " + String(_this[k]);
    }).join(";\n ") + "}";
};
SystemObject.prototype.GetHashCode = function () {
    return Object(__WEBPACK_IMPORTED_MODULE_5__Util__["l" /* identityHash */])(this);
};
SystemObject.prototype.Equals = function (other) {
    return this === other;
};
function compareList(self, other) {
    if (self === other) {
        return 0;
    } else {
        if (other == null) {
            return -1;
        }
        while (self.tail != null) {
            if (other.tail == null) {
                return 1;
            }
            var res = Object(__WEBPACK_IMPORTED_MODULE_5__Util__["c" /* compare */])(self.head, other.head);
            if (res !== 0) {
                return res;
            }
            self = self.tail;
            other = other.tail;
        }
        return other.tail == null ? 0 : -1;
    }
}
function List(head, tail) {
    this.head = head;
    this.tail = tail;
}
List.prototype.toString = function () {
    return "[" + __WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_array_from___default()(this).map(function (x) {
        return String(x);
    }).join("; ") + "]";
};
List.prototype.toJSON = function () {
    return __WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_array_from___default()(this);
};
List.prototype[__WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_symbol_iterator___default.a] = function () {
    var cur = this;
    return {
        next: function next() {
            var tmp = cur;
            cur = cur.tail;
            return { done: tmp.tail == null, value: tmp.head };
        }
    };
};
List.prototype.GetHashCode = function () {
    var hashes = __WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_array_from___default()(this).map(__WEBPACK_IMPORTED_MODULE_5__Util__["q" /* structuralHash */]);
    return Object(__WEBPACK_IMPORTED_MODULE_5__Util__["b" /* combineHashCodes */])(hashes);
};
List.prototype.Equals = function (other) {
    return compareList(this, other) === 0;
};
List.prototype.CompareTo = function (other) {
    return compareList(this, other);
};
function Union(tag, name) {
    this.tag = tag | 0;
    this.name = name;

    for (var _len = arguments.length, fields = Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++) {
        fields[_key - 2] = arguments[_key];
    }

    this.fields = fields;
}
Union.prototype.toString = function () {
    var len = this.fields.length;
    if (len === 0) {
        return this.name;
    } else if (len === 1) {
        return this.name + " " + String(this.fields[0]);
    } else {
        return this.name + " (" + this.fields.map(function (x) {
            return String(x);
        }).join(",") + ")";
    }
};
Union.prototype.toJSON = function () {
    return this.fields.length === 0 ? this.name : [this.name].concat(this.fields);
};
Union.prototype.GetHashCode = function () {
    var hashes = this.fields.map(function (x) {
        return Object(__WEBPACK_IMPORTED_MODULE_5__Util__["q" /* structuralHash */])(x);
    });
    hashes.splice(0, 0, Object(__WEBPACK_IMPORTED_MODULE_5__Util__["o" /* numberHash */])(this.tag));
    return Object(__WEBPACK_IMPORTED_MODULE_5__Util__["b" /* combineHashCodes */])(hashes);
};
Union.prototype.Equals = function (other) {
    return this === other || sameType(this, other) && this.tag === other.tag && Object(__WEBPACK_IMPORTED_MODULE_5__Util__["j" /* equalArrays */])(this.fields, other.fields);
};
Union.prototype.CompareTo = function (other) {
    if (this === other) {
        return 0;
    } else if (!sameType(this, other)) {
        return -1;
    } else if (this.tag === other.tag) {
        return Object(__WEBPACK_IMPORTED_MODULE_5__Util__["d" /* compareArrays */])(this.fields, other.fields);
    } else {
        return this.tag < other.tag ? -1 : 1;
    }
};
function recordToJson(record, getFieldNames) {
    var o = {};
    var keys = getFieldNames == null ? __WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_object_keys___default()(record) : getFieldNames(record);
    for (var i = 0; i < keys.length; i++) {
        o[keys[i]] = record[keys[i]];
    }
    return o;
}
function recordEquals(self, other, getFieldNames) {
    if (self === other) {
        return true;
    } else if (!sameType(self, other)) {
        return false;
    } else {
        var thisNames = getFieldNames == null ? __WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_object_keys___default()(self) : getFieldNames(self);
        for (var i = 0; i < thisNames.length; i++) {
            if (!Object(__WEBPACK_IMPORTED_MODULE_5__Util__["k" /* equals */])(self[thisNames[i]], other[thisNames[i]])) {
                return false;
            }
        }
        return true;
    }
}
function recordCompare(self, other, getFieldNames) {
    if (self === other) {
        return 0;
    } else if (!sameType(self, other)) {
        return -1;
    } else {
        var thisNames = getFieldNames == null ? __WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_object_keys___default()(self) : getFieldNames(self);
        for (var i = 0; i < thisNames.length; i++) {
            var result = Object(__WEBPACK_IMPORTED_MODULE_5__Util__["c" /* compare */])(self[thisNames[i]], other[thisNames[i]]);
            if (result !== 0) {
                return result;
            }
        }
        return 0;
    }
}
function Record() {}
Record.prototype.toString = function () {
    var _this2 = this;

    return "{" + __WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_object_keys___default()(this).map(function (k) {
        return k + " = " + String(_this2[k]);
    }).join(";\n ") + "}";
};
Record.prototype.toJSON = function () {
    return recordToJson(this);
};
Record.prototype.GetHashCode = function () {
    var _this3 = this;

    var hashes = __WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_object_keys___default()(this).map(function (k) {
        return Object(__WEBPACK_IMPORTED_MODULE_5__Util__["q" /* structuralHash */])(_this3[k]);
    });
    return Object(__WEBPACK_IMPORTED_MODULE_5__Util__["b" /* combineHashCodes */])(hashes);
};
Record.prototype.Equals = function (other) {
    return recordEquals(this, other);
};
Record.prototype.CompareTo = function (other) {
    return recordCompare(this, other);
};
var FSharpRef = declare(function FSharpRef(contents) {
    this.contents = contents;
}, Record);
// EXCEPTIONS
var Exception = declare(function Exception(msg) {
    this.stack = Error().stack;
    this.message = msg;
});
function isException(x) {
    return x instanceof Error || x instanceof Exception;
}
function getFSharpExceptionFieldNames(self) {
    return __WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_object_keys___default()(self).filter(function (k) {
        return k !== "message" && k !== "stack";
    });
}
var FSharpException = declare(function FSharpException() {
    Exception.call(this);
}, Exception);
FSharpException.prototype.toString = function () {
    var _this4 = this;

    var fieldNames = getFSharpExceptionFieldNames(this);
    var len = fieldNames.length;
    if (len === 0) {
        return this.message;
    } else if (len === 1) {
        return this.message + " " + String(this[fieldNames[0]]);
    } else {
        return this.message + " (" + fieldNames.map(function (k) {
            return String(_this4[k]);
        }).join(",") + ")";
    }
};
FSharpException.prototype.toJSON = function () {
    return recordToJson(this, getFSharpExceptionFieldNames);
};
FSharpException.prototype.GetHashCode = function () {
    var _this5 = this;

    var hashes = getFSharpExceptionFieldNames(this).map(function (k) {
        return Object(__WEBPACK_IMPORTED_MODULE_5__Util__["q" /* structuralHash */])(_this5[k]);
    });
    return Object(__WEBPACK_IMPORTED_MODULE_5__Util__["b" /* combineHashCodes */])(hashes);
};
FSharpException.prototype.Equals = function (other) {
    return recordEquals(this, other, getFSharpExceptionFieldNames);
};
FSharpException.prototype.CompareTo = function (other) {
    return recordCompare(this, other, getFSharpExceptionFieldNames);
};
var MatchFailureException = declare(function MatchFailureException(arg1, arg2, arg3) {
    this.arg1 = arg1;
    this.arg2 = arg2 | 0;
    this.arg3 = arg3 | 0;
}, FSharpException);
var Attribute = declare(function Attribute() {});

/***/ }),
/* 17 */
/***/ (function(module, exports, __webpack_require__) {

// optional / simple context binding
var aFunction = __webpack_require__(59);
module.exports = function (fn, that, length) {
  aFunction(fn);
  if (that === undefined) return fn;
  switch (length) {
    case 1: return function (a) {
      return fn.call(that, a);
    };
    case 2: return function (a, b) {
      return fn.call(that, a, b);
    };
    case 3: return function (a, b, c) {
      return fn.call(that, a, b, c);
    };
  }
  return function (/* ...args */) {
    return fn.apply(that, arguments);
  };
};


/***/ }),
/* 18 */
/***/ (function(module, exports) {

module.exports = function (bitmap, value) {
  return {
    enumerable: !(bitmap & 1),
    configurable: !(bitmap & 2),
    writable: !(bitmap & 4),
    value: value
  };
};


/***/ }),
/* 19 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.14 / 15.2.3.14 Object.keys(O)
var $keys = __webpack_require__(62);
var enumBugKeys = __webpack_require__(43);

module.exports = Object.keys || function keys(O) {
  return $keys(O, enumBugKeys);
};


/***/ }),
/* 20 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(97), __esModule: true };

/***/ }),
/* 21 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(108), __esModule: true };

/***/ }),
/* 22 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export Some */
/* harmony export (immutable) */ __webpack_exports__["c"] = some;
/* harmony export (immutable) */ __webpack_exports__["d"] = value;
/* harmony export (immutable) */ __webpack_exports__["b"] = defaultArg;
/* unused harmony export defaultArgWith */
/* unused harmony export filter */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Choice; });
/* unused harmony export choice1 */
/* unused harmony export choice2 */
/* unused harmony export tryValueIfChoice1 */
/* unused harmony export tryValueIfChoice2 */
/* unused harmony export Result */
/* unused harmony export ok */
/* unused harmony export error */
/* unused harmony export mapOk */
/* unused harmony export mapError */
/* unused harmony export bindOk */
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_helpers_classCallCheck__ = __webpack_require__(54);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_helpers_classCallCheck___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_babel_runtime_helpers_classCallCheck__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_createClass__ = __webpack_require__(52);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_createClass___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_createClass__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__Types__ = __webpack_require__(16);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__Util__ = __webpack_require__(3);




// Options are erased in runtime by Fable, but we have
// the `Some` type below to wrap values that would evaluate
// to null in runtime. These two rules must be followed:
// 1- None is always null in runtime, a non-strict null check
//    (`x == null`) is enough to check the case of an option.
// 2- To get the value of an option the `getValue` helper
//    below must **always** be used.
// export type Option<T> = T | Some<T>;
// Using a class here for better compatibility with TS files importing Some
var Some = function () {
    function Some(value) {
        __WEBPACK_IMPORTED_MODULE_0_babel_runtime_helpers_classCallCheck___default()(this, Some);

        this.value = value;
    }
    // Don't add "Some" for consistency with erased options


    __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_createClass___default()(Some, [{
        key: "toString",
        value: function toString() {
            return String(this.value);
        }
    }, {
        key: "toJSON",
        value: function toJSON() {
            return this.value;
        }
    }, {
        key: "GetHashCode",
        value: function GetHashCode() {
            return Object(__WEBPACK_IMPORTED_MODULE_3__Util__["q" /* structuralHash */])(this.value);
        }
    }, {
        key: "Equals",
        value: function Equals(other) {
            return other == null ? false : Object(__WEBPACK_IMPORTED_MODULE_3__Util__["k" /* equals */])(this.value, other instanceof Some ? other.value : other);
        }
    }, {
        key: "CompareTo",
        value: function CompareTo(other) {
            return other == null ? 1 : Object(__WEBPACK_IMPORTED_MODULE_3__Util__["c" /* compare */])(this.value, other instanceof Some ? other.value : other);
        }
    }]);

    return Some;
}();
function some(x) {
    return x == null || x instanceof Some ? new Some(x) : x;
}
function value(x, acceptNull) {
    if (x == null) {
        if (!acceptNull) {
            throw new Error("Option has no value");
        }
        return null;
    } else {
        return x instanceof Some ? x.value : x;
    }
}
function defaultArg(arg, defaultValue, f) {
    return arg == null ? defaultValue : f != null ? f(value(arg)) : value(arg);
}
function defaultArgWith(arg, defThunk) {
    return arg == null ? defThunk() : value(arg);
}
function filter(predicate, arg) {
    return arg != null ? !predicate(value(arg)) ? null : arg : arg;
}
// CHOICE
var Choice = Object(__WEBPACK_IMPORTED_MODULE_2__Types__["e" /* declare */])(function Choice(tag, name, field) {
    __WEBPACK_IMPORTED_MODULE_2__Types__["d" /* Union */].call(this, tag, name, field);
}, __WEBPACK_IMPORTED_MODULE_2__Types__["d" /* Union */]);
function choice1(x) {
    return new Choice(0, "Choice1Of2", x);
}
function choice2(x) {
    return new Choice(1, "Choice2Of2", x);
}
function tryValueIfChoice1(x) {
    return x.tag === 0 ? some(x.fields[0]) : null;
}
function tryValueIfChoice2(x) {
    return x.tag === 1 ? some(x.fields[0]) : null;
}
// RESULT
var Result = Object(__WEBPACK_IMPORTED_MODULE_2__Types__["e" /* declare */])(function Result(tag, name, field) {
    __WEBPACK_IMPORTED_MODULE_2__Types__["d" /* Union */].call(this, tag, name, field);
}, __WEBPACK_IMPORTED_MODULE_2__Types__["d" /* Union */]);
function ok(x) {
    return new Result(0, "Ok", x);
}
function error(x) {
    return new Result(1, "Error", x);
}
function mapOk(f, result) {
    return result.tag === 0 ? ok(f(result.fields[0])) : result;
}
function mapError(f, result) {
    return result.tag === 1 ? error(f(result.fields[0])) : result;
}
function bindOk(f, result) {
    return result.tag === 0 ? f(result.fields[0]) : result;
}

/***/ }),
/* 23 */
/***/ (function(module, exports) {

module.exports = require("fs");

/***/ }),
/* 24 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $at = __webpack_require__(88)(true);

// 21.1.3.27 String.prototype[@@iterator]()
__webpack_require__(58)(String, 'String', function (iterated) {
  this._t = String(iterated); // target
  this._i = 0;                // next index
// 21.1.5.2.1 %StringIteratorPrototype%.next()
}, function () {
  var O = this._t;
  var index = this._i;
  var point;
  if (index >= O.length) return { value: undefined, done: true };
  point = $at(O, index);
  this._i += point.length;
  return { value: point, done: false };
});


/***/ }),
/* 25 */
/***/ (function(module, exports, __webpack_require__) {

// 7.1.15 ToLength
var toInteger = __webpack_require__(33);
var min = Math.min;
module.exports = function (it) {
  return it > 0 ? min(toInteger(it), 0x1fffffffffffff) : 0; // pow(2, 53) - 1 == 9007199254740991
};


/***/ }),
/* 26 */
/***/ (function(module, exports) {

var id = 0;
var px = Math.random();
module.exports = function (key) {
  return 'Symbol('.concat(key === undefined ? '' : key, ')_', (++id + px).toString(36));
};


/***/ }),
/* 27 */
/***/ (function(module, exports, __webpack_require__) {

var def = __webpack_require__(6).f;
var has = __webpack_require__(11);
var TAG = __webpack_require__(1)('toStringTag');

module.exports = function (it, tag, stat) {
  if (it && !has(it = stat ? it : it.prototype, TAG)) def(it, TAG, { configurable: true, value: tag });
};


/***/ }),
/* 28 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;

var _from = __webpack_require__(13);

var _from2 = _interopRequireDefault(_from);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = function (arr) {
  if (Array.isArray(arr)) {
    for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) {
      arr2[i] = arr[i];
    }

    return arr2;
  } else {
    return (0, _from2.default)(arr);
  }
};

/***/ }),
/* 29 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(98);
var global = __webpack_require__(5);
var hide = __webpack_require__(7);
var Iterators = __webpack_require__(14);
var TO_STRING_TAG = __webpack_require__(1)('toStringTag');

var DOMIterables = ('CSSRuleList,CSSStyleDeclaration,CSSValueList,ClientRectList,DOMRectList,DOMStringList,' +
  'DOMTokenList,DataTransferItemList,FileList,HTMLAllCollection,HTMLCollection,HTMLFormElement,HTMLSelectElement,' +
  'MediaList,MimeTypeArray,NamedNodeMap,NodeList,PaintRequestList,Plugin,PluginArray,SVGLengthList,SVGNumberList,' +
  'SVGPathSegList,SVGPointList,SVGStringList,SVGTransformList,SourceBufferList,StyleSheetList,TextTrackCueList,' +
  'TextTrackList,TouchList').split(',');

for (var i = 0; i < DOMIterables.length; i++) {
  var NAME = DOMIterables[i];
  var Collection = global[NAME];
  var proto = Collection && Collection.prototype;
  if (proto && !proto[TO_STRING_TAG]) hide(proto, TO_STRING_TAG, NAME);
  Iterators[NAME] = Iterators.Array;
}


/***/ }),
/* 30 */
/***/ (function(module, exports, __webpack_require__) {

var META = __webpack_require__(26)('meta');
var isObject = __webpack_require__(4);
var has = __webpack_require__(11);
var setDesc = __webpack_require__(6).f;
var id = 0;
var isExtensible = Object.isExtensible || function () {
  return true;
};
var FREEZE = !__webpack_require__(10)(function () {
  return isExtensible(Object.preventExtensions({}));
});
var setMeta = function (it) {
  setDesc(it, META, { value: {
    i: 'O' + ++id, // object ID
    w: {}          // weak collections IDs
  } });
};
var fastKey = function (it, create) {
  // return primitive with prefix
  if (!isObject(it)) return typeof it == 'symbol' ? it : (typeof it == 'string' ? 'S' : 'P') + it;
  if (!has(it, META)) {
    // can't set metadata to uncaught frozen object
    if (!isExtensible(it)) return 'F';
    // not necessary to add metadata
    if (!create) return 'E';
    // add missing metadata
    setMeta(it);
  // return object ID
  } return it[META].i;
};
var getWeak = function (it, create) {
  if (!has(it, META)) {
    // can't set metadata to uncaught frozen object
    if (!isExtensible(it)) return true;
    // not necessary to add metadata
    if (!create) return false;
    // add missing metadata
    setMeta(it);
  // return hash weak collections IDs
  } return it[META].w;
};
// add metadata on freeze-family methods calling
var onFreeze = function (it) {
  if (FREEZE && meta.NEED && isExtensible(it) && !has(it, META)) setMeta(it);
  return it;
};
var meta = module.exports = {
  KEY: META,
  NEED: false,
  fastKey: fastKey,
  getWeak: getWeak,
  onFreeze: onFreeze
};


/***/ }),
/* 31 */
/***/ (function(module, exports) {

exports.f = {}.propertyIsEnumerable;


/***/ }),
/* 32 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export Enumerator */
/* harmony export (immutable) */ __webpack_exports__["f"] = getEnumerator;
/* harmony export (immutable) */ __webpack_exports__["l"] = toIterator;
/* unused harmony export ofArray */
/* unused harmony export append */
/* unused harmony export average */
/* unused harmony export averageBy */
/* unused harmony export concat */
/* harmony export (immutable) */ __webpack_exports__["a"] = collect;
/* unused harmony export choose */
/* unused harmony export compareWith */
/* unused harmony export delay */
/* harmony export (immutable) */ __webpack_exports__["b"] = empty;
/* unused harmony export enumerateWhile */
/* unused harmony export enumerateThenFinally */
/* unused harmony export enumerateUsing */
/* unused harmony export exactlyOne */
/* unused harmony export except */
/* unused harmony export exists */
/* unused harmony export exists2 */
/* unused harmony export contains */
/* unused harmony export filter */
/* unused harmony export where */
/* harmony export (immutable) */ __webpack_exports__["c"] = fold;
/* unused harmony export foldBack */
/* harmony export (immutable) */ __webpack_exports__["d"] = fold2;
/* harmony export (immutable) */ __webpack_exports__["e"] = foldBack2;
/* unused harmony export forAll */
/* unused harmony export forAll2 */
/* unused harmony export tryHead */
/* unused harmony export head */
/* unused harmony export initialize */
/* unused harmony export initializeInfinite */
/* unused harmony export tryItem */
/* unused harmony export item */
/* harmony export (immutable) */ __webpack_exports__["g"] = iterate;
/* unused harmony export iterate2 */
/* unused harmony export iterateIndexed */
/* unused harmony export iterateIndexed2 */
/* unused harmony export isEmpty */
/* unused harmony export tryLast */
/* unused harmony export last */
/* unused harmony export length */
/* harmony export (immutable) */ __webpack_exports__["h"] = map;
/* unused harmony export mapIndexed */
/* unused harmony export indexed */
/* unused harmony export map2 */
/* unused harmony export mapIndexed2 */
/* unused harmony export map3 */
/* unused harmony export mapFold */
/* unused harmony export mapFoldBack */
/* unused harmony export max */
/* unused harmony export maxBy */
/* unused harmony export min */
/* unused harmony export minBy */
/* unused harmony export pairwise */
/* unused harmony export rangeChar */
/* unused harmony export rangeLong */
/* unused harmony export rangeNumber */
/* unused harmony export readOnly */
/* harmony export (immutable) */ __webpack_exports__["i"] = reduce;
/* unused harmony export reduceBack */
/* unused harmony export replicate */
/* unused harmony export reverse */
/* harmony export (immutable) */ __webpack_exports__["j"] = scan;
/* harmony export (immutable) */ __webpack_exports__["k"] = scanBack;
/* unused harmony export singleton */
/* unused harmony export skip */
/* unused harmony export skipWhile */
/* unused harmony export sortWith */
/* unused harmony export sum */
/* unused harmony export sumBy */
/* unused harmony export tail */
/* unused harmony export take */
/* unused harmony export truncate */
/* unused harmony export takeWhile */
/* unused harmony export tryFind */
/* unused harmony export find */
/* unused harmony export tryFindBack */
/* unused harmony export findBack */
/* unused harmony export tryFindIndex */
/* unused harmony export findIndex */
/* unused harmony export tryFindIndexBack */
/* unused harmony export findIndexBack */
/* unused harmony export tryPick */
/* unused harmony export pick */
/* harmony export (immutable) */ __webpack_exports__["m"] = unfold;
/* unused harmony export zip */
/* unused harmony export zip3 */
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_helpers_slicedToArray__ = __webpack_require__(72);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_helpers_slicedToArray___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_babel_runtime_helpers_slicedToArray__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_array_from__ = __webpack_require__(13);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_array_from___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_array_from__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_babel_runtime_helpers_defineProperty__ = __webpack_require__(56);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_babel_runtime_helpers_defineProperty___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_babel_runtime_helpers_defineProperty__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_babel_runtime_core_js_symbol_iterator__ = __webpack_require__(20);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_babel_runtime_core_js_symbol_iterator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_babel_runtime_core_js_symbol_iterator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_get_iterator__ = __webpack_require__(21);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_get_iterator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_get_iterator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_babel_runtime_helpers_classCallCheck__ = __webpack_require__(54);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_babel_runtime_helpers_classCallCheck___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5_babel_runtime_helpers_classCallCheck__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_babel_runtime_helpers_createClass__ = __webpack_require__(52);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_babel_runtime_helpers_createClass___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_6_babel_runtime_helpers_createClass__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__Long__ = __webpack_require__(49);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__Option__ = __webpack_require__(22);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__Util__ = __webpack_require__(3);










var Enumerator = function () {
    function Enumerator(iter) {
        __WEBPACK_IMPORTED_MODULE_5_babel_runtime_helpers_classCallCheck___default()(this, Enumerator);

        this.iter = iter;
    }

    __WEBPACK_IMPORTED_MODULE_6_babel_runtime_helpers_createClass___default()(Enumerator, [{
        key: "MoveNext",
        value: function MoveNext() {
            var cur = this.iter.next();
            this.current = cur.value;
            return !cur.done;
        }
    }, {
        key: "Reset",
        value: function Reset() {
            throw new Error("JS iterators cannot be reset");
        }
    }, {
        key: "Dispose",
        value: function Dispose() {
            return;
        }
    }, {
        key: "Current",
        get: function get() {
            return this.current;
        }
    }]);

    return Enumerator;
}();
function getEnumerator(o) {
    return new Enumerator(__WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_get_iterator___default()(o));
}
function toIterator(en) {
    return {
        next: function next() {
            return en.MoveNext() ? { done: false, value: en.Current } : { done: true, value: null };
        }
    };
}
// export function toIterable<T>(en: IEnumerable<T>): Iterable<T> {
//   return {
//     [Symbol.iterator]() {
//       return toIterator(en.GetEnumerator());
//     },
//   };
// }
function __failIfNone(res) {
    if (res == null) {
        throw new Error("Seq did not contain any matching element");
    }
    return Object(__WEBPACK_IMPORTED_MODULE_8__Option__["d" /* value */])(res);
}
function ofArray(xs) {
    return delay(function () {
        return unfold(function (i) {
            return i < xs.length ? [xs[i], i + 1] : null;
        }, 0);
    });
}
function append(xs, ys) {
    return delay(function () {
        var firstDone = false;
        var i = __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_get_iterator___default()(xs);
        var iters = [i, null];
        return unfold(function () {
            var cur = void 0;
            if (!firstDone) {
                cur = iters[0].next();
                if (!cur.done) {
                    return [cur.value, iters];
                } else {
                    firstDone = true;
                    iters = [null, __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_get_iterator___default()(ys)];
                }
            }
            cur = iters[1].next();
            return !cur.done ? [cur.value, iters] : null;
        }, iters);
    });
}
function average(xs, averager) {
    var count = 0;
    var total = fold(function (acc, x) {
        count++;
        return averager.Add(acc, x);
    }, averager.GetZero(), xs);
    return averager.DivideByInt(total, count);
}
function averageBy(f, xs, averager) {
    var count = 0;
    var total = fold(function (acc, x) {
        count++;
        return averager.Add(acc, f(x));
    }, averager.GetZero(), xs);
    return averager.DivideByInt(total, count);
}
function concat(xs) {
    return delay(function () {
        var iter = __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_get_iterator___default()(xs);
        var output = { value: null };
        return unfold(function (innerIter) {
            var hasFinished = false;
            while (!hasFinished) {
                if (innerIter == null) {
                    var cur = iter.next();
                    if (!cur.done) {
                        innerIter = __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_get_iterator___default()(cur.value);
                    } else {
                        hasFinished = true;
                    }
                } else {
                    var _cur = innerIter.next();
                    if (!_cur.done) {
                        output = { value: _cur.value };
                        hasFinished = true;
                    } else {
                        innerIter = null;
                    }
                }
            }
            return innerIter != null && output != null ? [output.value, innerIter] : null;
        }, null);
    });
}
function collect(f, xs) {
    return concat(map(f, xs));
}
function choose(f, xs) {
    return delay(function () {
        return unfold(function (iter) {
            var cur = iter.next();
            while (!cur.done) {
                var y = f(cur.value);
                if (y != null) {
                    return [Object(__WEBPACK_IMPORTED_MODULE_8__Option__["d" /* value */])(y), iter];
                }
                cur = iter.next();
            }
            return null;
        }, __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_get_iterator___default()(xs));
    });
}
function compareWith(f, xs, ys) {
    var nonZero = tryFind(function (i) {
        return i !== 0;
    }, map2(function (x, y) {
        return f(x, y);
    }, xs, ys));
    return nonZero != null ? Object(__WEBPACK_IMPORTED_MODULE_8__Option__["d" /* value */])(nonZero) : length(xs) - length(ys);
}
function delay(f) {
    return __WEBPACK_IMPORTED_MODULE_2_babel_runtime_helpers_defineProperty___default()({}, __WEBPACK_IMPORTED_MODULE_3_babel_runtime_core_js_symbol_iterator___default.a, function () {
        return __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_get_iterator___default()(f());
    });
}
function empty() {
    return unfold(function () {
        return void 0;
    });
}
function enumerateWhile(cond, xs) {
    return concat(unfold(function () {
        return cond() ? [xs, true] : null;
    }));
}
function enumerateThenFinally(xs, finalFn) {
    return delay(function () {
        var iter = void 0;
        try {
            iter = __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_get_iterator___default()(xs);
        } catch (err) {
            return void 0;
        } finally {
            finalFn();
        }
        return unfold(function (it) {
            try {
                var cur = it.next();
                return !cur.done ? [cur.value, it] : null;
            } catch (err) {
                return void 0;
            } finally {
                finalFn();
            }
        }, iter);
    });
}
function enumerateUsing(disp, work) {
    var isDisposed = false;
    var disposeOnce = function disposeOnce() {
        if (!isDisposed) {
            isDisposed = true;
            disp.Dispose();
        }
    };
    try {
        return enumerateThenFinally(work(disp), disposeOnce);
    } catch (err) {
        return void 0;
    } finally {
        disposeOnce();
    }
}
function exactlyOne(xs) {
    var iter = __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_get_iterator___default()(xs);
    var fst = iter.next();
    if (fst.done) {
        throw new Error("Seq was empty");
    }
    var snd = iter.next();
    if (!snd.done) {
        throw new Error("Seq had multiple items");
    }
    return fst.value;
}
function except(itemsToExclude, source) {
    var exclusionItems = __WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_array_from___default()(itemsToExclude);
    var testIsNotInExclusionItems = function testIsNotInExclusionItems(element) {
        return !exclusionItems.some(function (excludedItem) {
            return Object(__WEBPACK_IMPORTED_MODULE_9__Util__["k" /* equals */])(excludedItem, element);
        });
    };
    return filter(testIsNotInExclusionItems, source);
}
function exists(f, xs) {
    var cur = void 0;
    for (var iter = __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_get_iterator___default()(xs);;) {
        cur = iter.next();
        if (cur.done) {
            break;
        }
        if (f(cur.value)) {
            return true;
        }
    }
    return false;
}
function exists2(f, xs, ys) {
    var cur1 = void 0;
    var cur2 = void 0;
    for (var iter1 = __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_get_iterator___default()(xs), iter2 = __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_get_iterator___default()(ys);;) {
        cur1 = iter1.next();
        cur2 = iter2.next();
        if (cur1.done || cur2.done) {
            break;
        }
        if (f(cur1.value, cur2.value)) {
            return true;
        }
    }
    return false;
}
function contains(i, xs) {
    return exists(function (x) {
        return Object(__WEBPACK_IMPORTED_MODULE_9__Util__["k" /* equals */])(x, i);
    }, xs);
}
function filter(f, xs) {
    return delay(function () {
        return unfold(function (iter) {
            var cur = iter.next();
            while (!cur.done) {
                if (f(cur.value)) {
                    return [cur.value, iter];
                }
                cur = iter.next();
            }
            return null;
        }, __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_get_iterator___default()(xs));
    });
}
function where(f, xs) {
    return filter(f, xs);
}
function fold(f, acc, xs) {
    if (Array.isArray(xs) || ArrayBuffer.isView(xs)) {
        return xs.reduce(f, acc);
    } else {
        var cur = void 0;
        for (var i = 0, iter = __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_get_iterator___default()(xs);; i++) {
            cur = iter.next();
            if (cur.done) {
                break;
            }
            acc = f(acc, cur.value, i);
        }
        return acc;
    }
}
function foldBack(f, xs, acc) {
    var arr = Array.isArray(xs) || ArrayBuffer.isView(xs) ? xs : __WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_array_from___default()(xs);
    for (var i = arr.length - 1; i >= 0; i--) {
        acc = f(arr[i], acc, i);
    }
    return acc;
}
function fold2(f, acc, xs, ys) {
    var iter1 = __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_get_iterator___default()(xs);
    var iter2 = __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_get_iterator___default()(ys);
    var cur1 = void 0;
    var cur2 = void 0;
    for (var i = 0;; i++) {
        cur1 = iter1.next();
        cur2 = iter2.next();
        if (cur1.done || cur2.done) {
            break;
        }
        acc = f(acc, cur1.value, cur2.value, i);
    }
    return acc;
}
function foldBack2(f, xs, ys, acc) {
    var ar1 = Array.isArray(xs) || ArrayBuffer.isView(xs) ? xs : __WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_array_from___default()(xs);
    var ar2 = Array.isArray(ys) || ArrayBuffer.isView(ys) ? ys : __WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_array_from___default()(ys);
    for (var i = ar1.length - 1; i >= 0; i--) {
        acc = f(ar1[i], ar2[i], acc, i);
    }
    return acc;
}
function forAll(f, xs) {
    return fold(function (acc, x) {
        return acc && f(x);
    }, true, xs);
}
function forAll2(f, xs, ys) {
    return fold2(function (acc, x, y) {
        return acc && f(x, y);
    }, true, xs, ys);
}
function tryHead(xs) {
    var iter = __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_get_iterator___default()(xs);
    var cur = iter.next();
    return cur.done ? null : Object(__WEBPACK_IMPORTED_MODULE_8__Option__["c" /* some */])(cur.value);
}
function head(xs) {
    return __failIfNone(tryHead(xs));
}
function initialize(n, f) {
    return delay(function () {
        return unfold(function (i) {
            return i < n ? [f(i), i + 1] : null;
        }, 0);
    });
}
function initializeInfinite(f) {
    return delay(function () {
        return unfold(function (i) {
            return [f(i), i + 1];
        }, 0);
    });
}
function tryItem(i, xs) {
    if (i < 0) {
        return null;
    }
    if (Array.isArray(xs) || ArrayBuffer.isView(xs)) {
        return i < xs.length ? Object(__WEBPACK_IMPORTED_MODULE_8__Option__["c" /* some */])(xs[i]) : null;
    }
    for (var j = 0, iter = __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_get_iterator___default()(xs);; j++) {
        var cur = iter.next();
        if (cur.done) {
            break;
        }
        if (j === i) {
            return Object(__WEBPACK_IMPORTED_MODULE_8__Option__["c" /* some */])(cur.value);
        }
    }
    return null;
}
function item(i, xs) {
    return __failIfNone(tryItem(i, xs));
}
function iterate(f, xs) {
    fold(function (_, x) {
        return f(x);
    }, null, xs);
}
function iterate2(f, xs, ys) {
    fold2(function (_, x, y) {
        return f(x, y);
    }, null, xs, ys);
}
function iterateIndexed(f, xs) {
    fold(function (_, x, i) {
        return f(i, x);
    }, null, xs);
}
function iterateIndexed2(f, xs, ys) {
    fold2(function (_, x, y, i) {
        return f(i, x, y);
    }, null, xs, ys);
}
function isEmpty(xs) {
    var i = __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_get_iterator___default()(xs);
    return i.next().done;
}
function tryLast(xs) {
    return isEmpty(xs) ? null : Object(__WEBPACK_IMPORTED_MODULE_8__Option__["c" /* some */])(reduce(function (_, x) {
        return x;
    }, xs));
}
function last(xs) {
    return __failIfNone(tryLast(xs));
}
function length(xs) {
    return Array.isArray(xs) || ArrayBuffer.isView(xs) ? xs.length : fold(function (acc, x) {
        return acc + 1;
    }, 0, xs);
}
function map(f, xs) {
    return delay(function () {
        return unfold(function (iter) {
            var cur = iter.next();
            return !cur.done ? [f(cur.value), iter] : null;
        }, __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_get_iterator___default()(xs));
    });
}
function mapIndexed(f, xs) {
    return delay(function () {
        var i = 0;
        return unfold(function (iter) {
            var cur = iter.next();
            return !cur.done ? [f(i++, cur.value), iter] : null;
        }, __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_get_iterator___default()(xs));
    });
}
function indexed(xs) {
    return mapIndexed(function (i, x) {
        return [i, x];
    }, xs);
}
function map2(f, xs, ys) {
    return delay(function () {
        var iter1 = __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_get_iterator___default()(xs);
        var iter2 = __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_get_iterator___default()(ys);
        return unfold(function () {
            var cur1 = iter1.next();
            var cur2 = iter2.next();
            return !cur1.done && !cur2.done ? [f(cur1.value, cur2.value), null] : null;
        });
    });
}
function mapIndexed2(f, xs, ys) {
    return delay(function () {
        var i = 0;
        var iter1 = __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_get_iterator___default()(xs);
        var iter2 = __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_get_iterator___default()(ys);
        return unfold(function () {
            var cur1 = iter1.next();
            var cur2 = iter2.next();
            return !cur1.done && !cur2.done ? [f(i++, cur1.value, cur2.value), null] : null;
        });
    });
}
function map3(f, xs, ys, zs) {
    return delay(function () {
        var iter1 = __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_get_iterator___default()(xs);
        var iter2 = __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_get_iterator___default()(ys);
        var iter3 = __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_get_iterator___default()(zs);
        return unfold(function () {
            var cur1 = iter1.next();
            var cur2 = iter2.next();
            var cur3 = iter3.next();
            return !cur1.done && !cur2.done && !cur3.done ? [f(cur1.value, cur2.value, cur3.value), null] : null;
        });
    });
}
function mapFold(f, acc, xs, transform) {
    var result = [];
    var r = void 0;
    var cur = void 0;
    for (var i = 0, iter = __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_get_iterator___default()(xs);; i++) {
        cur = iter.next();
        if (cur.done) {
            break;
        }

        var _f = f(acc, cur.value);

        var _f2 = __WEBPACK_IMPORTED_MODULE_0_babel_runtime_helpers_slicedToArray___default()(_f, 2);

        r = _f2[0];
        acc = _f2[1];

        result.push(r);
    }
    return transform !== void 0 ? [transform(result), acc] : [result, acc];
}
function mapFoldBack(f, xs, acc, transform) {
    var arr = Array.isArray(xs) || ArrayBuffer.isView(xs) ? xs : __WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_array_from___default()(xs);
    var result = [];
    var r = void 0;
    for (var i = arr.length - 1; i >= 0; i--) {
        var _f3 = f(arr[i], acc);

        var _f4 = __WEBPACK_IMPORTED_MODULE_0_babel_runtime_helpers_slicedToArray___default()(_f3, 2);

        r = _f4[0];
        acc = _f4[1];

        result.push(r);
    }
    return transform !== void 0 ? [transform(result), acc] : [result, acc];
}
function max(xs, comparer) {
    var compareFn = comparer != null ? comparer.Compare : __WEBPACK_IMPORTED_MODULE_9__Util__["c" /* compare */];
    return reduce(function (acc, x) {
        return compareFn(acc, x) === 1 ? acc : x;
    }, xs);
}
function maxBy(f, xs, comparer) {
    var compareFn = comparer != null ? comparer.Compare : __WEBPACK_IMPORTED_MODULE_9__Util__["c" /* compare */];
    return reduce(function (acc, x) {
        return compareFn(f(acc), f(x)) === 1 ? acc : x;
    }, xs);
}
function min(xs, comparer) {
    var compareFn = comparer != null ? comparer.Compare : __WEBPACK_IMPORTED_MODULE_9__Util__["c" /* compare */];
    return reduce(function (acc, x) {
        return compareFn(acc, x) === -1 ? acc : x;
    }, xs);
}
function minBy(f, xs, comparer) {
    var compareFn = comparer != null ? comparer.Compare : __WEBPACK_IMPORTED_MODULE_9__Util__["c" /* compare */];
    return reduce(function (acc, x) {
        return compareFn(f(acc), f(x)) === -1 ? acc : x;
    }, xs);
}
function pairwise(xs) {
    return skip(2, scan(function (last, next) {
        return [last[1], next];
    }, [0, 0], xs));
}
function rangeChar(first, last) {
    return delay(function () {
        return unfold(function (x) {
            return x <= last ? [x, String.fromCharCode(x.charCodeAt(0) + 1)] : null;
        }, first);
    });
}
function rangeLong(first, step, last, unsigned) {
    var stepFn = Object(__WEBPACK_IMPORTED_MODULE_7__Long__["d" /* makeRangeStepFunction */])(step, last, unsigned);
    return delay(function () {
        return unfold(stepFn, first);
    });
}
function rangeNumber(first, step, last) {
    if (step === 0) {
        throw new Error("Step cannot be 0");
    }
    return delay(function () {
        return unfold(function (x) {
            return step > 0 && x <= last || step < 0 && x >= last ? [x, x + step] : null;
        }, first);
    });
}
function readOnly(xs) {
    return map(function (x) {
        return x;
    }, xs);
}
function reduce(f, xs) {
    if (Array.isArray(xs) || ArrayBuffer.isView(xs)) {
        return xs.reduce(f);
    }
    var iter = __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_get_iterator___default()(xs);
    var cur = iter.next();
    if (cur.done) {
        throw new Error("Seq was empty");
    }
    var acc = cur.value;
    while (true) {
        cur = iter.next();
        if (cur.done) {
            break;
        }
        acc = f(acc, cur.value);
    }
    return acc;
}
function reduceBack(f, xs) {
    var ar = Array.isArray(xs) || ArrayBuffer.isView(xs) ? xs : __WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_array_from___default()(xs);
    if (ar.length === 0) {
        throw new Error("Seq was empty");
    }
    var acc = ar[ar.length - 1];
    for (var i = ar.length - 2; i >= 0; i--) {
        acc = f(ar[i], acc, i);
    }
    return acc;
}
function replicate(n, x) {
    return initialize(n, function () {
        return x;
    });
}
function reverse(xs) {
    var ar = Array.isArray(xs) || ArrayBuffer.isView(xs) ? xs.slice(0) : __WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_array_from___default()(xs);
    return ofArray(ar.reverse());
}
function scan(f, seed, xs) {
    return delay(function () {
        var iter = __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_get_iterator___default()(xs);
        return unfold(function (acc) {
            if (acc == null) {
                return [seed, seed];
            }
            var cur = iter.next();
            if (!cur.done) {
                acc = f(acc, cur.value);
                return [acc, acc];
            }
            return void 0;
        }, null);
    });
}
function scanBack(f, xs, seed) {
    return reverse(scan(function (acc, x) {
        return f(x, acc);
    }, seed, reverse(xs)));
}
function singleton(y) {
    return [y];
}
function skip(n, xs) {
    return __WEBPACK_IMPORTED_MODULE_2_babel_runtime_helpers_defineProperty___default()({}, __WEBPACK_IMPORTED_MODULE_3_babel_runtime_core_js_symbol_iterator___default.a, function () {
        var iter = __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_get_iterator___default()(xs);
        for (var i = 1; i <= n; i++) {
            if (iter.next().done) {
                throw new Error("Seq has not enough elements");
            }
        }
        return iter;
    });
}
function skipWhile(f, xs) {
    return delay(function () {
        var hasPassed = false;
        return filter(function (x) {
            return hasPassed || (hasPassed = !f(x));
        }, xs);
    });
}
function sortWith(f, xs) {
    var ys = __WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_array_from___default()(xs);
    return ofArray(ys.sort(f));
}
function sum(xs, adder) {
    return fold(function (acc, x) {
        return adder.Add(acc, x);
    }, adder.GetZero(), xs);
}
function sumBy(f, xs, adder) {
    return fold(function (acc, x) {
        return adder.Add(acc, f(x));
    }, adder.GetZero(), xs);
}
function tail(xs) {
    var iter = __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_get_iterator___default()(xs);
    var cur = iter.next();
    if (cur.done) {
        throw new Error("Seq was empty");
    }
    return __WEBPACK_IMPORTED_MODULE_2_babel_runtime_helpers_defineProperty___default()({}, __WEBPACK_IMPORTED_MODULE_3_babel_runtime_core_js_symbol_iterator___default.a, function () {
        return iter;
    });
}
function take(n, xs) {
    var truncate = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;

    return delay(function () {
        var iter = __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_get_iterator___default()(xs);
        return unfold(function (i) {
            if (i < n) {
                var cur = iter.next();
                if (!cur.done) {
                    return [cur.value, i + 1];
                }
                if (!truncate) {
                    throw new Error("Seq has not enough elements");
                }
            }
            return void 0;
        }, 0);
    });
}
function truncate(n, xs) {
    return take(n, xs, true);
}
function takeWhile(f, xs) {
    return delay(function () {
        var iter = __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_get_iterator___default()(xs);
        return unfold(function (i) {
            var cur = iter.next();
            if (!cur.done && f(cur.value)) {
                return [cur.value, null];
            }
            return void 0;
        }, 0);
    });
}
function tryFind(f, xs, defaultValue) {
    for (var i = 0, iter = __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_get_iterator___default()(xs);; i++) {
        var cur = iter.next();
        if (cur.done) {
            break;
        }
        if (f(cur.value, i)) {
            return Object(__WEBPACK_IMPORTED_MODULE_8__Option__["c" /* some */])(cur.value);
        }
    }
    return defaultValue === void 0 ? null : Object(__WEBPACK_IMPORTED_MODULE_8__Option__["c" /* some */])(defaultValue);
}
function find(f, xs) {
    return __failIfNone(tryFind(f, xs));
}
function tryFindBack(f, xs, defaultValue) {
    var arr = Array.isArray(xs) || ArrayBuffer.isView(xs) ? xs.slice(0) : __WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_array_from___default()(xs);
    return tryFind(f, arr.reverse(), defaultValue);
}
function findBack(f, xs) {
    return __failIfNone(tryFindBack(f, xs));
}
function tryFindIndex(f, xs) {
    for (var i = 0, iter = __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_get_iterator___default()(xs);; i++) {
        var cur = iter.next();
        if (cur.done) {
            break;
        }
        if (f(cur.value, i)) {
            return i;
        }
    }
    return null;
}
function findIndex(f, xs) {
    return __failIfNone(tryFindIndex(f, xs));
}
function tryFindIndexBack(f, xs) {
    var arr = Array.isArray(xs) || ArrayBuffer.isView(xs) ? xs.slice(0) : __WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_array_from___default()(xs);
    for (var i = arr.length - 1; i >= 0; i--) {
        if (f(arr[i], i)) {
            return i;
        }
    }
    return null;
}
function findIndexBack(f, xs) {
    return __failIfNone(tryFindIndexBack(f, xs));
}
function tryPick(f, xs) {
    for (var i = 0, iter = __WEBPACK_IMPORTED_MODULE_4_babel_runtime_core_js_get_iterator___default()(xs);; i++) {
        var cur = iter.next();
        if (cur.done) {
            break;
        }
        var y = f(cur.value, i);
        if (y != null) {
            return y;
        }
    }
    return null;
}
function pick(f, xs) {
    return __failIfNone(tryPick(f, xs));
}
function unfold(f, fst) {
    return __WEBPACK_IMPORTED_MODULE_2_babel_runtime_helpers_defineProperty___default()({}, __WEBPACK_IMPORTED_MODULE_3_babel_runtime_core_js_symbol_iterator___default.a, function () {
        // Capture a copy of the first value in the closure
        // so the sequence is restarted every time, see #1230
        var acc = fst;
        return {
            next: function next() {
                var res = f(acc);
                if (res != null) {
                    acc = res[1];
                    return { done: false, value: res[0] };
                }
                return { done: true };
            }
        };
    });
}
function zip(xs, ys) {
    return map2(function (x, y) {
        return [x, y];
    }, xs, ys);
}
function zip3(xs, ys, zs) {
    return map3(function (x, y, z) {
        return [x, y, z];
    }, xs, ys, zs);
}

/***/ }),
/* 33 */
/***/ (function(module, exports) {

// 7.1.4 ToInteger
var ceil = Math.ceil;
var floor = Math.floor;
module.exports = function (it) {
  return isNaN(it = +it) ? 0 : (it > 0 ? floor : ceil)(it);
};


/***/ }),
/* 34 */
/***/ (function(module, exports) {

// 7.2.1 RequireObjectCoercible(argument)
module.exports = function (it) {
  if (it == undefined) throw TypeError("Can't call method on  " + it);
  return it;
};


/***/ }),
/* 35 */
/***/ (function(module, exports) {

module.exports = true;


/***/ }),
/* 36 */
/***/ (function(module, exports, __webpack_require__) {

// 7.1.1 ToPrimitive(input [, PreferredType])
var isObject = __webpack_require__(4);
// instead of the ES6 spec version, we didn't implement @@toPrimitive case
// and the second argument - flag - preferred type is a string
module.exports = function (it, S) {
  if (!isObject(it)) return it;
  var fn, val;
  if (S && typeof (fn = it.toString) == 'function' && !isObject(val = fn.call(it))) return val;
  if (typeof (fn = it.valueOf) == 'function' && !isObject(val = fn.call(it))) return val;
  if (!S && typeof (fn = it.toString) == 'function' && !isObject(val = fn.call(it))) return val;
  throw TypeError("Can't convert object to primitive value");
};


/***/ }),
/* 37 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(7);


/***/ }),
/* 38 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.2 / 15.2.3.5 Object.create(O [, Properties])
var anObject = __webpack_require__(8);
var dPs = __webpack_require__(90);
var enumBugKeys = __webpack_require__(43);
var IE_PROTO = __webpack_require__(41)('IE_PROTO');
var Empty = function () { /* empty */ };
var PROTOTYPE = 'prototype';

// Create object with fake `null` prototype: use iframe Object with cleared prototype
var createDict = function () {
  // Thrash, waste and sodomy: IE GC bug
  var iframe = __webpack_require__(61)('iframe');
  var i = enumBugKeys.length;
  var lt = '<';
  var gt = '>';
  var iframeDocument;
  iframe.style.display = 'none';
  __webpack_require__(93).appendChild(iframe);
  iframe.src = 'javascript:'; // eslint-disable-line no-script-url
  // createDict = iframe.contentWindow.Object;
  // html.removeChild(iframe);
  iframeDocument = iframe.contentWindow.document;
  iframeDocument.open();
  iframeDocument.write(lt + 'script' + gt + 'document.F=Object' + lt + '/script' + gt);
  iframeDocument.close();
  createDict = iframeDocument.F;
  while (i--) delete createDict[PROTOTYPE][enumBugKeys[i]];
  return createDict();
};

module.exports = Object.create || function create(O, Properties) {
  var result;
  if (O !== null) {
    Empty[PROTOTYPE] = anObject(O);
    result = new Empty();
    Empty[PROTOTYPE] = null;
    // add "__proto__" for Object.getPrototypeOf polyfill
    result[IE_PROTO] = O;
  } else result = createDict();
  return Properties === undefined ? result : dPs(result, Properties);
};


/***/ }),
/* 39 */
/***/ (function(module, exports, __webpack_require__) {

// fallback for non-array-like ES3 and non-enumerable old V8 strings
var cof = __webpack_require__(40);
// eslint-disable-next-line no-prototype-builtins
module.exports = Object('z').propertyIsEnumerable(0) ? Object : function (it) {
  return cof(it) == 'String' ? it.split('') : Object(it);
};


/***/ }),
/* 40 */
/***/ (function(module, exports) {

var toString = {}.toString;

module.exports = function (it) {
  return toString.call(it).slice(8, -1);
};


/***/ }),
/* 41 */
/***/ (function(module, exports, __webpack_require__) {

var shared = __webpack_require__(42)('keys');
var uid = __webpack_require__(26);
module.exports = function (key) {
  return shared[key] || (shared[key] = uid(key));
};


/***/ }),
/* 42 */
/***/ (function(module, exports, __webpack_require__) {

var global = __webpack_require__(5);
var SHARED = '__core-js_shared__';
var store = global[SHARED] || (global[SHARED] = {});
module.exports = function (key) {
  return store[key] || (store[key] = {});
};


/***/ }),
/* 43 */
/***/ (function(module, exports) {

// IE 8- don't enum bug keys
module.exports = (
  'constructor,hasOwnProperty,isPrototypeOf,propertyIsEnumerable,toLocaleString,toString,valueOf'
).split(',');


/***/ }),
/* 44 */
/***/ (function(module, exports, __webpack_require__) {

var classof = __webpack_require__(66);
var ITERATOR = __webpack_require__(1)('iterator');
var Iterators = __webpack_require__(14);
module.exports = __webpack_require__(0).getIteratorMethod = function (it) {
  if (it != undefined) return it[ITERATOR]
    || it['@@iterator']
    || Iterators[classof(it)];
};


/***/ }),
/* 45 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export compare */
/* unused harmony export compareOrdinal */
/* unused harmony export compareTo */
/* unused harmony export startsWith */
/* unused harmony export indexOfAny */
/* harmony export (immutable) */ __webpack_exports__["b"] = printf;
/* harmony export (immutable) */ __webpack_exports__["c"] = toConsole;
/* unused harmony export toConsoleError */
/* harmony export (immutable) */ __webpack_exports__["d"] = toText;
/* unused harmony export toFail */
/* unused harmony export fsFormat */
/* unused harmony export format */
/* unused harmony export endsWith */
/* unused harmony export initialize */
/* unused harmony export insert */
/* unused harmony export isNullOrEmpty */
/* unused harmony export isNullOrWhiteSpace */
/* harmony export (immutable) */ __webpack_exports__["a"] = join;
/* unused harmony export joinWithIndices */
/* unused harmony export validateGuid */
/* unused harmony export newGuid */
/* unused harmony export guidToArray */
/* unused harmony export arrayToGuid */
/* unused harmony export toBase64String */
/* unused harmony export fromBase64String */
/* unused harmony export padLeft */
/* unused harmony export padRight */
/* unused harmony export remove */
/* unused harmony export replace */
/* unused harmony export replicate */
/* unused harmony export getCharAtIndex */
/* unused harmony export split */
/* unused harmony export trim */
/* unused harmony export trimStart */
/* unused harmony export trimEnd */
/* unused harmony export filter */
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_helpers_toConsumableArray__ = __webpack_require__(28);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_helpers_toConsumableArray___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_babel_runtime_helpers_toConsumableArray__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_typeof__ = __webpack_require__(67);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_typeof___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_typeof__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_get_iterator__ = __webpack_require__(21);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_get_iterator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_get_iterator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__Date__ = __webpack_require__(110);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__Decimal__ = __webpack_require__(138);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__Long__ = __webpack_require__(49);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__RegExp__ = __webpack_require__(140);







var fsFormatRegExp = /(^|[^%])%([0+ ]*)(-?\d+)?(?:\.(\d+))?(\w)/;
var formatRegExp = /\{(\d+)(,-?\d+)?(?:\:(.+?))?\}/g;
// From https://stackoverflow.com/a/13653180/3922220
var guidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
function cmp(x, y, ic) {
    function isIgnoreCase(i) {
        return i === true || i === 1 /* CurrentCultureIgnoreCase */ || i === 3 /* InvariantCultureIgnoreCase */ || i === 5 /* OrdinalIgnoreCase */;
    }
    function isOrdinal(i) {
        return i === 4 /* Ordinal */ || i === 5 /* OrdinalIgnoreCase */;
    }
    if (x == null) {
        return y == null ? 0 : -1;
    }
    if (y == null) {
        return 1;
    } // everything is bigger than null
    if (isOrdinal(ic)) {
        if (isIgnoreCase(ic)) {
            x = x.toLowerCase();
            y = y.toLowerCase();
        }
        return x === y ? 0 : x < y ? -1 : 1;
    } else {
        if (isIgnoreCase(ic)) {
            x = x.toLocaleLowerCase();
            y = y.toLocaleLowerCase();
        }
        return x.localeCompare(y);
    }
}
function compare() {
    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
    }

    switch (args.length) {
        case 2:
            return cmp(args[0], args[1], false);
        case 3:
            return cmp(args[0], args[1], args[2]);
        case 4:
            return cmp(args[0], args[1], args[2] === true);
        case 5:
            return cmp(args[0].substr(args[1], args[4]), args[2].substr(args[3], args[4]), false);
        case 6:
            return cmp(args[0].substr(args[1], args[4]), args[2].substr(args[3], args[4]), args[5]);
        case 7:
            return cmp(args[0].substr(args[1], args[4]), args[2].substr(args[3], args[4]), args[5] === true);
        default:
            throw new Error("String.compare: Unsupported number of parameters");
    }
}
function compareOrdinal(x, y) {
    return cmp(x, y, 4 /* Ordinal */);
}
function compareTo(x, y) {
    return cmp(x, y, 0 /* CurrentCulture */);
}
function startsWith(str, pattern, ic) {
    if (str.length >= pattern.length) {
        return cmp(str.substr(0, pattern.length), pattern, ic) === 0;
    }
    return false;
}
function indexOfAny(str, anyOf) {
    if (str == null || str === "") {
        return -1;
    }
    var startIndex = (arguments.length <= 2 ? 0 : arguments.length - 2) > 0 ? arguments.length <= 2 ? undefined : arguments[2] : 0;
    if (startIndex < 0) {
        throw new Error("Start index cannot be negative");
    }
    var length = (arguments.length <= 2 ? 0 : arguments.length - 2) > 1 ? arguments.length <= 3 ? undefined : arguments[3] : str.length - startIndex;
    if (length < 0) {
        throw new Error("Length cannot be negative");
    }
    if (length > str.length - startIndex) {
        throw new Error("Invalid startIndex and length");
    }
    str = str.substr(startIndex, length);
    var _iteratorNormalCompletion = true;
    var _didIteratorError = false;
    var _iteratorError = undefined;

    try {
        for (var _iterator = __WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_get_iterator___default()(anyOf), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
            var c = _step.value;

            var index = str.indexOf(c);
            if (index > -1) {
                return index + startIndex;
            }
        }
    } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
    } finally {
        try {
            if (!_iteratorNormalCompletion && _iterator.return) {
                _iterator.return();
            }
        } finally {
            if (_didIteratorError) {
                throw _iteratorError;
            }
        }
    }

    return -1;
}
function toHex(x) {
    if (x instanceof __WEBPACK_IMPORTED_MODULE_5__Long__["a" /* default */]) {
        return Object(__WEBPACK_IMPORTED_MODULE_5__Long__["g" /* toString */])(x.unsigned ? x : Object(__WEBPACK_IMPORTED_MODULE_5__Long__["b" /* fromBytes */])(Object(__WEBPACK_IMPORTED_MODULE_5__Long__["f" /* toBytes */])(x), true), 16);
    } else {
        return (Number(x) >>> 0).toString(16);
    }
}
function printf(input) {
    return {
        input: input,
        cont: fsFormat(input)
    };
}
function toConsole(arg) {
    // Don't remove the lambda here, see #1357
    return arg.cont(function (x) {
        console.log(x);
    });
}
function toConsoleError(arg) {
    return arg.cont(function (x) {
        console.error(x);
    });
}
function toText(arg) {
    return arg.cont(function (x) {
        return x;
    });
}
function toFail(arg) {
    return arg.cont(function (x) {
        throw new Error(x);
    });
}
function formatOnce(str2, rep) {
    return str2.replace(fsFormatRegExp, function (_, prefix, flags, pad, precision, format) {
        switch (format) {
            case "f":
            case "F":
                rep = Number(rep).toFixed(precision || 6);
                break;
            case "g":
            case "G":
                rep = Number(rep).toPrecision(precision);
                break;
            case "e":
            case "E":
                rep = Number(rep).toExponential(precision);
                break;
            case "O":
            case "A":
                rep = String(rep);
                break;
            case "x":
                rep = toHex(rep);
                break;
            case "X":
                rep = toHex(rep).toUpperCase();
                break;
        }
        var plusPrefix = flags.indexOf("+") >= 0 && parseInt(rep, 10) >= 0;
        pad = parseInt(pad, 10);
        if (!isNaN(pad)) {
            var ch = pad >= 0 && flags.indexOf("0") >= 0 ? "0" : " ";
            rep = padLeft(String(rep), Math.abs(pad) - (plusPrefix ? 1 : 0), ch, pad < 0);
        }
        var once = prefix + (plusPrefix ? "+" + rep : rep);
        return once.replace(/%/g, "%%");
    });
}
function createPrinter(str, cont) {
    return function () {
        for (var _len2 = arguments.length, args = Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
            args[_key2] = arguments[_key2];
        }

        // Make a copy as the function may be used several times
        var strCopy = str;
        var _iteratorNormalCompletion2 = true;
        var _didIteratorError2 = false;
        var _iteratorError2 = undefined;

        try {
            for (var _iterator2 = __WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_get_iterator___default()(args), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
                var arg = _step2.value;

                strCopy = formatOnce(strCopy, arg);
            }
        } catch (err) {
            _didIteratorError2 = true;
            _iteratorError2 = err;
        } finally {
            try {
                if (!_iteratorNormalCompletion2 && _iterator2.return) {
                    _iterator2.return();
                }
            } finally {
                if (_didIteratorError2) {
                    throw _iteratorError2;
                }
            }
        }

        return fsFormatRegExp.test(strCopy) ? createPrinter(strCopy, cont) : cont(strCopy.replace(/%%/g, "%"));
    };
}
function fsFormat(str) {
    return function (cont) {
        return fsFormatRegExp.test(str) ? createPrinter(str, cont) : cont(str);
    };
}
function format(str) {
    for (var _len3 = arguments.length, args = Array(_len3 > 1 ? _len3 - 1 : 0), _key3 = 1; _key3 < _len3; _key3++) {
        args[_key3 - 1] = arguments[_key3];
    }

    if ((typeof str === "undefined" ? "undefined" : __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_typeof___default()(str)) === "object" && args.length > 0) {
        // Called with culture info
        str = args[0];
        args.shift();
    }
    return str.replace(formatRegExp, function (match, idx, pad, pattern) {
        var rep = args[idx];
        var padSymbol = " ";
        if (typeof rep === "number" || rep instanceof __WEBPACK_IMPORTED_MODULE_5__Long__["a" /* default */] || rep instanceof __WEBPACK_IMPORTED_MODULE_4__Decimal__["a" /* default */]) {
            switch ((pattern || "").substring(0, 1)) {
                case "f":
                case "F":
                    rep = pattern.length > 1 ? rep.toFixed(pattern.substring(1)) : rep.toFixed(2);
                    break;
                case "g":
                case "G":
                    rep = pattern.length > 1 ? rep.toPrecision(pattern.substring(1)) : rep.toPrecision();
                    break;
                case "e":
                case "E":
                    rep = pattern.length > 1 ? rep.toExponential(pattern.substring(1)) : rep.toExponential();
                    break;
                case "p":
                case "P":
                    rep = (pattern.length > 1 ? (rep * 100).toFixed(pattern.substring(1)) : (rep * 100).toFixed(2)) + " %";
                    break;
                case "x":
                    rep = toHex(rep);
                    break;
                case "X":
                    rep = toHex(rep).toUpperCase();
                    break;
                default:
                    var m = /^(0+)(\.0+)?$/.exec(pattern);
                    if (m != null) {
                        var decs = 0;
                        if (m[2] != null) {
                            rep = rep.toFixed(decs = m[2].length - 1);
                        }
                        pad = "," + (m[1].length + (decs ? decs + 1 : 0)).toString();
                        padSymbol = "0";
                    } else if (pattern) {
                        rep = pattern;
                    }
            }
        } else if (rep instanceof Date) {
            rep = Object(__WEBPACK_IMPORTED_MODULE_3__Date__["a" /* toString */])(rep, pattern);
        }
        pad = parseInt((pad || "").substring(1), 10);
        if (!isNaN(pad)) {
            rep = padLeft(String(rep), Math.abs(pad), padSymbol, pad < 0);
        }
        return rep;
    });
}
function endsWith(str, search) {
    var idx = str.lastIndexOf(search);
    return idx >= 0 && idx === str.length - search.length;
}
function initialize(n, f) {
    if (n < 0) {
        throw new Error("String length must be non-negative");
    }
    var xs = new Array(n);
    for (var i = 0; i < n; i++) {
        xs[i] = f(i);
    }
    return xs.join("");
}
function insert(str, startIndex, value) {
    if (startIndex < 0 || startIndex > str.length) {
        throw new Error("startIndex is negative or greater than the length of this instance.");
    }
    return str.substring(0, startIndex) + value + str.substring(startIndex);
}
function isNullOrEmpty(str) {
    return typeof str !== "string" || str.length === 0;
}
function isNullOrWhiteSpace(str) {
    return typeof str !== "string" || /^\s*$/.test(str);
}
function join(delimiter) {
    for (var _len4 = arguments.length, xs = Array(_len4 > 1 ? _len4 - 1 : 0), _key4 = 1; _key4 < _len4; _key4++) {
        xs[_key4 - 1] = arguments[_key4];
    }

    return xs.map(function (x) {
        return String(x);
    }).join(delimiter);
}
function joinWithIndices(delimiter, xs, startIndex, count) {
    var endIndexPlusOne = startIndex + count;
    if (endIndexPlusOne > xs.length) {
        throw new Error("Index and count must refer to a location within the buffer.");
    }
    return join.apply(undefined, [delimiter].concat(__WEBPACK_IMPORTED_MODULE_0_babel_runtime_helpers_toConsumableArray___default()(xs.slice(startIndex, endIndexPlusOne))));
}
/** Validates UUID as specified in RFC4122 (versions 1-5). Trims braces. */
function validateGuid(str, doNotThrow) {
    var trimmed = trim(str, "{", "}");
    if (guidRegex.test(trimmed)) {
        return doNotThrow ? [true, trimmed] : trimmed;
    } else if (doNotThrow) {
        return [false, "00000000-0000-0000-0000-000000000000"];
    }
    throw new Error("Guid should contain 32 digits with 4 dashes: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx");
}
// From https://gist.github.com/LeverOne/1308368
function newGuid() {
    var b = "";
    for (var a = 0; a++ < 36;) {
        b += a * 51 & 52 ? (a ^ 15 ? 8 ^ Math.random() * (a ^ 20 ? 16 : 4) : 4).toString(16) : "-";
    }
    return b;
}
// Maps for number <-> hex string conversion
var _convertMapsInitialized = false;
var _byteToHex = void 0;
var _hexToByte = void 0;
function initConvertMaps() {
    _byteToHex = new Array(256);
    _hexToByte = {};
    for (var i = 0; i < 256; i++) {
        _byteToHex[i] = (i + 0x100).toString(16).substr(1);
        _hexToByte[_byteToHex[i]] = i;
    }
    _convertMapsInitialized = true;
}
/** Parse a UUID into it's component bytes */
// Adapted from https://github.com/zefferus/uuid-parse
function guidToArray(s) {
    if (!_convertMapsInitialized) {
        initConvertMaps();
    }
    var i = 0;
    var buf = new Uint8Array(16);
    s.toLowerCase().replace(/[0-9a-f]{2}/g, function (oct) {
        switch (i) {
            // .NET saves first three byte groups with different endianness
            // See https://stackoverflow.com/a/16722909/3922220
            case 0:
            case 1:
            case 2:
            case 3:
                buf[3 - i++] = _hexToByte[oct];
                break;
            case 4:
            case 5:
                buf[9 - i++] = _hexToByte[oct];
                break;
            case 6:
            case 7:
                buf[13 - i++] = _hexToByte[oct];
                break;
            case 8:
            case 9:
            case 10:
            case 11:
            case 12:
            case 13:
            case 14:
            case 15:
                buf[i++] = _hexToByte[oct];
                break;
        }
    });
    // Zero out remaining bytes if string was short
    while (i < 16) {
        buf[i++] = 0;
    }
    return buf;
}
/** Convert UUID byte array into a string */
function arrayToGuid(buf) {
    if (buf.length !== 16) {
        throw new Error("Byte array for GUID must be exactly 16 bytes long");
    }
    if (!_convertMapsInitialized) {
        initConvertMaps();
    }
    return _byteToHex[buf[3]] + _byteToHex[buf[2]] + _byteToHex[buf[1]] + _byteToHex[buf[0]] + "-" + _byteToHex[buf[5]] + _byteToHex[buf[4]] + "-" + _byteToHex[buf[7]] + _byteToHex[buf[6]] + "-" + _byteToHex[buf[8]] + _byteToHex[buf[9]] + "-" + _byteToHex[buf[10]] + _byteToHex[buf[11]] + _byteToHex[buf[12]] + _byteToHex[buf[13]] + _byteToHex[buf[14]] + _byteToHex[buf[15]];
}
function notSupported(name) {
    throw new Error("The environment doesn't support '" + name + "', please use a polyfill.");
}
function toBase64String(inArray) {
    var str = "";
    for (var i = 0; i < inArray.length; i++) {
        str += String.fromCharCode(inArray[i]);
    }
    return typeof btoa === "function" ? btoa(str) : notSupported("btoa");
}
function fromBase64String(b64Encoded) {
    var binary = typeof atob === "function" ? atob(b64Encoded) : notSupported("atob");
    var bytes = new Uint8Array(binary.length);
    for (var i = 0; i < binary.length; i++) {
        bytes[i] = binary.charCodeAt(i);
    }
    return bytes;
}
function padLeft(str, len, ch, isRight) {
    ch = ch || " ";
    len = len - str.length;
    for (var i = 0; i < len; i++) {
        str = isRight ? str + ch : ch + str;
    }
    return str;
}
function padRight(str, len, ch) {
    return padLeft(str, len, ch, true);
}
function remove(str, startIndex, count) {
    if (startIndex >= str.length) {
        throw new Error("startIndex must be less than length of string");
    }
    if (typeof count === "number" && startIndex + count > str.length) {
        throw new Error("Index and count must refer to a location within the string.");
    }
    return str.slice(0, startIndex) + (typeof count === "number" ? str.substr(startIndex + count) : "");
}
function replace(str, search, replace) {
    return str.replace(new RegExp(Object(__WEBPACK_IMPORTED_MODULE_6__RegExp__["a" /* escape */])(search), "g"), replace);
}
function replicate(n, x) {
    return initialize(n, function () {
        return x;
    });
}
function getCharAtIndex(input, index) {
    if (index < 0 || index >= input.length) {
        throw new Error("Index was outside the bounds of the array.");
    }
    return input[index];
}
function split(str, splitters, count, removeEmpty) {
    count = typeof count === "number" ? count : null;
    removeEmpty = typeof removeEmpty === "number" ? removeEmpty : null;
    if (count < 0) {
        throw new Error("Count cannot be less than zero");
    }
    if (count === 0) {
        return [];
    }
    if (!Array.isArray(splitters)) {
        if (removeEmpty === 0) {
            return str.split(splitters, count);
        }
        var len = arguments.length;
        splitters = Array(len - 1);
        for (var key = 1; key < len; key++) {
            splitters[key - 1] = arguments[key];
        }
    }
    splitters = splitters.map(function (x) {
        return Object(__WEBPACK_IMPORTED_MODULE_6__RegExp__["a" /* escape */])(x);
    });
    splitters = splitters.length > 0 ? splitters : [" "];
    var i = 0;
    var splits = [];
    var reg = new RegExp(splitters.join("|"), "g");
    while (count == null || count > 1) {
        var m = reg.exec(str);
        if (m === null) {
            break;
        }
        if (!removeEmpty || m.index - i > 0) {
            count = count != null ? count - 1 : count;
            splits.push(str.substring(i, m.index));
        }
        i = reg.lastIndex;
    }
    if (!removeEmpty || str.length - i > 0) {
        splits.push(str.substring(i));
    }
    return splits;
}
function trim(str) {
    for (var _len5 = arguments.length, chars = Array(_len5 > 1 ? _len5 - 1 : 0), _key5 = 1; _key5 < _len5; _key5++) {
        chars[_key5 - 1] = arguments[_key5];
    }

    if (chars.length === 0) {
        return str.trim();
    }
    var pattern = "[" + Object(__WEBPACK_IMPORTED_MODULE_6__RegExp__["a" /* escape */])(chars.join("")) + "]+";
    return str.replace(new RegExp("^" + pattern), "").replace(new RegExp(pattern + "$"), "");
}
function trimStart(str) {
    for (var _len6 = arguments.length, chars = Array(_len6 > 1 ? _len6 - 1 : 0), _key6 = 1; _key6 < _len6; _key6++) {
        chars[_key6 - 1] = arguments[_key6];
    }

    return chars.length === 0 ? str.trimStart() : str.replace(new RegExp("^[" + Object(__WEBPACK_IMPORTED_MODULE_6__RegExp__["a" /* escape */])(chars.join("")) + "]+"), "");
}
function trimEnd(str) {
    for (var _len7 = arguments.length, chars = Array(_len7 > 1 ? _len7 - 1 : 0), _key7 = 1; _key7 < _len7; _key7++) {
        chars[_key7 - 1] = arguments[_key7];
    }

    return chars.length === 0 ? str.trimEnd() : str.replace(new RegExp("[" + Object(__WEBPACK_IMPORTED_MODULE_6__RegExp__["a" /* escape */])(chars.join("")) + "]+$"), "");
}
function filter(pred, x) {
    return x.split("").filter(function (c) {
        return pred(c);
    }).join("");
}

/***/ }),
/* 46 */
/***/ (function(module, exports, __webpack_require__) {

exports.f = __webpack_require__(1);


/***/ }),
/* 47 */
/***/ (function(module, exports, __webpack_require__) {

var global = __webpack_require__(5);
var core = __webpack_require__(0);
var LIBRARY = __webpack_require__(35);
var wksExt = __webpack_require__(46);
var defineProperty = __webpack_require__(6).f;
module.exports = function (name) {
  var $Symbol = core.Symbol || (core.Symbol = LIBRARY ? {} : global.Symbol || {});
  if (name.charAt(0) != '_' && !(name in $Symbol)) defineProperty($Symbol, name, { value: wksExt.f(name) });
};


/***/ }),
/* 48 */
/***/ (function(module, exports) {

exports.f = Object.getOwnPropertySymbols;


/***/ }),
/* 49 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = Long;
/* unused harmony export neg */
/* unused harmony export not */
/* unused harmony export add */
/* unused harmony export sub */
/* unused harmony export mul */
/* unused harmony export div */
/* unused harmony export mod */
/* unused harmony export shl */
/* unused harmony export shr */
/* unused harmony export and */
/* unused harmony export or */
/* unused harmony export xor */
/* unused harmony export fromInt */
/* unused harmony export fromNumber */
/* unused harmony export fromInteger */
/* unused harmony export fromBits */
/* unused harmony export fromString */
/* unused harmony export parse */
/* unused harmony export tryParse */
/* harmony export (immutable) */ __webpack_exports__["c"] = fromValue;
/* unused harmony export ZERO */
/* unused harmony export UZERO */
/* unused harmony export ONE */
/* unused harmony export UONE */
/* unused harmony export NEG_ONE */
/* unused harmony export MAX_VALUE */
/* unused harmony export MAX_UNSIGNED_VALUE */
/* unused harmony export MIN_VALUE */
/* unused harmony export toInt */
/* unused harmony export toNumber */
/* harmony export (immutable) */ __webpack_exports__["g"] = toString;
/* unused harmony export getHighBits */
/* unused harmony export getHighBitsUnsigned */
/* unused harmony export getLowBits */
/* unused harmony export getLowBitsUnsigned */
/* unused harmony export getNumBitsAbs */
/* unused harmony export isZero */
/* unused harmony export isNegative */
/* unused harmony export isPositive */
/* unused harmony export isOdd */
/* unused harmony export isEven */
/* unused harmony export equals */
/* unused harmony export notEquals */
/* unused harmony export lessThan */
/* unused harmony export lessThanOrEqual */
/* unused harmony export greaterThan */
/* unused harmony export greaterThanOrEqual */
/* unused harmony export compare */
/* unused harmony export abs */
/* unused harmony export op_UnaryNegation */
/* unused harmony export op_Addition */
/* unused harmony export op_Subtraction */
/* unused harmony export op_Multiply */
/* unused harmony export op_Division */
/* unused harmony export op_Modulus */
/* unused harmony export op_LogicalNot */
/* unused harmony export op_BitwiseAnd */
/* unused harmony export op_BitwiseOr */
/* unused harmony export op_ExclusiveOr */
/* unused harmony export op_LeftShift */
/* unused harmony export op_RightShift */
/* unused harmony export op_RightShiftUnsigned */
/* unused harmony export toSigned */
/* unused harmony export toUnsigned */
/* harmony export (immutable) */ __webpack_exports__["f"] = toBytes;
/* unused harmony export toBytesLE */
/* unused harmony export toBytesBE */
/* harmony export (immutable) */ __webpack_exports__["b"] = fromBytes;
/* unused harmony export fromBytesLE */
/* unused harmony export fromBytesBE */
/* harmony export (immutable) */ __webpack_exports__["h"] = unixEpochMillisecondsToTicks;
/* harmony export (immutable) */ __webpack_exports__["e"] = ticksToUnixEpochMilliseconds;
/* harmony export (immutable) */ __webpack_exports__["d"] = makeRangeStepFunction;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__Int32__ = __webpack_require__(111);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__Util__ = __webpack_require__(3);
// Adapted from: https://github.com/dcodeIO/long.js/blob/f572e3a17d313730cf11eb838f6d2a5e31626f8a/src/long.js
// Apache License 2.0: https://github.com/dcodeIO/long.js/blob/master/LICENSE
/* tslint:disable */


/**
 * wasm optimizations, to do native i64 multiplication and divide
 */
var wasm = null;
try {
    wasm = new WebAssembly.Instance(new WebAssembly.Module(new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0, 1, 13, 2, 96, 0, 1, 127, 96, 4, 127, 127, 127, 127, 1, 127, 3, 7, 6, 0, 1, 1, 1, 1, 1, 6, 6, 1, 127, 1, 65, 0, 11, 7, 50, 6, 3, 109, 117, 108, 0, 1, 5, 100, 105, 118, 95, 115, 0, 2, 5, 100, 105, 118, 95, 117, 0, 3, 5, 114, 101, 109, 95, 115, 0, 4, 5, 114, 101, 109, 95, 117, 0, 5, 8, 103, 101, 116, 95, 104, 105, 103, 104, 0, 0, 10, 191, 1, 6, 4, 0, 35, 0, 11, 36, 1, 1, 126, 32, 0, 173, 32, 1, 173, 66, 32, 134, 132, 32, 2, 173, 32, 3, 173, 66, 32, 134, 132, 126, 34, 4, 66, 32, 135, 167, 36, 0, 32, 4, 167, 11, 36, 1, 1, 126, 32, 0, 173, 32, 1, 173, 66, 32, 134, 132, 32, 2, 173, 32, 3, 173, 66, 32, 134, 132, 127, 34, 4, 66, 32, 135, 167, 36, 0, 32, 4, 167, 11, 36, 1, 1, 126, 32, 0, 173, 32, 1, 173, 66, 32, 134, 132, 32, 2, 173, 32, 3, 173, 66, 32, 134, 132, 128, 34, 4, 66, 32, 135, 167, 36, 0, 32, 4, 167, 11, 36, 1, 1, 126, 32, 0, 173, 32, 1, 173, 66, 32, 134, 132, 32, 2, 173, 32, 3, 173, 66, 32, 134, 132, 129, 34, 4, 66, 32, 135, 167, 36, 0, 32, 4, 167, 11, 36, 1, 1, 126, 32, 0, 173, 32, 1, 173, 66, 32, 134, 132, 32, 2, 173, 32, 3, 173, 66, 32, 134, 132, 130, 34, 4, 66, 32, 135, 167, 36, 0, 32, 4, 167, 11])), {}).exports;
} catch (e) {}
// no wasm support :(

/**
 * Constructs a 64 bit two's-complement integer, given its low and high 32 bit values as *signed* integers.
 *  See the from* functions below for more convenient ways of constructing Longs.
 * @exports Long
 * @class A Long class for representing a 64 bit two's-complement integer value.
 * @param {number} low The low (signed) 32 bits of the long
 * @param {number} high The high (signed) 32 bits of the long
 * @param {boolean=} unsigned Whether unsigned or not, defaults to signed
 * @constructor
 */
function Long(low, high, unsigned) {
    /**
     * The low 32 bits as a signed value.
     * @type {number}
     */
    this.low = low | 0;
    /**
     * The high 32 bits as a signed value.
     * @type {number}
     */
    this.high = high | 0;
    /**
     * Whether unsigned or not.
     * @type {boolean}
     */
    this.unsigned = !!unsigned;
}
Long.prototype.GetHashCode = function () {
    return Object(__WEBPACK_IMPORTED_MODULE_1__Util__["b" /* combineHashCodes */])([this.unsigned ? 1 : 0, this.high, this.low]);
};
Long.prototype.Equals = function (x) {
    return equals(this, x);
};
Long.prototype.CompareTo = function (x) {
    return compare(this, x);
};
Long.prototype.toString = function (radix) {
    return toString(this, radix);
};
Long.prototype.toJSON = function () {
    return toString(this);
};
var neg = op_UnaryNegation;
var not = op_LogicalNot;
var add = op_Addition;
var sub = op_Subtraction;
var mul = op_Multiply;
var div = op_Division;
var mod = op_Modulus;
var shl = op_LeftShift;
var shr = op_RightShift;
var and = op_BitwiseAnd;
var or = op_BitwiseOr;
var xor = op_ExclusiveOr;
// The internal representation of a long is the two given signed, 32-bit values.
// We use 32-bit pieces because these are the size of integers on which
// Javascript performs bit-operations.  For operations like addition and
// multiplication, we split each number into 16 bit pieces, which can easily be
// multiplied within Javascript's floating-point representation without overflow
// or change in sign.
//
// In the algorithms below, we frequently reduce the negative case to the
// positive case by negating the input(s) and then post-processing the result.
// Note that we must ALWAYS check specially whether those values are MIN_VALUE
// (-2^63) because -MIN_VALUE == MIN_VALUE (since 2^63 cannot be represented as
// a positive number, it overflows back into a negative).  Not handling this
// case would often result in infinite recursion.
//
// Common constant values ZERO, ONE, NEG_ONE, etc. are defined below the from*
// methods on which they depend.
/**
 * An indicator used to reliably determine if an object is a Long or not.
 * @type {boolean}
 * @const
 * @private
 */
Long.prototype.__isLong__;
Object.defineProperty(Long.prototype, "__isLong__", { value: true });
/**
 * @function
 * @param {*} obj Object
 * @returns {boolean}
 * @inner
 */
function isLong(obj) {
    return (obj && obj["__isLong__"]) === true;
}
/**
 * A cache of the Long representations of small integer values.
 * @type {!Object}
 * @inner
 */
var INT_CACHE = {};
/**
 * A cache of the Long representations of small unsigned integer values.
 * @type {!Object}
 * @inner
 */
var UINT_CACHE = {};
/**
 * @param {number} value
 * @param {boolean=} unsigned
 * @returns {!Long}
 * @inner
 */
function fromInt(value, unsigned) {
    var obj, cachedObj, cache;
    if (unsigned) {
        value >>>= 0;
        if (cache = 0 <= value && value < 256) {
            cachedObj = UINT_CACHE[value];
            if (cachedObj) return cachedObj;
        }
        obj = fromBits(value, (value | 0) < 0 ? -1 : 0, true);
        if (cache) UINT_CACHE[value] = obj;
        return obj;
    } else {
        value |= 0;
        if (cache = -128 <= value && value < 128) {
            cachedObj = INT_CACHE[value];
            if (cachedObj) return cachedObj;
        }
        obj = fromBits(value, value < 0 ? -1 : 0, false);
        if (cache) INT_CACHE[value] = obj;
        return obj;
    }
}
/**
 * @param {number} value
 * @param {boolean=} unsigned
 * @returns {!Long}
 * @inner
 */
function fromNumber(value, unsigned) {
    if (isNaN(value)) return unsigned ? UZERO : ZERO;
    if (unsigned) {
        if (value < 0) return UZERO;
        if (value >= TWO_PWR_64_DBL) return MAX_UNSIGNED_VALUE;
    } else {
        if (value <= -TWO_PWR_63_DBL) return MIN_VALUE;
        if (value + 1 >= TWO_PWR_63_DBL) return MAX_VALUE;
    }
    if (value < 0) return op_UnaryNegation(fromNumber(-value, unsigned));
    return fromBits(value % TWO_PWR_32_DBL | 0, value / TWO_PWR_32_DBL | 0, unsigned);
}
/**
 * @param {number} value
 * @param {boolean} unsigned
 * @param {number} kind
 * @returns {!Long}
 * @inner
 */
function fromInteger(value, unsigned, kind) {
    var x;
    var xh = 0;
    switch (kind) {
        case 0:
            x = value << 24 >> 24;
            xh = x;
            break;
        case 4:
            x = value << 24 >>> 24;
            break;
        case 1:
            x = value << 16 >> 16;
            xh = x;
            break;
        case 5:
            x = value << 16 >>> 16;
            break;
        case 2:
            x = value >> 0;
            xh = x;
            break;
        case 6:
            x = value >>> 0;
    }
    return fromBits(x, xh >> 31, unsigned);
}
/**
 * @param {number} lowBits
 * @param {number} highBits
 * @param {boolean=} unsigned
 * @returns {!Long}
 * @inner
 */
function fromBits(lowBits, highBits, unsigned) {
    return new Long(lowBits, highBits, unsigned);
}
/**
 * @function
 * @param {number} base
 * @param {number} exponent
 * @returns {number}
 * @inner
 */
var pow_dbl = Math.pow; // Used 4 times (4*8 to 15+4)
/**
 * @param {string} str
 * @param {(boolean|number)=} unsigned
 * @param {number=} radix
 * @returns {!Long}
 * @inner
 */
function fromString(str, unsigned, radix) {
    var res = Object(__WEBPACK_IMPORTED_MODULE_0__Int32__["a" /* isValid */])(str, radix);
    if (res === null) {
        throw new Error("Input string was not in a correct format.");
    }
    str = res.sign + res.digits;
    radix = res.radix;
    if (str.length === 0) throw Error("empty string");
    if (str === "NaN" || str === "Infinity" || str === "+Infinity" || str === "-Infinity") return ZERO;
    if (typeof unsigned === "number") {
        // For goog.math.long compatibility
        radix = unsigned, unsigned = false;
    } else {
        unsigned = !!unsigned;
    }
    radix = radix || 10;
    if (radix < 2 || 36 < radix) throw RangeError("radix");
    var p = str.indexOf("-");
    if (p > 0) throw Error("interior hyphen");else if (p === 0) {
        return op_UnaryNegation(fromString(str.substring(1), unsigned, radix));
    }
    // Do several (8) digits each time through the loop, so as to
    // minimize the calls to the very expensive emulated div.
    var radixToPower = fromNumber(pow_dbl(radix, 8));
    var result = ZERO;
    for (var i = 0; i < str.length; i += 8) {
        var size = Math.min(8, str.length - i),
            value = parseInt(str.substring(i, i + size), radix);
        if (size < 8) {
            var power = fromNumber(pow_dbl(radix, size));
            result = op_Addition(op_Multiply(result, power), fromNumber(value));
        } else {
            result = op_Multiply(result, radixToPower);
            result = op_Addition(result, fromNumber(value));
        }
    }
    result.unsigned = unsigned;
    return result;
}
// For compatibility with Int32 module
function parse(str, radix) {
    return fromString(str, false, radix);
}
function tryParse(str, radix, defaultValue) {
    try {
        return [true, fromString(str, false, radix)];
    } catch (_a) {
        return [false, defaultValue];
    }
}
/**
 * @function
 * @param {!Long|number|string|!{low: number, high: number, unsigned: boolean}} val
 * @param {boolean=} unsigned
 * @returns {!Long}
 * @inner
 */
function fromValue(val, unsigned) {
    if (typeof val === "number") return fromNumber(val, unsigned);
    if (typeof val === "string") return fromString(val, unsigned);
    // Throws for non-objects, converts non-instanceof Long:
    return fromBits(val.low, val.high, typeof unsigned === "boolean" ? unsigned : val.unsigned);
}
// NOTE: the compiler should inline these constant values below and then remove these variables, so there should be
// no runtime penalty for these.
/**
 * @type {number}
 * @const
 * @inner
 */
var TWO_PWR_16_DBL = 1 << 16;
/**
 * @type {number}
 * @const
 * @inner
 */
var TWO_PWR_24_DBL = 1 << 24;
/**
 * @type {number}
 * @const
 * @inner
 */
var TWO_PWR_32_DBL = TWO_PWR_16_DBL * TWO_PWR_16_DBL;
/**
 * @type {number}
 * @const
 * @inner
 */
var TWO_PWR_64_DBL = TWO_PWR_32_DBL * TWO_PWR_32_DBL;
/**
 * @type {number}
 * @const
 * @inner
 */
var TWO_PWR_63_DBL = TWO_PWR_64_DBL / 2;
/**
 * @type {!Long}
 * @const
 * @inner
 */
var TWO_PWR_24 = fromInt(TWO_PWR_24_DBL);
/**
 * @type {!Long}
 * @inner
 */
var ZERO = fromInt(0);
/**
 * @type {!Long}
 * @inner
 */
var UZERO = fromInt(0, true);
/**
 * @type {!Long}
 * @inner
 */
var ONE = fromInt(1);
/**
 * @type {!Long}
 * @inner
 */
var UONE = fromInt(1, true);
/**
 * @type {!Long}
 * @inner
 */
var NEG_ONE = fromInt(-1);
/**
 * @type {!Long}
 * @inner
 */
var MAX_VALUE = fromBits(0xFFFFFFFF | 0, 0x7FFFFFFF | 0, false);
/**
 * @type {!Long}
 * @inner
 */
var MAX_UNSIGNED_VALUE = fromBits(0xFFFFFFFF | 0, 0xFFFFFFFF | 0, true);
/**
 * @type {!Long}
 * @inner
 */
var MIN_VALUE = fromBits(0, 0x80000000 | 0, false);
/**
 * Converts the Long to a 32 bit integer, assuming it is a 32 bit integer.
 * @returns {number}
 */
function toInt($this) {
    return $this.unsigned ? $this.low >>> 0 : $this.low;
}
;
/**
 * Converts the Long to a the nearest floating-point representation of this value (double, 53 bit mantissa).
 * @returns {number}
 */
function toNumber($this) {
    if ($this.unsigned) return ($this.high >>> 0) * TWO_PWR_32_DBL + ($this.low >>> 0);
    return $this.high * TWO_PWR_32_DBL + ($this.low >>> 0);
}
;
/**
 * Converts the Long to a string written in the specified radix.
 * @param {number=} radix Radix (2-36), defaults to 10
 * @returns {string}
 * @override
 * @throws {RangeError} If `radix` is out of range
 */
function toString($this, radix) {
    radix = radix || 10;
    if (radix < 2 || 36 < radix) throw RangeError("radix");
    if (isZero($this)) return "0";
    if (isNegative($this)) {
        // Unsigned Longs are never negative
        if (equals($this, MIN_VALUE)) {
            // We need to change the Long value before it can be negated, so we remove
            // the bottom-most digit in this base and then recurse to do the rest.
            var radixLong = fromNumber(radix),
                div = op_Division($this, radixLong),
                rem1 = op_Subtraction(op_Multiply(div, radixLong), $this);
            return toString(div, radix) + toInt(rem1).toString(radix);
        } else return "-" + toString(op_UnaryNegation($this), radix);
    }
    // Do several (6) digits each time through the loop, so as to
    // minimize the calls to the very expensive emulated div.
    var radixToPower = fromNumber(pow_dbl(radix, 6), $this.unsigned),
        rem = $this;
    var result = "";
    while (true) {
        var remDiv = op_Division(rem, radixToPower),
            intval = toInt(op_Subtraction(rem, op_Multiply(remDiv, radixToPower))) >>> 0,
            digits = intval.toString(radix);
        rem = remDiv;
        if (isZero(rem)) return digits + result;else {
            while (digits.length < 6) {
                digits = "0" + digits;
            }result = "" + digits + result;
        }
    }
}
;
/**
 * Gets the high 32 bits as a signed integer.
 * @returns {number} Signed high bits
 */
function getHighBits($this) {
    return $this.high;
}
;
/**
 * Gets the high 32 bits as an unsigned integer.
 * @returns {number} Unsigned high bits
 */
function getHighBitsUnsigned($this) {
    return $this.high >>> 0;
}
;
/**
 * Gets the low 32 bits as a signed integer.
 * @returns {number} Signed low bits
 */
function getLowBits($this) {
    return $this.low;
}
;
/**
 * Gets the low 32 bits as an unsigned integer.
 * @returns {number} Unsigned low bits
 */
function getLowBitsUnsigned($this) {
    return $this.low >>> 0;
}
;
/**
 * Gets the number of bits needed to represent the absolute value of this Long.
 * @returns {number}
 */
function getNumBitsAbs($this) {
    if (isNegative($this)) // Unsigned Longs are never negative
        return equals($this, MIN_VALUE) ? 64 : getNumBitsAbs(op_UnaryNegation($this));
    var val = $this.high != 0 ? $this.high : $this.low;
    for (var bit = 31; bit > 0; bit--) {
        if ((val & 1 << bit) != 0) break;
    }return $this.high != 0 ? bit + 33 : bit + 1;
}
;
/**
 * Tests if this Long's value equals zero.
 * @returns {boolean}
 */
function isZero($this) {
    return $this.high === 0 && $this.low === 0;
}
;
/**
 * Tests if this Long's value is negative.
 * @returns {boolean}
 */
function isNegative($this) {
    return !$this.unsigned && $this.high < 0;
}
;
/**
 * Tests if this Long's value is positive.
 * @returns {boolean}
 */
function isPositive($this) {
    return $this.unsigned || $this.high >= 0;
}
;
/**
 * Tests if this Long's value is odd.
 * @returns {boolean}
 */
function isOdd($this) {
    return ($this.low & 1) === 1;
}
;
/**
 * Tests if this Long's value is even.
 * @returns {boolean}
 */
function isEven($this) {
    return ($this.low & 1) === 0;
}
;
/**
 * Tests if this Long's value equals the specified's.
 * @param {!Long|number|string} other Other value
 * @returns {boolean}
 */
function equals($this, other) {
    if (!isLong(other)) other = fromValue(other);
    if ($this.unsigned !== other.unsigned && $this.high >>> 31 === 1 && other.high >>> 31 === 1) return false;
    return $this.high === other.high && $this.low === other.low;
}
;
/**
 * Tests if this Long's value differs from the specified's.
 * @param {!Long|number|string} other Other value
 * @returns {boolean}
 */
function notEquals($this, other) {
    return !equals($this, /* validates */other);
}
;
/**
 * Tests if this Long's value is less than the specified's.
 * @param {!Long|number|string} other Other value
 * @returns {boolean}
 */
function lessThan($this, other) {
    return compare($this, /* validates */other) < 0;
}
;
/**
 * Tests if this Long's value is less than or equal the specified's.
 * @param {!Long|number|string} other Other value
 * @returns {boolean}
 */
function lessThanOrEqual($this, other) {
    return compare($this, /* validates */other) <= 0;
}
;
/**
 * Tests if this Long's value is greater than the specified's.
 * @param {!Long|number|string} other Other value
 * @returns {boolean}
 */
function greaterThan($this, other) {
    return compare($this, /* validates */other) > 0;
}
;
/**
 * Tests if this Long's value is greater than or equal the specified's.
 * @param {!Long|number|string} other Other value
 * @returns {boolean}
 */
function greaterThanOrEqual($this, other) {
    return compare($this, /* validates */other) >= 0;
}
;
/**
 * Compares this Long's value with the specified's.
 * @param {!Long|number|string} other Other value
 * @returns {number} 0 if they are the same, 1 if the this is greater and -1
 *  if the given one is greater
 */
function compare($this, other) {
    if (!isLong(other)) other = fromValue(other);
    if (equals($this, other)) return 0;
    var thisNeg = isNegative($this),
        otherNeg = isNegative(other);
    if (thisNeg && !otherNeg) return -1;
    if (!thisNeg && otherNeg) return 1;
    // At this point the sign bits are the same
    if (!$this.unsigned) return isNegative(op_Subtraction($this, other)) ? -1 : 1;
    // Both are positive if at least one is unsigned
    return other.high >>> 0 > $this.high >>> 0 || other.high === $this.high && other.low >>> 0 > $this.low >>> 0 ? -1 : 1;
}
;
/**
 * Absolute value of the given number.
 */
function abs($this) {
    if (!$this.unsigned && isNegative($this)) return op_UnaryNegation($this);else return $this;
}
/**
 * Negates this Long's value.
 * @returns {!Long} Negated Long
 */
function op_UnaryNegation($this) {
    if (!$this.unsigned && equals($this, MIN_VALUE)) return MIN_VALUE;
    return op_Addition(op_LogicalNot($this), ONE);
}
;
/**
 * Returns the sum of this and the specified Long.
 * @param {!Long|number|string} addend Addend
 * @returns {!Long} Sum
 */
function op_Addition($this, addend) {
    if (!isLong(addend)) addend = fromValue(addend);
    // Divide each number into 4 chunks of 16 bits, and then sum the chunks.
    var a48 = $this.high >>> 16;
    var a32 = $this.high & 0xFFFF;
    var a16 = $this.low >>> 16;
    var a00 = $this.low & 0xFFFF;
    var b48 = addend.high >>> 16;
    var b32 = addend.high & 0xFFFF;
    var b16 = addend.low >>> 16;
    var b00 = addend.low & 0xFFFF;
    var c48 = 0,
        c32 = 0,
        c16 = 0,
        c00 = 0;
    c00 += a00 + b00;
    c16 += c00 >>> 16;
    c00 &= 0xFFFF;
    c16 += a16 + b16;
    c32 += c16 >>> 16;
    c16 &= 0xFFFF;
    c32 += a32 + b32;
    c48 += c32 >>> 16;
    c32 &= 0xFFFF;
    c48 += a48 + b48;
    c48 &= 0xFFFF;
    return fromBits(c16 << 16 | c00, c48 << 16 | c32, $this.unsigned);
}
;
/**
 * Returns the difference of this and the specified Long.
 * @param {!Long|number|string} subtrahend Subtrahend
 * @returns {!Long} Difference
 */
function op_Subtraction($this, subtrahend) {
    if (!isLong(subtrahend)) subtrahend = fromValue(subtrahend);
    return op_Addition($this, op_UnaryNegation(subtrahend));
}
;
/**
 * Returns the product of this and the specified Long.
 * @param {!Long|number|string} multiplier Multiplier
 * @returns {!Long} Product
 */
function op_Multiply($this, multiplier) {
    if (isZero($this)) return $this.unsigned ? UZERO : ZERO;
    if (!isLong(multiplier)) multiplier = fromValue(multiplier);
    // use wasm support if present
    if (wasm) {
        var low = wasm.mul($this.low, $this.high, multiplier.low, multiplier.high);
        return fromBits(low, wasm.get_high(), $this.unsigned);
    }
    if (isZero(multiplier)) return $this.unsigned ? UZERO : ZERO;
    if (equals($this, MIN_VALUE)) return isOdd(multiplier) ? MIN_VALUE : ZERO;
    if (equals(multiplier, MIN_VALUE)) return isOdd($this) ? MIN_VALUE : ZERO;
    if (isNegative($this)) {
        if (isNegative(multiplier)) return op_Multiply(op_UnaryNegation($this), op_UnaryNegation(multiplier));else return op_UnaryNegation(op_Multiply(op_UnaryNegation($this), multiplier));
    } else if (isNegative(multiplier)) return op_UnaryNegation(op_Multiply($this, op_UnaryNegation(multiplier)));
    // If both longs are small, use float multiplication
    if (lessThan($this, TWO_PWR_24) && lessThan(multiplier, TWO_PWR_24)) return fromNumber(toNumber($this) * toNumber(multiplier), $this.unsigned);
    // Divide each long into 4 chunks of 16 bits, and then add up 4x4 products.
    // We can skip products that would overflow.
    var a48 = $this.high >>> 16;
    var a32 = $this.high & 0xFFFF;
    var a16 = $this.low >>> 16;
    var a00 = $this.low & 0xFFFF;
    var b48 = multiplier.high >>> 16;
    var b32 = multiplier.high & 0xFFFF;
    var b16 = multiplier.low >>> 16;
    var b00 = multiplier.low & 0xFFFF;
    var c48 = 0,
        c32 = 0,
        c16 = 0,
        c00 = 0;
    c00 += a00 * b00;
    c16 += c00 >>> 16;
    c00 &= 0xFFFF;
    c16 += a16 * b00;
    c32 += c16 >>> 16;
    c16 &= 0xFFFF;
    c16 += a00 * b16;
    c32 += c16 >>> 16;
    c16 &= 0xFFFF;
    c32 += a32 * b00;
    c48 += c32 >>> 16;
    c32 &= 0xFFFF;
    c32 += a16 * b16;
    c48 += c32 >>> 16;
    c32 &= 0xFFFF;
    c32 += a00 * b32;
    c48 += c32 >>> 16;
    c32 &= 0xFFFF;
    c48 += a48 * b00 + a32 * b16 + a16 * b32 + a00 * b48;
    c48 &= 0xFFFF;
    return fromBits(c16 << 16 | c00, c48 << 16 | c32, $this.unsigned);
}
;
/**
 * Returns this Long divided by the specified. The result is signed if this Long is signed or
 *  unsigned if this Long is unsigned.
 * @param {!Long|number|string} divisor Divisor
 * @returns {!Long} Quotient
 */
function op_Division($this, divisor) {
    if (!isLong(divisor)) divisor = fromValue(divisor);
    if (isZero(divisor)) throw Error("division by zero");
    // use wasm support if present
    if (wasm) {
        // guard against signed division overflow: the largest
        // negative number / -1 would be 1 larger than the largest
        // positive number, due to two's complement.
        if (!$this.unsigned && $this.high === -0x80000000 && divisor.low === -1 && divisor.high === -1) {
            // be consistent with non-wasm code path
            return $this;
        }
        var low = ($this.unsigned ? wasm.div_u : wasm.div_s)($this.low, $this.high, divisor.low, divisor.high);
        return fromBits(low, wasm.get_high(), $this.unsigned);
    }
    if (isZero($this)) return $this.unsigned ? UZERO : ZERO;
    var approx, rem, res;
    if (!$this.unsigned) {
        // This section is only relevant for signed longs and is derived from the
        // closure library as a whole.
        if (equals($this, MIN_VALUE)) {
            if (equals(divisor, ONE) || equals(divisor, NEG_ONE)) return MIN_VALUE; // recall that -MIN_VALUE == MIN_VALUE
            else if (equals(divisor, MIN_VALUE)) return ONE;else {
                    // At this point, we have |other| >= 2, so |this/other| < |MIN_VALUE|.
                    var halfThis = op_RightShift($this, 1);
                    approx = op_LeftShift(op_Division(halfThis, divisor), 1);
                    if (equals(approx, ZERO)) {
                        return isNegative(divisor) ? ONE : NEG_ONE;
                    } else {
                        rem = op_Subtraction($this, op_Multiply(divisor, approx));
                        res = op_Addition(approx, op_Division(rem, divisor));
                        return res;
                    }
                }
        } else if (equals(divisor, MIN_VALUE)) return $this.unsigned ? UZERO : ZERO;
        if (isNegative($this)) {
            if (isNegative(divisor)) return op_Division(op_UnaryNegation($this), op_UnaryNegation(divisor));
            return op_UnaryNegation(op_Division(op_UnaryNegation($this), divisor));
        } else if (isNegative(divisor)) return op_UnaryNegation(op_Division($this, op_UnaryNegation(divisor)));
        res = ZERO;
    } else {
        // The algorithm below has not been made for unsigned longs. It's therefore
        // required to take special care of the MSB prior to running it.
        if (!divisor.unsigned) divisor = toUnsigned(divisor);
        if (greaterThan(divisor, $this)) return UZERO;
        if (greaterThan(divisor, op_RightShiftUnsigned($this, 1))) // 15 >>> 1 = 7 ; with divisor = 8 ; true
            return UONE;
        res = UZERO;
    }
    // Repeat the following until the remainder is less than other:  find a
    // floating-point that approximates remainder / other *from below*, add this
    // into the result, and subtract it from the remainder.  It is critical that
    // the approximate value is less than or equal to the real value so that the
    // remainder never becomes negative.
    rem = $this;
    while (greaterThanOrEqual(rem, divisor)) {
        // Approximate the result of division. This may be a little greater or
        // smaller than the actual value.
        approx = Math.max(1, Math.floor(toNumber(rem) / toNumber(divisor)));
        // We will tweak the approximate result by changing it in the 48-th digit or
        // the smallest non-fractional digit, whichever is larger.
        var log2 = Math.ceil(Math.log(approx) / Math.LN2),
            delta = log2 <= 48 ? 1 : pow_dbl(2, log2 - 48),

        // Decrease the approximation until it is smaller than the remainder.  Note
        // that if it is too large, the product overflows and is negative.
        approxRes = fromNumber(approx),
            approxRem = op_Multiply(approxRes, divisor);
        while (isNegative(approxRem) || greaterThan(approxRem, rem)) {
            approx -= delta;
            approxRes = fromNumber(approx, $this.unsigned);
            approxRem = op_Multiply(approxRes, divisor);
        }
        // We know the answer can't be zero... and actually, zero would cause
        // infinite recursion since we would make no progress.
        if (isZero(approxRes)) approxRes = ONE;
        res = op_Addition(res, approxRes);
        rem = op_Subtraction(rem, approxRem);
    }
    return res;
}
;
/**
 * Returns this Long modulo the specified.
 * @param {!Long|number|string} divisor Divisor
 * @returns {!Long} Remainder
 */
function op_Modulus($this, divisor) {
    if (!isLong(divisor)) divisor = fromValue(divisor);
    // use wasm support if present
    if (wasm) {
        var low = ($this.unsigned ? wasm.rem_u : wasm.rem_s)($this.low, $this.high, divisor.low, divisor.high);
        return fromBits(low, wasm.get_high(), $this.unsigned);
    }
    return op_Subtraction($this, op_Multiply(op_Division($this, divisor), divisor));
}
;
/**
 * Returns the bitwise NOT of this Long.
 * @returns {!Long}
 */
function op_LogicalNot($this) {
    return fromBits(~$this.low, ~$this.high, $this.unsigned);
}
;
/**
 * Returns the bitwise AND of this Long and the specified.
 * @param {!Long|number|string} other Other Long
 * @returns {!Long}
 */
function op_BitwiseAnd($this, other) {
    if (!isLong(other)) other = fromValue(other);
    return fromBits($this.low & other.low, $this.high & other.high, $this.unsigned);
}
;
/**
 * Returns the bitwise OR of this Long and the specified.
 * @param {!Long|number|string} other Other Long
 * @returns {!Long}
 */
function op_BitwiseOr($this, other) {
    if (!isLong(other)) other = fromValue(other);
    return fromBits($this.low | other.low, $this.high | other.high, $this.unsigned);
}
;
/**
 * Returns the bitwise XOR of this Long and the given one.
 * @param {!Long|number|string} other Other Long
 * @returns {!Long}
 */
function op_ExclusiveOr($this, other) {
    if (!isLong(other)) other = fromValue(other);
    return fromBits($this.low ^ other.low, $this.high ^ other.high, $this.unsigned);
}
;
/**
 * Returns this Long with bits shifted to the left by the given amount.
 * @param {number|!Long} numBits Number of bits
 * @returns {!Long} Shifted Long
 */
function op_LeftShift($this, numBits) {
    if (isLong(numBits)) numBits = toInt(numBits);
    if ((numBits &= 63) === 0) return $this;else if (numBits < 32) return fromBits($this.low << numBits, $this.high << numBits | $this.low >>> 32 - numBits, $this.unsigned);else return fromBits(0, $this.low << numBits - 32, $this.unsigned);
}
;
/**
 * Returns this Long with bits arithmetically shifted to the right by the given amount.
 * @param {number|!Long} numBits Number of bits
 * @returns {!Long} Shifted Long
 */
function op_RightShift($this, numBits) {
    if (isLong(numBits)) numBits = toInt(numBits);
    if ((numBits &= 63) === 0) return $this;else if (numBits < 32) return fromBits($this.low >>> numBits | $this.high << 32 - numBits, $this.high >> numBits, $this.unsigned);else return fromBits($this.high >> numBits - 32, $this.high >= 0 ? 0 : -1, $this.unsigned);
}
;
/**
 * Returns this Long with bits logically shifted to the right by the given amount.
 * @param {number|!Long} numBits Number of bits
 * @returns {!Long} Shifted Long
 */
function op_RightShiftUnsigned($this, numBits) {
    if (isLong(numBits)) numBits = toInt(numBits);
    numBits &= 63;
    if (numBits === 0) return $this;else {
        var high = $this.high;
        if (numBits < 32) {
            var low = $this.low;
            return fromBits(low >>> numBits | high << 32 - numBits, high >>> numBits, $this.unsigned);
        } else if (numBits === 32) return fromBits(high, 0, $this.unsigned);else return fromBits(high >>> numBits - 32, 0, $this.unsigned);
    }
}
;
/**
 * Converts this Long to signed.
 * @returns {!Long} Signed long
 */
function toSigned($this) {
    if (!$this.unsigned) return $this;
    return fromBits($this.low, $this.high, false);
}
;
/**
 * Converts this Long to unsigned.
 * @returns {!Long} Unsigned long
 */
function toUnsigned($this) {
    if ($this.unsigned) return $this;
    return fromBits($this.low, $this.high, true);
}
;
/**
 * Converts this Long to its byte representation.
 * @param {boolean=} le Whether little or big endian, defaults to big endian
 * @returns {!Array.<number>} Byte representation
 */
function toBytes($this, le) {
    return le ? toBytesLE($this) : toBytesBE($this);
}
;
/**
 * Converts this Long to its little endian byte representation.
 * @returns {!Array.<number>} Little endian byte representation
 */
function toBytesLE($this) {
    var hi = $this.high,
        lo = $this.low;
    return [lo & 0xff, lo >>> 8 & 0xff, lo >>> 16 & 0xff, lo >>> 24, hi & 0xff, hi >>> 8 & 0xff, hi >>> 16 & 0xff, hi >>> 24];
}
;
/**
 * Converts this Long to its big endian byte representation.
 * @returns {!Array.<number>} Big endian byte representation
 */
function toBytesBE($this) {
    var hi = $this.high,
        lo = $this.low;
    return [hi >>> 24, hi >>> 16 & 0xff, hi >>> 8 & 0xff, hi & 0xff, lo >>> 24, lo >>> 16 & 0xff, lo >>> 8 & 0xff, lo & 0xff];
}
;
/**
 * Creates a Long from its byte representation.
 * @param {!Array.<number>} bytes Byte representation
 * @param {boolean=} unsigned Whether unsigned or not, defaults to signed
 * @param {boolean=} le Whether little or big endian, defaults to big endian
 * @returns {Long} The corresponding Long value
 */
function fromBytes(bytes, unsigned, le) {
    return le ? fromBytesLE(bytes, unsigned) : fromBytesBE(bytes, unsigned);
}
;
/**
 * Creates a Long from its little endian byte representation.
 * @param {!Array.<number>} bytes Little endian byte representation
 * @param {boolean=} unsigned Whether unsigned or not, defaults to signed
 * @returns {Long} The corresponding Long value
 */
function fromBytesLE(bytes, unsigned) {
    return new Long(bytes[0] | bytes[1] << 8 | bytes[2] << 16 | bytes[3] << 24, bytes[4] | bytes[5] << 8 | bytes[6] << 16 | bytes[7] << 24, unsigned);
}
;
/**
 * Creates a Long from its big endian byte representation.
 * @param {!Array.<number>} bytes Big endian byte representation
 * @param {boolean=} unsigned Whether unsigned or not, defaults to signed
 * @returns {Long} The corresponding Long value
 */
function fromBytesBE(bytes, unsigned) {
    return new Long(bytes[4] << 24 | bytes[5] << 16 | bytes[6] << 8 | bytes[7], bytes[0] << 24 | bytes[1] << 16 | bytes[2] << 8 | bytes[3], unsigned);
}
;
function unixEpochMillisecondsToTicks(ms, offset) {
    return op_Multiply(op_Addition(op_Addition(fromNumber(ms), 62135596800000), offset), 10000);
}
function ticksToUnixEpochMilliseconds(ticks) {
    return toNumber(op_Subtraction(op_Division(ticks, 10000), 62135596800000));
}
function makeRangeStepFunction(step, last, unsigned) {
    var zero = unsigned ? UZERO : ZERO;
    return function (x) {
        return greaterThan(step, zero) && lessThanOrEqual(x, last) || lessThan(step, zero) && greaterThanOrEqual(x, last) ? [x, op_Addition(x, step)] : null;
    };
}

/***/ }),
/* 50 */
/***/ (function(module, exports, __webpack_require__) {

// 0 -> Array#forEach
// 1 -> Array#map
// 2 -> Array#filter
// 3 -> Array#some
// 4 -> Array#every
// 5 -> Array#find
// 6 -> Array#findIndex
var ctx = __webpack_require__(17);
var IObject = __webpack_require__(39);
var toObject = __webpack_require__(15);
var toLength = __webpack_require__(25);
var asc = __webpack_require__(120);
module.exports = function (TYPE, $create) {
  var IS_MAP = TYPE == 1;
  var IS_FILTER = TYPE == 2;
  var IS_SOME = TYPE == 3;
  var IS_EVERY = TYPE == 4;
  var IS_FIND_INDEX = TYPE == 6;
  var NO_HOLES = TYPE == 5 || IS_FIND_INDEX;
  var create = $create || asc;
  return function ($this, callbackfn, that) {
    var O = toObject($this);
    var self = IObject(O);
    var f = ctx(callbackfn, that, 3);
    var length = toLength(self.length);
    var index = 0;
    var result = IS_MAP ? create($this, length) : IS_FILTER ? create($this, 0) : undefined;
    var val, res;
    for (;length > index; index++) if (NO_HOLES || index in self) {
      val = self[index];
      res = f(val, index, O);
      if (TYPE) {
        if (IS_MAP) result[index] = res;   // map
        else if (res) switch (TYPE) {
          case 3: return true;             // some
          case 5: return val;              // find
          case 6: return index;            // findIndex
          case 2: result.push(val);        // filter
        } else if (IS_EVERY) return false; // every
      }
    }
    return IS_FIND_INDEX ? -1 : IS_SOME || IS_EVERY ? IS_EVERY : result;
  };
};


/***/ }),
/* 51 */
/***/ (function(module, exports, __webpack_require__) {

var ctx = __webpack_require__(17);
var call = __webpack_require__(64);
var isArrayIter = __webpack_require__(65);
var anObject = __webpack_require__(8);
var toLength = __webpack_require__(25);
var getIterFn = __webpack_require__(44);
var BREAK = {};
var RETURN = {};
var exports = module.exports = function (iterable, entries, fn, that, ITERATOR) {
  var iterFn = ITERATOR ? function () { return iterable; } : getIterFn(iterable);
  var f = ctx(fn, that, entries ? 2 : 1);
  var index = 0;
  var length, step, iterator, result;
  if (typeof iterFn != 'function') throw TypeError(iterable + ' is not iterable!');
  // fast case for arrays with default iterator
  if (isArrayIter(iterFn)) for (length = toLength(iterable.length); length > index; index++) {
    result = entries ? f(anObject(step = iterable[index])[0], step[1]) : f(iterable[index]);
    if (result === BREAK || result === RETURN) return result;
  } else for (iterator = iterFn.call(iterable); !(step = iterator.next()).done;) {
    result = call(iterator, f, step.value, entries);
    if (result === BREAK || result === RETURN) return result;
  }
};
exports.BREAK = BREAK;
exports.RETURN = RETURN;


/***/ }),
/* 52 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;

var _defineProperty = __webpack_require__(53);

var _defineProperty2 = _interopRequireDefault(_defineProperty);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = function () {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      (0, _defineProperty2.default)(target, descriptor.key, descriptor);
    }
  }

  return function (Constructor, protoProps, staticProps) {
    if (protoProps) defineProperties(Constructor.prototype, protoProps);
    if (staticProps) defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();

/***/ }),
/* 53 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(128), __esModule: true };

/***/ }),
/* 54 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;

exports.default = function (instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
};

/***/ }),
/* 55 */
/***/ (function(module, exports, __webpack_require__) {

// most Object methods by ES6 should accept primitives
var $export = __webpack_require__(2);
var core = __webpack_require__(0);
var fails = __webpack_require__(10);
module.exports = function (KEY, exec) {
  var fn = (core.Object || {})[KEY] || Object[KEY];
  var exp = {};
  exp[KEY] = exec(fn);
  $export($export.S + $export.F * fails(function () { fn(1); }), 'Object', exp);
};


/***/ }),
/* 56 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;

var _defineProperty = __webpack_require__(53);

var _defineProperty2 = _interopRequireDefault(_defineProperty);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = function (obj, key, value) {
  if (key in obj) {
    (0, _defineProperty2.default)(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
};

/***/ }),
/* 57 */
/***/ (function(module, exports) {

module.exports = require("assert");

/***/ }),
/* 58 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var LIBRARY = __webpack_require__(35);
var $export = __webpack_require__(2);
var redefine = __webpack_require__(37);
var hide = __webpack_require__(7);
var has = __webpack_require__(11);
var Iterators = __webpack_require__(14);
var $iterCreate = __webpack_require__(89);
var setToStringTag = __webpack_require__(27);
var getPrototypeOf = __webpack_require__(63);
var ITERATOR = __webpack_require__(1)('iterator');
var BUGGY = !([].keys && 'next' in [].keys()); // Safari has buggy iterators w/o `next`
var FF_ITERATOR = '@@iterator';
var KEYS = 'keys';
var VALUES = 'values';

var returnThis = function () { return this; };

module.exports = function (Base, NAME, Constructor, next, DEFAULT, IS_SET, FORCED) {
  $iterCreate(Constructor, NAME, next);
  var getMethod = function (kind) {
    if (!BUGGY && kind in proto) return proto[kind];
    switch (kind) {
      case KEYS: return function keys() { return new Constructor(this, kind); };
      case VALUES: return function values() { return new Constructor(this, kind); };
    } return function entries() { return new Constructor(this, kind); };
  };
  var TAG = NAME + ' Iterator';
  var DEF_VALUES = DEFAULT == VALUES;
  var VALUES_BUG = false;
  var proto = Base.prototype;
  var $native = proto[ITERATOR] || proto[FF_ITERATOR] || DEFAULT && proto[DEFAULT];
  var $default = (!BUGGY && $native) || getMethod(DEFAULT);
  var $entries = DEFAULT ? !DEF_VALUES ? $default : getMethod('entries') : undefined;
  var $anyNative = NAME == 'Array' ? proto.entries || $native : $native;
  var methods, key, IteratorPrototype;
  // Fix native
  if ($anyNative) {
    IteratorPrototype = getPrototypeOf($anyNative.call(new Base()));
    if (IteratorPrototype !== Object.prototype && IteratorPrototype.next) {
      // Set @@toStringTag to native iterators
      setToStringTag(IteratorPrototype, TAG, true);
      // fix for some old engines
      if (!LIBRARY && !has(IteratorPrototype, ITERATOR)) hide(IteratorPrototype, ITERATOR, returnThis);
    }
  }
  // fix Array#{values, @@iterator}.name in V8 / FF
  if (DEF_VALUES && $native && $native.name !== VALUES) {
    VALUES_BUG = true;
    $default = function values() { return $native.call(this); };
  }
  // Define iterator
  if ((!LIBRARY || FORCED) && (BUGGY || VALUES_BUG || !proto[ITERATOR])) {
    hide(proto, ITERATOR, $default);
  }
  // Plug for library
  Iterators[NAME] = $default;
  Iterators[TAG] = returnThis;
  if (DEFAULT) {
    methods = {
      values: DEF_VALUES ? $default : getMethod(VALUES),
      keys: IS_SET ? $default : getMethod(KEYS),
      entries: $entries
    };
    if (FORCED) for (key in methods) {
      if (!(key in proto)) redefine(proto, key, methods[key]);
    } else $export($export.P + $export.F * (BUGGY || VALUES_BUG), NAME, methods);
  }
  return methods;
};


/***/ }),
/* 59 */
/***/ (function(module, exports) {

module.exports = function (it) {
  if (typeof it != 'function') throw TypeError(it + ' is not a function!');
  return it;
};


/***/ }),
/* 60 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = !__webpack_require__(9) && !__webpack_require__(10)(function () {
  return Object.defineProperty(__webpack_require__(61)('div'), 'a', { get: function () { return 7; } }).a != 7;
});


/***/ }),
/* 61 */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(4);
var document = __webpack_require__(5).document;
// typeof document.createElement is 'object' in old IE
var is = isObject(document) && isObject(document.createElement);
module.exports = function (it) {
  return is ? document.createElement(it) : {};
};


/***/ }),
/* 62 */
/***/ (function(module, exports, __webpack_require__) {

var has = __webpack_require__(11);
var toIObject = __webpack_require__(12);
var arrayIndexOf = __webpack_require__(91)(false);
var IE_PROTO = __webpack_require__(41)('IE_PROTO');

module.exports = function (object, names) {
  var O = toIObject(object);
  var i = 0;
  var result = [];
  var key;
  for (key in O) if (key != IE_PROTO) has(O, key) && result.push(key);
  // Don't enum bug & hidden keys
  while (names.length > i) if (has(O, key = names[i++])) {
    ~arrayIndexOf(result, key) || result.push(key);
  }
  return result;
};


/***/ }),
/* 63 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.9 / 15.2.3.2 Object.getPrototypeOf(O)
var has = __webpack_require__(11);
var toObject = __webpack_require__(15);
var IE_PROTO = __webpack_require__(41)('IE_PROTO');
var ObjectProto = Object.prototype;

module.exports = Object.getPrototypeOf || function (O) {
  O = toObject(O);
  if (has(O, IE_PROTO)) return O[IE_PROTO];
  if (typeof O.constructor == 'function' && O instanceof O.constructor) {
    return O.constructor.prototype;
  } return O instanceof Object ? ObjectProto : null;
};


/***/ }),
/* 64 */
/***/ (function(module, exports, __webpack_require__) {

// call something on iterator step with safe closing on error
var anObject = __webpack_require__(8);
module.exports = function (iterator, fn, value, entries) {
  try {
    return entries ? fn(anObject(value)[0], value[1]) : fn(value);
  // 7.4.6 IteratorClose(iterator, completion)
  } catch (e) {
    var ret = iterator['return'];
    if (ret !== undefined) anObject(ret.call(iterator));
    throw e;
  }
};


/***/ }),
/* 65 */
/***/ (function(module, exports, __webpack_require__) {

// check on default Array iterator
var Iterators = __webpack_require__(14);
var ITERATOR = __webpack_require__(1)('iterator');
var ArrayProto = Array.prototype;

module.exports = function (it) {
  return it !== undefined && (Iterators.Array === it || ArrayProto[ITERATOR] === it);
};


/***/ }),
/* 66 */
/***/ (function(module, exports, __webpack_require__) {

// getting tag from 19.1.3.6 Object.prototype.toString()
var cof = __webpack_require__(40);
var TAG = __webpack_require__(1)('toStringTag');
// ES3 wrong here
var ARG = cof(function () { return arguments; }()) == 'Arguments';

// fallback for IE11 Script Access Denied error
var tryGet = function (it, key) {
  try {
    return it[key];
  } catch (e) { /* empty */ }
};

module.exports = function (it) {
  var O, T, B;
  return it === undefined ? 'Undefined' : it === null ? 'Null'
    // @@toStringTag case
    : typeof (T = tryGet(O = Object(it), TAG)) == 'string' ? T
    // builtinTag case
    : ARG ? cof(O)
    // ES3 arguments fallback
    : (B = cof(O)) == 'Object' && typeof O.callee == 'function' ? 'Arguments' : B;
};


/***/ }),
/* 67 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;

var _iterator = __webpack_require__(20);

var _iterator2 = _interopRequireDefault(_iterator);

var _symbol = __webpack_require__(101);

var _symbol2 = _interopRequireDefault(_symbol);

var _typeof = typeof _symbol2.default === "function" && typeof _iterator2.default === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof _symbol2.default === "function" && obj.constructor === _symbol2.default && obj !== _symbol2.default.prototype ? "symbol" : typeof obj; };

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = typeof _symbol2.default === "function" && _typeof(_iterator2.default) === "symbol" ? function (obj) {
  return typeof obj === "undefined" ? "undefined" : _typeof(obj);
} : function (obj) {
  return obj && typeof _symbol2.default === "function" && obj.constructor === _symbol2.default && obj !== _symbol2.default.prototype ? "symbol" : typeof obj === "undefined" ? "undefined" : _typeof(obj);
};

/***/ }),
/* 68 */
/***/ (function(module, exports, __webpack_require__) {

// 7.2.2 IsArray(argument)
var cof = __webpack_require__(40);
module.exports = Array.isArray || function isArray(arg) {
  return cof(arg) == 'Array';
};


/***/ }),
/* 69 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.7 / 15.2.3.4 Object.getOwnPropertyNames(O)
var $keys = __webpack_require__(62);
var hiddenKeys = __webpack_require__(43).concat('length', 'prototype');

exports.f = Object.getOwnPropertyNames || function getOwnPropertyNames(O) {
  return $keys(O, hiddenKeys);
};


/***/ }),
/* 70 */
/***/ (function(module, exports, __webpack_require__) {

var pIE = __webpack_require__(31);
var createDesc = __webpack_require__(18);
var toIObject = __webpack_require__(12);
var toPrimitive = __webpack_require__(36);
var has = __webpack_require__(11);
var IE8_DOM_DEFINE = __webpack_require__(60);
var gOPD = Object.getOwnPropertyDescriptor;

exports.f = __webpack_require__(9) ? gOPD : function getOwnPropertyDescriptor(O, P) {
  O = toIObject(O);
  P = toPrimitive(P, true);
  if (IE8_DOM_DEFINE) try {
    return gOPD(O, P);
  } catch (e) { /* empty */ }
  if (has(O, P)) return createDesc(!pIE.f.call(O, P), O[P]);
};


/***/ }),
/* 71 */
/***/ (function(module, exports) {



/***/ }),
/* 72 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;

var _isIterable2 = __webpack_require__(73);

var _isIterable3 = _interopRequireDefault(_isIterable2);

var _getIterator2 = __webpack_require__(21);

var _getIterator3 = _interopRequireDefault(_getIterator2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = function () {
  function sliceIterator(arr, i) {
    var _arr = [];
    var _n = true;
    var _d = false;
    var _e = undefined;

    try {
      for (var _i = (0, _getIterator3.default)(arr), _s; !(_n = (_s = _i.next()).done); _n = true) {
        _arr.push(_s.value);

        if (i && _arr.length === i) break;
      }
    } catch (err) {
      _d = true;
      _e = err;
    } finally {
      try {
        if (!_n && _i["return"]) _i["return"]();
      } finally {
        if (_d) throw _e;
      }
    }

    return _arr;
  }

  return function (arr, i) {
    if (Array.isArray(arr)) {
      return arr;
    } else if ((0, _isIterable3.default)(Object(arr))) {
      return sliceIterator(arr, i);
    } else {
      throw new TypeError("Invalid attempt to destructure non-iterable instance");
    }
  };
}();

/***/ }),
/* 73 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(115), __esModule: true };

/***/ }),
/* 74 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 19.1.2.1 Object.assign(target, source, ...)
var getKeys = __webpack_require__(19);
var gOPS = __webpack_require__(48);
var pIE = __webpack_require__(31);
var toObject = __webpack_require__(15);
var IObject = __webpack_require__(39);
var $assign = Object.assign;

// should work with symbols and should have deterministic property order (V8 bug)
module.exports = !$assign || __webpack_require__(10)(function () {
  var A = {};
  var B = {};
  // eslint-disable-next-line no-undef
  var S = Symbol();
  var K = 'abcdefghijklmnopqrst';
  A[S] = 7;
  K.split('').forEach(function (k) { B[k] = k; });
  return $assign({}, A)[S] != 7 || Object.keys($assign({}, B)).join('') != K;
}) ? function assign(target, source) { // eslint-disable-line no-unused-vars
  var T = toObject(target);
  var aLen = arguments.length;
  var index = 1;
  var getSymbols = gOPS.f;
  var isEnum = pIE.f;
  while (aLen > index) {
    var S = IObject(arguments[index++]);
    var keys = getSymbols ? getKeys(S).concat(getSymbols(S)) : getKeys(S);
    var length = keys.length;
    var j = 0;
    var key;
    while (length > j) if (isEnum.call(S, key = keys[j++])) T[key] = S[key];
  } return T;
} : $assign;


/***/ }),
/* 75 */
/***/ (function(module, exports, __webpack_require__) {

var hide = __webpack_require__(7);
module.exports = function (target, src, safe) {
  for (var key in src) {
    if (safe && target[key]) target[key] = src[key];
    else hide(target, key, src[key]);
  } return target;
};


/***/ }),
/* 76 */
/***/ (function(module, exports) {

module.exports = function (it, Constructor, name, forbiddenField) {
  if (!(it instanceof Constructor) || (forbiddenField !== undefined && forbiddenField in it)) {
    throw TypeError(name + ': incorrect invocation!');
  } return it;
};


/***/ }),
/* 77 */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(4);
module.exports = function (it, TYPE) {
  if (!isObject(it) || it._t !== TYPE) throw TypeError('Incompatible receiver, ' + TYPE + ' required!');
  return it;
};


/***/ }),
/* 78 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(136), __esModule: true };

/***/ }),
/* 79 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export append */
/* unused harmony export filter */
/* unused harmony export fill */
/* unused harmony export getSubArray */
/* unused harmony export last */
/* unused harmony export tryLast */
/* unused harmony export mapIndexed */
/* unused harmony export map */
/* unused harmony export mapIndexed2 */
/* unused harmony export map2 */
/* unused harmony export mapIndexed3 */
/* unused harmony export map3 */
/* unused harmony export mapFold */
/* unused harmony export mapFoldBack */
/* unused harmony export indexed */
/* unused harmony export truncate */
/* unused harmony export concat */
/* unused harmony export collect */
/* unused harmony export countBy */
/* unused harmony export distinctBy */
/* unused harmony export distinct */
/* unused harmony export where */
/* unused harmony export contains */
/* unused harmony export except */
/* unused harmony export groupBy */
/* unused harmony export empty */
/* unused harmony export singleton */
/* unused harmony export initialize */
/* unused harmony export pairwise */
/* unused harmony export replicate */
/* unused harmony export copy */
/* unused harmony export reverse */
/* unused harmony export scan */
/* unused harmony export scanBack */
/* unused harmony export skip */
/* unused harmony export skipWhile */
/* unused harmony export take */
/* unused harmony export takeWhile */
/* unused harmony export addRangeInPlace */
/* unused harmony export removeInPlace */
/* unused harmony export copyTo */
/* unused harmony export partition */
/* unused harmony export find */
/* unused harmony export tryFind */
/* unused harmony export findIndex */
/* unused harmony export tryFindIndex */
/* unused harmony export pick */
/* unused harmony export tryPick */
/* unused harmony export findBack */
/* unused harmony export tryFindBack */
/* harmony export (immutable) */ __webpack_exports__["a"] = findIndexBack;
/* harmony export (immutable) */ __webpack_exports__["e"] = tryFindIndexBack;
/* unused harmony export choose */
/* unused harmony export foldIndexed */
/* unused harmony export fold */
/* unused harmony export iterate */
/* unused harmony export iterateIndexed */
/* unused harmony export iterate2 */
/* unused harmony export iterateIndexed2 */
/* unused harmony export isEmpty */
/* unused harmony export forAll */
/* harmony export (immutable) */ __webpack_exports__["d"] = permute;
/* unused harmony export setSlice */
/* unused harmony export sortInPlaceBy */
/* unused harmony export sortInPlace */
/* unused harmony export sort */
/* unused harmony export sortBy */
/* unused harmony export sortDescending */
/* unused harmony export sortByDescending */
/* unused harmony export sortWith */
/* unused harmony export unfold */
/* unused harmony export unzip */
/* unused harmony export unzip3 */
/* unused harmony export zip */
/* unused harmony export zip3 */
/* unused harmony export chunkBySize */
/* unused harmony export splitAt */
/* unused harmony export compareWith */
/* unused harmony export equalsWith */
/* unused harmony export exactlyOne */
/* unused harmony export head */
/* unused harmony export tryHead */
/* unused harmony export tail */
/* unused harmony export item */
/* unused harmony export tryItem */
/* unused harmony export foldBackIndexed */
/* harmony export (immutable) */ __webpack_exports__["b"] = foldBack;
/* unused harmony export foldIndexed2 */
/* unused harmony export fold2 */
/* unused harmony export foldBackIndexed2 */
/* unused harmony export foldBack2 */
/* unused harmony export reduce */
/* unused harmony export reduceBack */
/* unused harmony export forAll2 */
/* unused harmony export existsOffset */
/* unused harmony export exists */
/* unused harmony export existsOffset2 */
/* unused harmony export exists2 */
/* unused harmony export sum */
/* unused harmony export sumBy */
/* unused harmony export maxBy */
/* unused harmony export max */
/* unused harmony export minBy */
/* unused harmony export min */
/* unused harmony export average */
/* unused harmony export averageBy */
/* unused harmony export ofSeq */
/* harmony export (immutable) */ __webpack_exports__["c"] = ofList;
/* unused harmony export toList */
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_get_iterator__ = __webpack_require__(21);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_get_iterator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_get_iterator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_toConsumableArray__ = __webpack_require__(28);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_toConsumableArray___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_toConsumableArray__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_array_from__ = __webpack_require__(13);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_array_from___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_array_from__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__Option__ = __webpack_require__(22);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__Util__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__Map__ = __webpack_require__(80);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__Seq__ = __webpack_require__(32);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__Set__ = __webpack_require__(81);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__Types__ = __webpack_require__(16);










function indexNotFound() {
  throw new Error("An index satisfying the predicate was not found in the collection.");
}

function append(array1, array2, cons) {
  if (ArrayBuffer.isView(array1)) {
    var len1 = array1.length | 0;
    var len2 = array2.length | 0;
    var newArray = new cons(len1 + len2);

    for (var i = 0; i <= len1 - 1; i++) {
      newArray[i] = array1[i];
    }

    for (var i$$1 = 0; i$$1 <= len2 - 1; i$$1++) {
      newArray[i$$1 + len1] = array2[i$$1];
    }

    return newArray;
  } else {
    return array1.concat(array2);
  }
}
function filter(predicate, array) {
  return array.filter(predicate);
}
function fill(target, targetIndex, count, value) {
  target.fill(value, targetIndex, targetIndex + count);
  return target;
}
function getSubArray(array$$3, start$$1, count$$2) {
  return array$$3.slice(start$$1, start$$1 + count$$2);
}
function last(array$$5) {
  if (array$$5.length === 0) {
    throw new Error("The input array was empty" + "\\nParameter name: " + "array");
  }

  return array$$5[array$$5.length - 1];
}
function tryLast(array$$6) {
  if (array$$6.length === 0) {
    return null;
  } else {
    return Object(__WEBPACK_IMPORTED_MODULE_3__Option__["c" /* some */])(array$$6[array$$6.length - 1]);
  }
}
function mapIndexed(f, source, cons$$1) {
  if (ArrayBuffer.isView(source)) {
    var len = source.length | 0;
    var target$$1 = new cons$$1(len);

    for (var i$$2 = 0; i$$2 <= len - 1; i$$2++) {
      target$$1[i$$2] = f(i$$2, source[i$$2]);
    }

    return target$$1;
  } else {
    return source.map(function mapping(x, i$$3) {
      return f(i$$3, x);
    });
  }
}
function map(f$$1, source$$1, cons$$2) {
  if (ArrayBuffer.isView(source$$1)) {
    var len$$1 = source$$1.length | 0;
    var target$$2 = new cons$$2(len$$1);

    for (var i$$4 = 0; i$$4 <= len$$1 - 1; i$$4++) {
      target$$2[i$$4] = f$$1(source$$1[i$$4]);
    }

    return target$$2;
  } else {
    return source$$1.map(function mapping$$1(x$$1) {
      return f$$1(x$$1);
    });
  }
}
function mapIndexed2(f$$2, source1, source2, cons$$3) {
  if (source1.length !== source2.length) {
    throw new Error("Arrays had different lengths");
  }

  var result = new cons$$3(source1.length);

  for (var i$$5 = 0; i$$5 <= source1.length - 1; i$$5++) {
    result[i$$5] = f$$2(i$$5, source1[i$$5], source2[i$$5]);
  }

  return result;
}
function map2(f$$3, source1$$1, source2$$1, cons$$4) {
  if (source1$$1.length !== source2$$1.length) {
    throw new Error("Arrays had different lengths");
  }

  var result$$1 = new cons$$4(source1$$1.length);

  for (var i$$6 = 0; i$$6 <= source1$$1.length - 1; i$$6++) {
    result$$1[i$$6] = f$$3(source1$$1[i$$6], source2$$1[i$$6]);
  }

  return result$$1;
}
function mapIndexed3(f$$4, source1$$2, source2$$2, source3, cons$$5) {
  if (source1$$2.length !== source2$$2.length ? true : source2$$2.length !== source3.length) {
    throw new Error("Arrays had different lengths");
  }

  var result$$2 = new cons$$5(source1$$2.length);

  for (var i$$7 = 0; i$$7 <= source1$$2.length - 1; i$$7++) {
    result$$2[i$$7] = f$$4(i$$7, source1$$2[i$$7], source2$$2[i$$7], source3[i$$7]);
  }

  return result$$2;
}
function map3(f$$5, source1$$3, source2$$3, source3$$1, cons$$6) {
  if (source1$$3.length !== source2$$3.length ? true : source2$$3.length !== source3$$1.length) {
    throw new Error("Arrays had different lengths");
  }

  var result$$3 = new cons$$6(source1$$3.length);

  for (var i$$8 = 0; i$$8 <= source1$$3.length - 1; i$$8++) {
    result$$3[i$$8] = f$$5(source1$$3[i$$8], source2$$3[i$$8], source3$$1[i$$8]);
  }

  return result$$3;
}
function mapFold(mapping$$2, state, array$$9, cons$$7) {
  var matchValue = array$$9.length | 0;

  if (matchValue === 0) {
    return [[], state];
  } else {
    var len$$2 = matchValue | 0;
    var acc = state;
    var res = new cons$$7(len$$2);

    for (var i$$9 = 0; i$$9 <= array$$9.length - 1; i$$9++) {
      var patternInput = mapping$$2(acc, array$$9[i$$9]);
      res[i$$9] = patternInput[0];
      acc = patternInput[1];
    }

    return [res, acc];
  }
}
function mapFoldBack(mapping$$3, array$$10, state$$1, cons$$8) {
  var matchValue$$1 = array$$10.length | 0;

  if (matchValue$$1 === 0) {
    return [[], state$$1];
  } else {
    var len$$3 = matchValue$$1 | 0;
    var acc$$1 = state$$1;
    var res$$1 = new cons$$8(len$$3);

    for (var i$$10 = array$$10.length - 1; i$$10 >= 0; i$$10--) {
      var patternInput$$1 = mapping$$3(array$$10[i$$10], acc$$1);
      res$$1[i$$10] = patternInput$$1[0];
      acc$$1 = patternInput$$1[1];
    }

    return [res$$1, acc$$1];
  }
}
function indexed(source$$2) {
  var len$$4 = source$$2.length | 0;
  var target$$3 = new Array(len$$4);

  for (var i$$11 = 0; i$$11 <= len$$4 - 1; i$$11++) {
    target$$3[i$$11] = [i$$11, source$$2[i$$11]];
  }

  return target$$3;
}
function truncate(count$$4, array$$11) {
  var count$$5 = Object(__WEBPACK_IMPORTED_MODULE_4__Util__["n" /* max */])(__WEBPACK_IMPORTED_MODULE_4__Util__["f" /* comparePrimitives */], 0, count$$4) | 0;
  return array$$11.slice(0, 0 + count$$5);
}
function concat(arrays, cons$$9) {
  var arrays$$1 = __WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_array_from___default()(arrays);
  var matchValue$$2 = arrays$$1.length | 0;

  switch (matchValue$$2) {
    case 0:
      {
        return new cons$$9(0);
      }

    case 1:
      {
        return arrays$$1[0];
      }

    default:
      {
        if (ArrayBuffer.isView(arrays$$1[0])) {
          var totalIdx = 0;
          var totalLength = 0;

          for (var idx = 0; idx <= arrays$$1.length - 1; idx++) {
            var arr$$4 = arrays$$1[idx];
            totalLength = totalLength + arr$$4.length;
          }

          var result$$4 = new cons$$9(totalLength);

          for (var idx$$1 = 0; idx$$1 <= arrays$$1.length - 1; idx$$1++) {
            var arr$$5 = arrays$$1[idx$$1];

            for (var j = 0; j <= arr$$5.length - 1; j++) {
              result$$4[totalIdx] = arr$$5[j];
              totalIdx = totalIdx + 1;
            }
          }

          return result$$4;
        } else {
          var _arrays$$1$;

          return (_arrays$$1$ = arrays$$1[0]).concat.apply(_arrays$$1$, __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_toConsumableArray___default()(arrays$$1.slice(1)));
        }
      }
  }
}
function collect(mapping$$4, array$$14, cons$$10) {
  var mapped = map(mapping$$4, array$$14, Array);
  return concat(mapped, cons$$10);
}
function countBy(projection, array$$15, eq) {
  var dict = Object(__WEBPACK_IMPORTED_MODULE_5__Map__["a" /* createMutable */])([], Object(__WEBPACK_IMPORTED_MODULE_4__Util__["g" /* comparerFromEqualityComparer */])(eq));

  for (var idx$$2 = 0; idx$$2 <= array$$15.length - 1; idx$$2++) {
    var value$$2 = array$$15[idx$$2];
    var key = projection(value$$2);
    var matchValue$$3 = Object(__WEBPACK_IMPORTED_MODULE_4__Util__["r" /* tryGetValue */])(dict, key, 0);

    if (matchValue$$3[0]) {
      dict.set(key, matchValue$$3[1] + 1);
    } else {
      dict.set(key, 1);
    }
  }

  var res$$2 = new Array(dict.size);
  var i$$12 = 0;
  Object(__WEBPACK_IMPORTED_MODULE_6__Seq__["g" /* iterate */])(function (group) {
    res$$2[i$$12] = [group[0], group[1]];
    i$$12 = i$$12 + 1;
  }, dict);
  return res$$2;
}
function distinctBy(projection$$1, array$$16, eq$$1) {
  var hashSet = Object(__WEBPACK_IMPORTED_MODULE_7__Set__["a" /* createMutable */])([], Object(__WEBPACK_IMPORTED_MODULE_4__Util__["g" /* comparerFromEqualityComparer */])(eq$$1));
  return filter(function predicate$$2($arg$$3) {
    return Object(__WEBPACK_IMPORTED_MODULE_4__Util__["a" /* addToSet */])(projection$$1($arg$$3), hashSet);
  }, array$$16);
}
function distinct(array$$18, eq$$2) {
  return distinctBy(function (x$$2) {
    return x$$2;
  }, array$$18, eq$$2);
}
function where(predicate$$3, array$$19) {
  return array$$19.filter(predicate$$3);
}
function contains(value$$3, array$$21, eq$$3) {
  var loop = function loop(i$$13) {
    loop: while (true) {
      if (i$$13 >= array$$21.length) {
        return false;
      } else if (eq$$3.Equals(value$$3, array$$21[i$$13])) {
        return true;
      } else {
        var $i$$13$$49 = i$$13;
        i$$13 = $i$$13$$49 + 1;
        continue loop;
      }

      break;
    }
  };

  return loop(0);
}
function except(itemsToExclude, array$$22, eq$$4) {
  if (array$$22.length === 0) {
    return array$$22;
  } else {
    var cached = Object(__WEBPACK_IMPORTED_MODULE_7__Set__["a" /* createMutable */])(itemsToExclude, Object(__WEBPACK_IMPORTED_MODULE_4__Util__["g" /* comparerFromEqualityComparer */])(eq$$4));
    return array$$22.filter(function predicate$$5(arg00$$1) {
      return Object(__WEBPACK_IMPORTED_MODULE_4__Util__["a" /* addToSet */])(arg00$$1, cached);
    });
  }
}
function groupBy(projection$$2, array$$25, cons$$11, eq$$5) {
  var dict$$1 = Object(__WEBPACK_IMPORTED_MODULE_5__Map__["a" /* createMutable */])([], Object(__WEBPACK_IMPORTED_MODULE_4__Util__["g" /* comparerFromEqualityComparer */])(eq$$5));

  for (var idx$$3 = 0; idx$$3 <= array$$25.length - 1; idx$$3++) {
    var v = array$$25[idx$$3];
    var key$$1 = projection$$2(v);
    var matchValue$$4 = Object(__WEBPACK_IMPORTED_MODULE_4__Util__["r" /* tryGetValue */])(dict$$1, key$$1, null);

    if (matchValue$$4[0]) {
      matchValue$$4[1].push(v);
    } else {
      var prev$$2 = [v];
      dict$$1.set(key$$1, prev$$2);
    }
  }

  var result$$5 = new Array(dict$$1.size);
  var i$$14 = 0;
  Object(__WEBPACK_IMPORTED_MODULE_6__Seq__["g" /* iterate */])(function (group$$1) {
    result$$5[i$$14] = [group$$1[0], cons$$11.from(group$$1[1])];
    i$$14 = i$$14 + 1;
  }, dict$$1);
  return result$$5;
}
function empty(cons$$12) {
  return new cons$$12(0);
}
function singleton(value$$5, cons$$14) {
  var ar = new cons$$14(1);
  ar[0] = value$$5;
  return ar;
}
function initialize(count$$8, initializer, cons$$15) {
  if (count$$8 < 0) {
    throw new Error("The input must be non-negative" + "\\nParameter name: " + "count");
  }

  var result$$6 = new cons$$15(count$$8);

  for (var i$$15 = 0; i$$15 <= count$$8 - 1; i$$15++) {
    result$$6[i$$15] = initializer(i$$15);
  }

  return result$$6;
}
function pairwise(array$$27) {
  if (array$$27.length < 2) {
    return [];
  } else {
    var count$$9 = array$$27.length - 1 | 0;
    var result$$7 = new Array(count$$9);

    for (var i$$16 = 0; i$$16 <= count$$9 - 1; i$$16++) {
      result$$7[i$$16] = [array$$27[i$$16], array$$27[i$$16 + 1]];
    }

    return result$$7;
  }
}
function replicate(count$$10, initial, cons$$16) {
  if (count$$10 < 0) {
    throw new Error("The input must be non-negative" + "\\nParameter name: " + "count");
  }

  var result$$8 = new cons$$16(count$$10);

  for (var i$$17 = 0; i$$17 <= result$$8.length - 1; i$$17++) {
    result$$8[i$$17] = initial;
  }

  return result$$8;
}
function copy(array$$28, cons$$17) {
  return array$$28.slice();
}
function reverse(array$$30, cons$$18) {
  return array$$30.slice().reverse();
}
function scan(folder, state$$2, array$$34, cons$$19) {
  var res$$3 = new cons$$19(array$$34.length + 1);
  res$$3[0] = state$$2;

  for (var i$$18 = 0; i$$18 <= array$$34.length - 1; i$$18++) {
    res$$3[i$$18 + 1] = folder(res$$3[i$$18], array$$34[i$$18]);
  }

  return res$$3;
}
function scanBack(folder$$1, array$$35, state$$3, cons$$20) {
  var res$$4 = new cons$$20(array$$35.length + 1);
  res$$4[array$$35.length] = state$$3;

  for (var i$$19 = array$$35.length - 1; i$$19 >= 0; i$$19--) {
    res$$4[i$$19] = folder$$1(array$$35[i$$19], res$$4[i$$19 + 1]);
  }

  return res$$4;
}
function skip(count$$11, array$$36, cons$$21) {
  if (count$$11 > array$$36.length) {
    throw new Error("count is greater than array length" + "\\nParameter name: " + "count");
  }

  if (count$$11 === array$$36.length) {
    return new cons$$21(0);
  } else {
    var count$$12 = (count$$11 < 0 ? 0 : count$$11) | 0;
    return array$$36.slice(count$$12);
  }
}
function skipWhile(predicate$$7, array$$38, cons$$23) {
  var count$$14 = 0;

  while (count$$14 < array$$38.length ? predicate$$7(array$$38[count$$14]) : false) {
    count$$14 = count$$14 + 1;
  }

  if (count$$14 === array$$38.length) {
    return new cons$$23(0);
  } else {
    return array$$38.slice(count$$14);
  }
}
function take(count$$16, array$$40, cons$$25) {
  if (count$$16 < 0) {
    throw new Error("The input must be non-negative" + "\\nParameter name: " + "count");
  }

  if (count$$16 > array$$40.length) {
    throw new Error("count is greater than array length" + "\\nParameter name: " + "count");
  }

  if (count$$16 === 0) {
    return new cons$$25(0);
  } else {
    return array$$40.slice(0, 0 + count$$16);
  }
}
function takeWhile(predicate$$8, array$$42, cons$$27) {
  var count$$18 = 0;

  while (count$$18 < array$$42.length ? predicate$$8(array$$42[count$$18]) : false) {
    count$$18 = count$$18 + 1;
  }

  if (count$$18 === 0) {
    return new cons$$27(0);
  } else {
    return array$$42.slice(0, 0 + count$$18);
  }
}
function addRangeInPlace(range, array$$44) {
  var iter = __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_get_iterator___default()(range);
  var cur = iter.next();

  while (!cur.done) {
    array$$44.push(cur.value);
    cur = iter.next();
  }
}
function removeInPlace(item$$3, array$$46) {
  var i$$20 = array$$46.indexOf(item$$3);

  if (i$$20 > -1) {
    array$$46.splice(i$$20, 1);
    return true;
  } else {
    return false;
  }
}
function copyTo(source$$3, sourceIndex, target$$4, targetIndex$$1, count$$20) {
  var diff = targetIndex$$1 - sourceIndex | 0;

  for (var i$$21 = sourceIndex; i$$21 <= sourceIndex + count$$20 - 1; i$$21++) {
    target$$4[i$$21 + diff] = source$$3[i$$21];
  }
}
function partition(f$$6, source$$4, cons$$29) {
  var len$$9 = source$$4.length | 0;
  var res1 = new cons$$29(len$$9);
  var res2 = new cons$$29(len$$9);
  var iTrue = 0;
  var iFalse = 0;

  for (var i$$22 = 0; i$$22 <= len$$9 - 1; i$$22++) {
    if (f$$6(source$$4[i$$22])) {
      res1[iTrue] = source$$4[i$$22];
      iTrue = iTrue + 1;
    } else {
      res2[iFalse] = source$$4[i$$22];
      iFalse = iFalse + 1;
    }
  }

  return [truncate(iTrue, res1), truncate(iFalse, res2)];
}
function find(predicate$$9, array$$51) {
  var matchValue$$5 = array$$51.find(predicate$$9);

  if (matchValue$$5 == null) {
    return indexNotFound();
  } else {
    var res$$5 = Object(__WEBPACK_IMPORTED_MODULE_3__Option__["d" /* value */])(matchValue$$5);
    return res$$5;
  }
}
function tryFind(predicate$$11, array$$53) {
  return array$$53.find(predicate$$11);
}
function findIndex(predicate$$13, array$$55) {
  var index;
  var matchValue$$6 = array$$55.findIndex(predicate$$13);

  if (index = matchValue$$6 | 0, index > -1) {
    var index$$1 = matchValue$$6 | 0;
    return index$$1 | 0;
  } else {
    return indexNotFound() | 0;
  }
}
function tryFindIndex(predicate$$15, array$$57) {
  var index$$2;
  var matchValue$$7 = array$$57.findIndex(predicate$$15);

  if (index$$2 = matchValue$$7 | 0, index$$2 > -1) {
    var index$$3 = matchValue$$7 | 0;
    return index$$3;
  } else {
    return null;
  }
}
function pick(chooser, array$$59) {
  var loop$$1 = function loop$$1(i$$23) {
    loop$$1: while (true) {
      if (i$$23 >= array$$59.length) {
        return indexNotFound();
      } else {
        var matchValue$$8 = chooser(array$$59[i$$23]);

        if (matchValue$$8 != null) {
          var res$$6 = Object(__WEBPACK_IMPORTED_MODULE_3__Option__["d" /* value */])(matchValue$$8);
          return res$$6;
        } else {
          var $i$$23$$84 = i$$23;
          i$$23 = $i$$23$$84 + 1;
          continue loop$$1;
        }
      }

      break;
    }
  };

  return loop$$1(0);
}
function tryPick(chooser$$1, array$$60) {
  var loop$$2 = function loop$$2(i$$24) {
    loop$$2: while (true) {
      if (i$$24 >= array$$60.length) {
        return null;
      } else {
        var matchValue$$9 = chooser$$1(array$$60[i$$24]);

        if (matchValue$$9 == null) {
          var $i$$24$$87 = i$$24;
          i$$24 = $i$$24$$87 + 1;
          continue loop$$2;
        } else {
          var res$$7 = matchValue$$9;
          return res$$7;
        }
      }

      break;
    }
  };

  return loop$$2(0);
}
function findBack(predicate$$17, array$$61) {
  var loop$$3 = function loop$$3(i$$25) {
    loop$$3: while (true) {
      if (i$$25 < 0) {
        return indexNotFound();
      } else if (predicate$$17(array$$61[i$$25])) {
        return array$$61[i$$25];
      } else {
        var $i$$25$$90 = i$$25;
        i$$25 = $i$$25$$90 - 1;
        continue loop$$3;
      }

      break;
    }
  };

  return loop$$3(array$$61.length - 1);
}
function tryFindBack(predicate$$18, array$$62) {
  var loop$$4 = function loop$$4(i$$26) {
    loop$$4: while (true) {
      if (i$$26 < 0) {
        return null;
      } else if (predicate$$18(array$$62[i$$26])) {
        return Object(__WEBPACK_IMPORTED_MODULE_3__Option__["c" /* some */])(array$$62[i$$26]);
      } else {
        var $i$$26$$93 = i$$26;
        i$$26 = $i$$26$$93 - 1;
        continue loop$$4;
      }

      break;
    }
  };

  return loop$$4(array$$62.length - 1);
}
function findIndexBack(predicate$$19, array$$63) {
  var loop$$5 = function loop$$5(i$$27) {
    loop$$5: while (true) {
      if (i$$27 < 0) {
        return indexNotFound() | 0;
      } else if (predicate$$19(array$$63[i$$27])) {
        return i$$27 | 0;
      } else {
        var $i$$27$$96 = i$$27;
        i$$27 = $i$$27$$96 - 1;
        continue loop$$5;
      }

      break;
    }
  };

  return loop$$5(array$$63.length - 1) | 0;
}
function tryFindIndexBack(predicate$$20, array$$64) {
  var loop$$6 = function loop$$6(i$$28) {
    loop$$6: while (true) {
      if (i$$28 < 0) {
        return null;
      } else if (predicate$$20(array$$64[i$$28])) {
        return i$$28;
      } else {
        var $i$$28$$99 = i$$28;
        i$$28 = $i$$28$$99 - 1;
        continue loop$$6;
      }

      break;
    }
  };

  return loop$$6(array$$64.length - 1);
}
function choose(f$$7, source$$5, cons$$30) {
  var res$$8 = new cons$$30(0);
  var j$$1 = 0;

  for (var i$$29 = 0; i$$29 <= source$$5.length - 1; i$$29++) {
    var matchValue$$10 = f$$7(source$$5[i$$29]);

    if (matchValue$$10 == null) {} else {
      var y = Object(__WEBPACK_IMPORTED_MODULE_3__Option__["d" /* value */])(matchValue$$10);
      res$$8[j$$1] = y;
      j$$1 = j$$1 + 1;
    }
  }

  return res$$8;
}
function foldIndexed(folder$$2, state$$4, array$$65) {
  return array$$65.reduce(function folder$$3(acc$$2, x$$3, i$$30) {
    return folder$$2(i$$30, acc$$2, x$$3);
  }, state$$4);
}
function fold(folder$$4, state$$6, array$$67) {
  return array$$67.reduce(folder$$4, state$$6);
}
function iterate(action, array$$69) {
  for (var i$$31 = 0; i$$31 <= array$$69.length - 1; i$$31++) {
    action(array$$69[i$$31]);
  }
}
function iterateIndexed(action$$1, array$$70) {
  for (var i$$32 = 0; i$$32 <= array$$70.length - 1; i$$32++) {
    action$$1(i$$32, array$$70[i$$32]);
  }
}
function iterate2(action$$2, array1$$2, array2$$2) {
  if (array1$$2.length !== array2$$2.length) {
    throw new Error("Arrays had different lengths");
  }

  for (var i$$33 = 0; i$$33 <= array1$$2.length - 1; i$$33++) {
    action$$2(array1$$2[i$$33], array2$$2[i$$33]);
  }
}
function iterateIndexed2(action$$3, array1$$3, array2$$3) {
  if (array1$$3.length !== array2$$3.length) {
    throw new Error("Arrays had different lengths");
  }

  for (var i$$34 = 0; i$$34 <= array1$$3.length - 1; i$$34++) {
    action$$3(i$$34, array1$$3[i$$34], array2$$3[i$$34]);
  }
}
function isEmpty(array$$71) {
  return array$$71.length === 0;
}
function forAll(predicate$$21, array$$72) {
  return array$$72.every(predicate$$21);
}
function permute(f$$8, array$$74) {
  var size = array$$74.length | 0;
  var res$$9 = new array$$74.constructor(array$$74.length);
  var checkFlags = new Array(size);
  iterateIndexed(function (i$$35, x$$5) {
    var j$$2 = f$$8(i$$35) | 0;

    if (j$$2 < 0 ? true : j$$2 >= size) {
      throw new Error("Not a valid permutation");
    }

    res$$9[j$$2] = x$$5;
    checkFlags[j$$2] = 1;
  }, array$$74);
  var isValid = forAll(function (y$$1) {
    return 1 === y$$1;
  }, checkFlags);

  if (!isValid) {
    throw new Error("Not a valid permutation");
  }

  return res$$9;
}
function setSlice(target$$5, lower, upper, source$$6) {
  var lower$$1 = Object(__WEBPACK_IMPORTED_MODULE_3__Option__["b" /* defaultArg */])(lower, 0) | 0;
  var upper$$1 = Object(__WEBPACK_IMPORTED_MODULE_3__Option__["b" /* defaultArg */])(upper, 0) | 0;
  var length = (upper$$1 > 0 ? upper$$1 : target$$5.length - 1) - lower$$1 | 0;

  if (ArrayBuffer.isView(target$$5) ? source$$6.length <= length : false) {
    return target$$5.set(source$$6, lower$$1);
  } else {
    for (var i$$36 = 0; i$$36 <= length; i$$36++) {
      target$$5[i$$36 + lower$$1] = source$$6[i$$36];
    }
  }
}
function sortInPlaceBy(projection$$3, xs, comparer) {
  xs.sort(function (x$$7, y$$2) {
    return comparer.Compare(projection$$3(x$$7), projection$$3(y$$2));
  });
}
function sortInPlace(xs$$1, comparer$$1) {
  xs$$1.sort(function (x$$8, y$$3) {
    return comparer$$1.Compare(x$$8, y$$3);
  });
}

function copyArray(array$$75) {
  var result$$9 = new array$$75.constructor(array$$75.length);

  for (var i$$37 = 0; i$$37 <= array$$75.length - 1; i$$37++) {
    result$$9[i$$37] = array$$75[i$$37];
  }

  return result$$9;
}

function sort(xs$$2, comparer$$2) {
  var xs$$3 = copyArray(xs$$2);
  xs$$3.sort(function comparer$$3(x$$9, y$$4) {
    return comparer$$2.Compare(x$$9, y$$4);
  });
  return xs$$3;
}
function sortBy(projection$$4, xs$$4, comparer$$4) {
  var xs$$5 = copyArray(xs$$4);
  xs$$5.sort(function comparer$$5(x$$10, y$$5) {
    return comparer$$4.Compare(projection$$4(x$$10), projection$$4(y$$5));
  });
  return xs$$5;
}
function sortDescending(xs$$6, comparer$$6) {
  var xs$$7 = copyArray(xs$$6);
  xs$$7.sort(function comparer$$7(x$$11, y$$6) {
    return comparer$$6.Compare(x$$11, y$$6) * -1;
  });
  return xs$$7;
}
function sortByDescending(projection$$5, xs$$8, comparer$$8) {
  var xs$$9 = copyArray(xs$$8);
  xs$$9.sort(function comparer$$9(x$$12, y$$7) {
    return comparer$$8.Compare(projection$$5(x$$12), projection$$5(y$$7)) * -1;
  });
  return xs$$9;
}
function sortWith(comparer$$10, xs$$10) {
  var xs$$11 = copyArray(xs$$10);
  xs$$11.sort(comparer$$10);
  return xs$$11;
}
function unfold(generator, state$$8) {
  var res$$10 = [];

  var loop$$7 = function loop$$7(state$$9) {
    loop$$7: while (true) {
      var matchValue$$11 = generator(state$$9);

      if (matchValue$$11 != null) {
        var x$$13 = matchValue$$11[0];
        var s$0027$$2 = matchValue$$11[1];
        res$$10.push(x$$13);
        state$$9 = s$0027$$2;
        continue loop$$7;
      }

      break;
    }
  };

  loop$$7(state$$8);
  return res$$10;
}
function unzip(array$$77) {
  var len$$11 = array$$77.length | 0;
  var res1$$1 = new Array(len$$11);
  var res2$$1 = new Array(len$$11);
  iterateIndexed(function (i$$38, tupledArg) {
    res1$$1[i$$38] = tupledArg[0];
    res2$$1[i$$38] = tupledArg[1];
  }, array$$77);
  return [res1$$1, res2$$1];
}
function unzip3(array$$78) {
  var len$$14 = array$$78.length | 0;
  var res1$$2 = new Array(len$$14);
  var res2$$2 = new Array(len$$14);
  var res3 = new Array(len$$14);
  iterateIndexed(function (i$$39, tupledArg$$1) {
    res1$$2[i$$39] = tupledArg$$1[0];
    res2$$2[i$$39] = tupledArg$$1[1];
    res3[i$$39] = tupledArg$$1[2];
  }, array$$78);
  return [res1$$2, res2$$2, res3];
}
function zip(array1$$4, array2$$4) {
  if (array1$$4.length !== array2$$4.length) {
    throw new Error("Arrays had different lengths");
  }

  var result$$10 = new Array(array1$$4.length);

  for (var i$$40 = 0; i$$40 <= array1$$4.length - 1; i$$40++) {
    result$$10[i$$40] = [array1$$4[i$$40], array2$$4[i$$40]];
  }

  return result$$10;
}
function zip3(array1$$5, array2$$5, array3) {
  if (array1$$5.length !== array2$$5.length ? true : array2$$5.length !== array3.length) {
    throw new Error("Arrays had different lengths");
  }

  var result$$11 = new Array(array1$$5.length);

  for (var i$$41 = 0; i$$41 <= array1$$5.length - 1; i$$41++) {
    result$$11[i$$41] = [array1$$5[i$$41], array2$$5[i$$41], array3[i$$41]];
  }

  return result$$11;
}
function chunkBySize(chunkSize, array$$79) {
  if (chunkSize < 1) {
    throw new Error("The input must be positive." + "\\nParameter name: " + "size");
  }

  if (array$$79.length === 0) {
    return [[]];
  } else {
    var result$$12 = [];

    for (var x$$14 = 0; x$$14 <= ~~Math.ceil(array$$79.length / chunkSize) - 1; x$$14++) {
      var start$$7 = x$$14 * chunkSize | 0;
      var slice = array$$79.slice(start$$7, start$$7 + chunkSize);
      result$$12.push(slice);
    }

    return result$$12;
  }
}
function splitAt(index$$4, array$$82) {
  if (index$$4 < 0) {
    throw new Error("The input must be non-negative" + "\\nParameter name: " + "index");
  }

  if (index$$4 > array$$82.length) {
    throw new Error("The input sequence has an insufficient number of elements." + "\\nParameter name: " + "index");
  }

  return [array$$82.slice(0, 0 + index$$4), array$$82.slice(index$$4)];
}
function compareWith(comparer$$12, array1$$6, array2$$6) {
  if (array1$$6 == null) {
    if (array2$$6 == null) {
      return 0;
    } else {
      return -1 | 0;
    }
  } else if (array2$$6 == null) {
    return 1;
  } else {
    var i$$42 = 0;
    var result$$13 = 0;
    var length1 = array1$$6.length | 0;
    var length2 = array2$$6.length | 0;

    if (length1 > length2) {
      return 1;
    } else if (length1 < length2) {
      return -1 | 0;
    } else {
      while (i$$42 < length1 ? result$$13 === 0 : false) {
        result$$13 = comparer$$12(array1$$6[i$$42], array2$$6[i$$42]);
        i$$42 = i$$42 + 1;
      }

      return result$$13 | 0;
    }
  }
}
function equalsWith(comparer$$13, array1$$7, array2$$7) {
  return compareWith(__WEBPACK_IMPORTED_MODULE_4__Util__["c" /* compare */], array1$$7, array2$$7) === 0;
}
function exactlyOne(array$$85) {
  if (array$$85.length === 1) {
    return array$$85[0];
  } else if (array$$85.length === 0) {
    throw new Error("The input sequence was empty" + "\\nParameter name: " + "array");
  } else {
    throw new Error("Input array too long" + "\\nParameter name: " + "array");
  }
}
function head(array$$86) {
  if (array$$86.length === 0) {
    throw new Error("The input array was empty" + "\\nParameter name: " + "array");
  } else {
    return array$$86[0];
  }
}
function tryHead(array$$87) {
  if (array$$87.length === 0) {
    return null;
  } else {
    return Object(__WEBPACK_IMPORTED_MODULE_3__Option__["c" /* some */])(array$$87[0]);
  }
}
function tail(array$$88) {
  if (array$$88.length === 0) {
    throw new Error("Not enough elements" + "\\nParameter name: " + "array");
  }

  return array$$88.slice(1);
}
function item(index$$5, array$$90) {
  return array$$90[index$$5];
}
function tryItem(index$$6, array$$91) {
  if (index$$6 < 0 ? true : index$$6 >= array$$91.length) {
    return null;
  } else {
    return Object(__WEBPACK_IMPORTED_MODULE_3__Option__["c" /* some */])(array$$91[index$$6]);
  }
}
function foldBackIndexed(folder$$6, array$$92, state$$10) {
  return array$$92.reduceRight(function folder$$7(acc$$4, x$$15, i$$43) {
    return folder$$6(i$$43, x$$15, acc$$4);
  }, state$$10);
}
function foldBack(folder$$8, array$$94, state$$12) {
  return array$$94.reduceRight(function folder$$9(acc$$5, x$$16) {
    return folder$$8(x$$16, acc$$5);
  }, state$$12);
}
function foldIndexed2(folder$$10, state$$14, array1$$8, array2$$8) {
  var acc$$6 = state$$14;

  if (array1$$8.length !== array2$$8.length) {
    throw new Error("Arrays have different lengths");
  }

  for (var i$$44 = 0; i$$44 <= array1$$8.length - 1; i$$44++) {
    acc$$6 = folder$$10(i$$44, acc$$6, array1$$8[i$$44], array2$$8[i$$44]);
  }

  return acc$$6;
}
function fold2(folder$$11, state$$15, array1$$9, array2$$9) {
  return foldIndexed2(function (_arg1, acc$$7, x$$17, y$$8) {
    return folder$$11(acc$$7, x$$17, y$$8);
  }, state$$15, array1$$9, array2$$9);
}
function foldBackIndexed2(folder$$12, array1$$10, array2$$10, state$$16) {
  var acc$$8 = state$$16;

  if (array1$$10.length !== array2$$10.length) {
    throw new Error("Arrays had different lengths");
  }

  var size$$1 = array1$$10.length | 0;

  for (var i$$45 = 1; i$$45 <= size$$1; i$$45++) {
    acc$$8 = folder$$12(i$$45 - 1, array1$$10[size$$1 - i$$45], array2$$10[size$$1 - i$$45], acc$$8);
  }

  return acc$$8;
}
function foldBack2(f$$9, array1$$11, array2$$11, state$$17) {
  return foldBackIndexed2(function (_arg1$$1, x$$18, y$$9, acc$$9) {
    return f$$9(x$$18, y$$9, acc$$9);
  }, array1$$11, array2$$11, state$$17);
}
function reduce(reduction, array$$96) {
  if (array$$96.length === 0) {
    throw new Error("The input array was empty");
  }

  return array$$96.reduce(reduction);
}
function reduceBack(reduction$$2, array$$98) {
  if (array$$98.length === 0) {
    throw new Error("The input array was empty");
  }

  return array$$98.reduceRight(reduction$$2);
}
function forAll2(predicate$$23, array1$$12, array2$$12) {
  return fold2(function (acc$$10, x$$19, y$$10) {
    return acc$$10 ? predicate$$23(x$$19, y$$10) : false;
  }, true, array1$$12, array2$$12);
}
function existsOffset($arg$$171, $arg$$172, $arg$$173) {
  existsOffset: while (true) {
    var predicate$$24 = $arg$$171,
        array$$100 = $arg$$172,
        index$$7 = $arg$$173;

    if (index$$7 === array$$100.length) {
      return false;
    } else if (predicate$$24(array$$100[index$$7])) {
      return true;
    } else {
      $arg$$171 = predicate$$24;
      $arg$$172 = array$$100;
      $arg$$173 = index$$7 + 1;
      continue existsOffset;
    }

    break;
  }
}
function exists(predicate$$25, array$$101) {
  return existsOffset(predicate$$25, array$$101, 0);
}
function existsOffset2($arg$$176, $arg$$177, $arg$$178, $arg$$179) {
  existsOffset2: while (true) {
    var predicate$$26 = $arg$$176,
        array1$$13 = $arg$$177,
        array2$$13 = $arg$$178,
        index$$8 = $arg$$179;

    if (index$$8 === array1$$13.length) {
      return false;
    } else if (predicate$$26(array1$$13[index$$8], array2$$13[index$$8])) {
      return true;
    } else {
      $arg$$176 = predicate$$26;
      $arg$$177 = array1$$13;
      $arg$$178 = array2$$13;
      $arg$$179 = index$$8 + 1;
      continue existsOffset2;
    }

    break;
  }
}
function exists2(predicate$$27, array1$$14, array2$$14) {
  if (array1$$14.length !== array2$$14.length) {
    throw new Error("Arrays had different lengths");
  }

  return existsOffset2(predicate$$27, array1$$14, array2$$14, 0);
}
function sum(array$$102, adder) {
  var acc$$11 = adder.GetZero();

  for (var i$$46 = 0; i$$46 <= array$$102.length - 1; i$$46++) {
    acc$$11 = adder.Add(acc$$11, array$$102[i$$46]);
  }

  return acc$$11;
}
function sumBy(projection$$6, array$$103, adder$$1) {
  var acc$$12 = adder$$1.GetZero();

  for (var i$$47 = 0; i$$47 <= array$$103.length - 1; i$$47++) {
    acc$$12 = adder$$1.Add(acc$$12, projection$$6(array$$103[i$$47]));
  }

  return acc$$12;
}
function maxBy(projection$$7, xs$$12, comparer$$14) {
  return reduce(function (x$$20, y$$11) {
    return comparer$$14.Compare(projection$$7(y$$11), projection$$7(x$$20)) > 0 ? y$$11 : x$$20;
  }, xs$$12);
}
function max(xs$$13, comparer$$15) {
  return reduce(function (x$$21, y$$12) {
    return comparer$$15.Compare(y$$12, x$$21) > 0 ? y$$12 : x$$21;
  }, xs$$13);
}
function minBy(projection$$8, xs$$14, comparer$$16) {
  return reduce(function (x$$22, y$$13) {
    return comparer$$16.Compare(projection$$8(y$$13), projection$$8(x$$22)) > 0 ? x$$22 : y$$13;
  }, xs$$14);
}
function min(xs$$15, comparer$$17) {
  return reduce(function (x$$23, y$$14) {
    return comparer$$17.Compare(y$$14, x$$23) > 0 ? x$$23 : y$$14;
  }, xs$$15);
}
function average(array$$104, averager) {
  if (array$$104.length === 0) {
    throw new Error("The input array was empty" + "\\nParameter name: " + "array");
  }

  var total = averager.GetZero();

  for (var i$$48 = 0; i$$48 <= array$$104.length - 1; i$$48++) {
    total = averager.Add(total, array$$104[i$$48]);
  }

  return averager.DivideByInt(total, array$$104.length);
}
function averageBy(projection$$9, array$$105, averager$$1) {
  if (array$$105.length === 0) {
    throw new Error("The input array was empty" + "\\nParameter name: " + "array");
  }

  var total$$1 = averager$$1.GetZero();

  for (var i$$49 = 0; i$$49 <= array$$105.length - 1; i$$49++) {
    total$$1 = averager$$1.Add(total$$1, projection$$9(array$$105[i$$49]));
  }

  return averager$$1.DivideByInt(total$$1, array$$105.length);
}
function ofSeq(source$$8, cons$$31) {
  return cons$$31.from(source$$8);
}
function ofList(source$$9, cons$$32) {
  return cons$$32.from(source$$9);
}
function toList(source$$10) {
  var len$$20 = source$$10.length | 0;
  var target$$7 = new __WEBPACK_IMPORTED_MODULE_8__Types__["b" /* List */]();

  for (var i$$50 = len$$20 - 1; i$$50 >= 0; i$$50--) {
    target$$7 = new __WEBPACK_IMPORTED_MODULE_8__Types__["b" /* List */](source$$10[i$$50], target$$7);
  }

  return target$$7;
}

/***/ }),
/* 80 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export MapTree$00602 */
/* unused harmony export MapTreeModule$$$sizeAux */
/* unused harmony export MapTreeModule$$$size */
/* unused harmony export MapTreeModule$$$empty */
/* unused harmony export MapTreeModule$$$height */
/* unused harmony export MapTreeModule$$$isEmpty */
/* unused harmony export MapTreeModule$$$mk */
/* unused harmony export MapTreeModule$$$rebalance */
/* unused harmony export MapTreeModule$$$add */
/* unused harmony export MapTreeModule$$$find */
/* unused harmony export MapTreeModule$$$tryFind */
/* unused harmony export MapTreeModule$$$partition1 */
/* unused harmony export MapTreeModule$$$partitionAux */
/* unused harmony export MapTreeModule$$$partition */
/* unused harmony export MapTreeModule$$$filter1 */
/* unused harmony export MapTreeModule$$$filterAux */
/* unused harmony export MapTreeModule$$$filter */
/* unused harmony export MapTreeModule$$$spliceOutSuccessor */
/* unused harmony export MapTreeModule$$$remove */
/* unused harmony export MapTreeModule$$$mem */
/* unused harmony export MapTreeModule$$$iter */
/* unused harmony export MapTreeModule$$$tryPick */
/* unused harmony export MapTreeModule$$$exists */
/* unused harmony export MapTreeModule$$$forall */
/* unused harmony export MapTreeModule$$$map */
/* unused harmony export MapTreeModule$$$mapi */
/* unused harmony export MapTreeModule$$$foldBack */
/* unused harmony export MapTreeModule$$$fold */
/* unused harmony export MapTreeModule$$$foldFromTo */
/* unused harmony export MapTreeModule$$$foldSection */
/* unused harmony export MapTreeModule$$$loop */
/* unused harmony export MapTreeModule$$$toList */
/* unused harmony export MapTreeModule$$$ofList */
/* unused harmony export MapTreeModule$$$mkFromEnumerator */
/* unused harmony export MapTreeModule$$$ofArray */
/* unused harmony export MapTreeModule$$$ofSeq */
/* unused harmony export MapTreeModule$$$copyToArray */
/* unused harmony export MapTreeModule$002EMapIterator$00602 */
/* unused harmony export MapTreeModule$$$collapseLHS */
/* unused harmony export MapTreeModule$$$mkIterator */
/* unused harmony export MapTreeModule$$$notStarted */
/* unused harmony export MapTreeModule$$$alreadyFinished */
/* unused harmony export MapTreeModule$$$current */
/* unused harmony export MapTreeModule$$$moveNext */
/* unused harmony export MapTreeModule$002EmkIEnumerator$0027$00602 */
/* unused harmony export MapTreeModule$002EmkIEnumerator$0027$00602$$$$002Ector$$Z26BC498C */
/* unused harmony export MapTreeModule$$$mkIEnumerator */
/* unused harmony export MapTreeModule$$$toSeq */
/* unused harmony export FSharpMap */
/* unused harmony export FSharpMap$$$$002Ector$$58ADD115 */
/* unused harmony export FSharpMap$$get_Comparer */
/* unused harmony export FSharpMap$$get_Tree */
/* unused harmony export FSharpMap$$Add$$5BDDA1 */
/* unused harmony export FSharpMap$$get_IsEmpty */
/* unused harmony export FSharpMap$$get_Item$$2B595 */
/* unused harmony export FSharpMap$$TryGetValue$$5BDDA1 */
/* unused harmony export FSharpMap$$TryPick$$72321DD7 */
/* unused harmony export FSharpMap$$Exists$$Z395DDC35 */
/* unused harmony export FSharpMap$$Filter$$Z395DDC35 */
/* unused harmony export FSharpMap$$ForAll$$Z395DDC35 */
/* unused harmony export FSharpMap$$Fold */
/* unused harmony export FSharpMap$$FoldSection */
/* unused harmony export FSharpMap$$Iterate$$1DCFB91D */
/* unused harmony export FSharpMap$$MapRange$$6DC7247 */
/* unused harmony export FSharpMap$$Map$$Z6F6B671C */
/* unused harmony export FSharpMap$$Partition$$Z395DDC35 */
/* unused harmony export FSharpMap$$get_Count */
/* unused harmony export FSharpMap$$ContainsKey$$2B595 */
/* unused harmony export FSharpMap$$Remove$$2B595 */
/* unused harmony export FSharpMap$$TryFind$$2B595 */
/* unused harmony export FSharpMap$$ToList */
/* unused harmony export isEmpty */
/* unused harmony export add */
/* unused harmony export find */
/* unused harmony export tryFind */
/* unused harmony export remove */
/* unused harmony export containsKey */
/* unused harmony export iterate */
/* unused harmony export tryPick */
/* unused harmony export pick */
/* unused harmony export exists */
/* unused harmony export filter */
/* unused harmony export partition */
/* unused harmony export forAll */
/* unused harmony export mapRange */
/* unused harmony export map */
/* unused harmony export fold */
/* unused harmony export foldBack */
/* unused harmony export toSeq */
/* unused harmony export findKey */
/* unused harmony export tryFindKey */
/* unused harmony export ofList */
/* unused harmony export ofSeq */
/* unused harmony export ofArray */
/* unused harmony export toList */
/* unused harmony export toArray */
/* unused harmony export empty */
/* harmony export (immutable) */ __webpack_exports__["a"] = createMutable;
/* unused harmony export groupBy */
/* unused harmony export countBy */
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_array_from__ = __webpack_require__(13);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_array_from___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_array_from__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_defineProperty__ = __webpack_require__(56);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_defineProperty___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_defineProperty__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_symbol_iterator__ = __webpack_require__(20);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_symbol_iterator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_symbol_iterator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_babel_runtime_helpers_toConsumableArray__ = __webpack_require__(28);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_babel_runtime_helpers_toConsumableArray___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_babel_runtime_helpers_toConsumableArray__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__Types__ = __webpack_require__(16);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__Option__ = __webpack_require__(22);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__Seq__ = __webpack_require__(32);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__Util__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__String__ = __webpack_require__(45);









var MapTree$00602 = Object(__WEBPACK_IMPORTED_MODULE_4__Types__["e" /* declare */])(function MapTree$00602(tag, name) {
  for (var _len = arguments.length, fields = Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++) {
    fields[_key - 2] = arguments[_key];
  }

  __WEBPACK_IMPORTED_MODULE_4__Types__["d" /* Union */].call.apply(__WEBPACK_IMPORTED_MODULE_4__Types__["d" /* Union */], [this, tag, name].concat(fields));
}, __WEBPACK_IMPORTED_MODULE_4__Types__["d" /* Union */]);
function MapTreeModule$$$sizeAux(acc, m) {
  MapTreeModule$$$sizeAux: while (true) {
    switch (m.tag) {
      case 1:
        {
          return acc + 1 | 0;
        }

      case 2:
        {
          var r = m.fields[3];
          var l = m.fields[2];
          var $acc$$3 = acc;
          acc = MapTreeModule$$$sizeAux($acc$$3 + 1, l);
          m = r;
          continue MapTreeModule$$$sizeAux;
        }

      default:
        {
          return acc | 0;
        }
    }

    break;
  }
}
function MapTreeModule$$$size(x) {
  return MapTreeModule$$$sizeAux(0, x);
}
function MapTreeModule$$$empty() {
  return new MapTree$00602(0, "MapEmpty");
}
function MapTreeModule$$$height(_arg1) {
  switch (_arg1.tag) {
    case 1:
      {
        return 1;
      }

    case 2:
      {
        var h = _arg1.fields[4] | 0;
        return h | 0;
      }

    default:
      {
        return 0;
      }
  }
}
function MapTreeModule$$$isEmpty(m$$1) {
  if (m$$1.tag === 0) {
    return true;
  } else {
    return false;
  }
}
function MapTreeModule$$$mk(l$$1, k, v, r$$1) {
  var matchValue = [l$$1, r$$1];
  var $target$$4;

  if (matchValue[0].tag === 0) {
    if (matchValue[1].tag === 0) {
      $target$$4 = 0;
    } else {
      $target$$4 = 1;
    }
  } else {
    $target$$4 = 1;
  }

  switch ($target$$4) {
    case 0:
      {
        return new MapTree$00602(1, "MapOne", k, v);
      }

    case 1:
      {
        var hl = MapTreeModule$$$height(l$$1) | 0;
        var hr = MapTreeModule$$$height(r$$1) | 0;
        var m$$2 = (hl < hr ? hr : hl) | 0;
        return new MapTree$00602(2, "MapNode", k, v, l$$1, r$$1, m$$2 + 1);
      }
  }
}
function MapTreeModule$$$rebalance(t1, k$$1, v$$1, t2) {
  var t1h = MapTreeModule$$$height(t1) | 0;
  var t2h = MapTreeModule$$$height(t2) | 0;

  if (t2h > t1h + 2) {
    if (t2.tag === 2) {
      var t2v = t2.fields[1];
      var t2r = t2.fields[3];
      var t2l = t2.fields[2];
      var t2k = t2.fields[0];

      if (MapTreeModule$$$height(t2l) > t1h + 1) {
        if (t2l.tag === 2) {
          var t2lv = t2l.fields[1];
          var t2lr = t2l.fields[3];
          var t2ll = t2l.fields[2];
          var t2lk = t2l.fields[0];
          return MapTreeModule$$$mk(MapTreeModule$$$mk(t1, k$$1, v$$1, t2ll), t2lk, t2lv, MapTreeModule$$$mk(t2lr, t2k, t2v, t2r));
        } else {
          throw new Error("rebalance");
        }
      } else {
        return MapTreeModule$$$mk(MapTreeModule$$$mk(t1, k$$1, v$$1, t2l), t2k, t2v, t2r);
      }
    } else {
      throw new Error("rebalance");
    }
  } else if (t1h > t2h + 2) {
    if (t1.tag === 2) {
      var t1v = t1.fields[1];
      var t1r = t1.fields[3];
      var t1l = t1.fields[2];
      var t1k = t1.fields[0];

      if (MapTreeModule$$$height(t1r) > t2h + 1) {
        if (t1r.tag === 2) {
          var t1rv = t1r.fields[1];
          var t1rr = t1r.fields[3];
          var t1rl = t1r.fields[2];
          var t1rk = t1r.fields[0];
          return MapTreeModule$$$mk(MapTreeModule$$$mk(t1l, t1k, t1v, t1rl), t1rk, t1rv, MapTreeModule$$$mk(t1rr, k$$1, v$$1, t2));
        } else {
          throw new Error("re  balance");
        }
      } else {
        return MapTreeModule$$$mk(t1l, t1k, t1v, MapTreeModule$$$mk(t1r, k$$1, v$$1, t2));
      }
    } else {
      throw new Error("rebalance");
    }
  } else {
    return MapTreeModule$$$mk(t1, k$$1, v$$1, t2);
  }
}
function MapTreeModule$$$add(comparer, k$$2, v$$2, m$$3) {
  switch (m$$3.tag) {
    case 1:
      {
        var k2 = m$$3.fields[0];
        var c = comparer.Compare(k$$2, k2) | 0;

        if (c < 0) {
          return new MapTree$00602(2, "MapNode", k$$2, v$$2, new MapTree$00602(0, "MapEmpty"), m$$3, 2);
        } else if (c === 0) {
          return new MapTree$00602(1, "MapOne", k$$2, v$$2);
        } else {
          return new MapTree$00602(2, "MapNode", k$$2, v$$2, m$$3, new MapTree$00602(0, "MapEmpty"), 2);
        }
      }

    case 2:
      {
        var v2 = m$$3.fields[1];
        var r$$2 = m$$3.fields[3];
        var l$$2 = m$$3.fields[2];
        var k2$$1 = m$$3.fields[0];
        var h$$1 = m$$3.fields[4] | 0;
        var c$$1 = comparer.Compare(k$$2, k2$$1) | 0;

        if (c$$1 < 0) {
          return MapTreeModule$$$rebalance(MapTreeModule$$$add(comparer, k$$2, v$$2, l$$2), k2$$1, v2, r$$2);
        } else if (c$$1 === 0) {
          return new MapTree$00602(2, "MapNode", k$$2, v$$2, l$$2, r$$2, h$$1);
        } else {
          return MapTreeModule$$$rebalance(l$$2, k2$$1, v2, MapTreeModule$$$add(comparer, k$$2, v$$2, r$$2));
        }
      }

    default:
      {
        return new MapTree$00602(1, "MapOne", k$$2, v$$2);
      }
  }
}
function MapTreeModule$$$find(comparer$$1, k$$3, m$$4) {
  MapTreeModule$$$find: while (true) {
    switch (m$$4.tag) {
      case 1:
        {
          var v2$$1 = m$$4.fields[1];
          var k2$$2 = m$$4.fields[0];
          var c$$2 = comparer$$1.Compare(k$$3, k2$$2) | 0;

          if (c$$2 === 0) {
            return v2$$1;
          } else {
            throw new Error("key not found");
          }
        }

      case 2:
        {
          var v2$$2 = m$$4.fields[1];
          var r$$3 = m$$4.fields[3];
          var l$$3 = m$$4.fields[2];
          var k2$$3 = m$$4.fields[0];
          var c$$3 = comparer$$1.Compare(k$$3, k2$$3) | 0;

          if (c$$3 < 0) {
            var $comparer$$1$$5 = comparer$$1;
            var $k$$3$$6 = k$$3;
            comparer$$1 = $comparer$$1$$5;
            k$$3 = $k$$3$$6;
            m$$4 = l$$3;
            continue MapTreeModule$$$find;
          } else if (c$$3 === 0) {
            return v2$$2;
          } else {
            var $comparer$$1$$7 = comparer$$1;
            var $k$$3$$8 = k$$3;
            comparer$$1 = $comparer$$1$$7;
            k$$3 = $k$$3$$8;
            m$$4 = r$$3;
            continue MapTreeModule$$$find;
          }
        }

      default:
        {
          throw new Error("key not found");
        }
    }

    break;
  }
}
function MapTreeModule$$$tryFind(comparer$$2, k$$4, m$$5) {
  MapTreeModule$$$tryFind: while (true) {
    switch (m$$5.tag) {
      case 1:
        {
          var v2$$3 = m$$5.fields[1];
          var k2$$4 = m$$5.fields[0];
          var c$$4 = comparer$$2.Compare(k$$4, k2$$4) | 0;

          if (c$$4 === 0) {
            return Object(__WEBPACK_IMPORTED_MODULE_5__Option__["c" /* some */])(v2$$3);
          } else {
            return null;
          }
        }

      case 2:
        {
          var v2$$4 = m$$5.fields[1];
          var r$$4 = m$$5.fields[3];
          var l$$4 = m$$5.fields[2];
          var k2$$5 = m$$5.fields[0];
          var c$$5 = comparer$$2.Compare(k$$4, k2$$5) | 0;

          if (c$$5 < 0) {
            var $comparer$$2$$9 = comparer$$2;
            var $k$$4$$10 = k$$4;
            comparer$$2 = $comparer$$2$$9;
            k$$4 = $k$$4$$10;
            m$$5 = l$$4;
            continue MapTreeModule$$$tryFind;
          } else if (c$$5 === 0) {
            return Object(__WEBPACK_IMPORTED_MODULE_5__Option__["c" /* some */])(v2$$4);
          } else {
            var $comparer$$2$$11 = comparer$$2;
            var $k$$4$$12 = k$$4;
            comparer$$2 = $comparer$$2$$11;
            k$$4 = $k$$4$$12;
            m$$5 = r$$4;
            continue MapTreeModule$$$tryFind;
          }
        }

      default:
        {
          return null;
        }
    }

    break;
  }
}
function MapTreeModule$$$partition1(comparer$$3, f, k$$5, v$$3, acc1, acc2) {
  if (f(k$$5, v$$3)) {
    return [MapTreeModule$$$add(comparer$$3, k$$5, v$$3, acc1), acc2];
  } else {
    return [acc1, MapTreeModule$$$add(comparer$$3, k$$5, v$$3, acc2)];
  }
}
function MapTreeModule$$$partitionAux($arg$$19, $arg$$20, $arg$$21, $arg$$22, $arg$$23) {
  MapTreeModule$$$partitionAux: while (true) {
    var comparer$$4 = $arg$$19,
        f$$1 = $arg$$20,
        s = $arg$$21,
        acc_0 = $arg$$22,
        acc_1 = $arg$$23;
    var acc$$1 = [acc_0, acc_1];

    switch (s.tag) {
      case 1:
        {
          var v$$4 = s.fields[1];
          var k$$6 = s.fields[0];
          return MapTreeModule$$$partition1(comparer$$4, f$$1, k$$6, v$$4, acc$$1[0], acc$$1[1]);
        }

      case 2:
        {
          var v$$5 = s.fields[1];
          var r$$5 = s.fields[3];
          var l$$5 = s.fields[2];
          var k$$7 = s.fields[0];
          var acc$$2 = MapTreeModule$$$partitionAux(comparer$$4, f$$1, r$$5, acc$$1[0], acc$$1[1]);
          var acc$$3 = MapTreeModule$$$partition1(comparer$$4, f$$1, k$$7, v$$5, acc$$2[0], acc$$2[1]);
          $arg$$19 = comparer$$4;
          $arg$$20 = f$$1;
          $arg$$21 = l$$5;
          $arg$$22 = acc$$3[0];
          $arg$$23 = acc$$3[1];
          continue MapTreeModule$$$partitionAux;
        }

      default:
        {
          return acc$$1;
        }
    }

    break;
  }
}
function MapTreeModule$$$partition(comparer$$5, f$$2, s$$1) {
  return MapTreeModule$$$partitionAux(comparer$$5, f$$2, s$$1, MapTreeModule$$$empty(), MapTreeModule$$$empty());
}
function MapTreeModule$$$filter1(comparer$$6, f$$3, k$$8, v$$6, acc$$4) {
  if (f$$3(k$$8, v$$6)) {
    return MapTreeModule$$$add(comparer$$6, k$$8, v$$6, acc$$4);
  } else {
    return acc$$4;
  }
}
function MapTreeModule$$$filterAux($arg$$32, $arg$$33, $arg$$34, $arg$$35) {
  MapTreeModule$$$filterAux: while (true) {
    var comparer$$7 = $arg$$32,
        f$$4 = $arg$$33,
        s$$2 = $arg$$34,
        acc$$5 = $arg$$35;

    switch (s$$2.tag) {
      case 1:
        {
          var v$$7 = s$$2.fields[1];
          var k$$9 = s$$2.fields[0];
          return MapTreeModule$$$filter1(comparer$$7, f$$4, k$$9, v$$7, acc$$5);
        }

      case 2:
        {
          var v$$8 = s$$2.fields[1];
          var r$$6 = s$$2.fields[3];
          var l$$6 = s$$2.fields[2];
          var k$$10 = s$$2.fields[0];
          var acc$$6 = MapTreeModule$$$filterAux(comparer$$7, f$$4, l$$6, acc$$5);
          var acc$$7 = MapTreeModule$$$filter1(comparer$$7, f$$4, k$$10, v$$8, acc$$6);
          $arg$$32 = comparer$$7;
          $arg$$33 = f$$4;
          $arg$$34 = r$$6;
          $arg$$35 = acc$$7;
          continue MapTreeModule$$$filterAux;
        }

      default:
        {
          return acc$$5;
        }
    }

    break;
  }
}
function MapTreeModule$$$filter(comparer$$8, f$$5, s$$3) {
  return MapTreeModule$$$filterAux(comparer$$8, f$$5, s$$3, MapTreeModule$$$empty());
}
function MapTreeModule$$$spliceOutSuccessor(m$$6) {
  switch (m$$6.tag) {
    case 1:
      {
        var v2$$5 = m$$6.fields[1];
        var k2$$6 = m$$6.fields[0];
        return [k2$$6, v2$$5, new MapTree$00602(0, "MapEmpty")];
      }

    case 2:
      {
        var v2$$6 = m$$6.fields[1];
        var r$$7 = m$$6.fields[3];
        var l$$7 = m$$6.fields[2];
        var k2$$7 = m$$6.fields[0];

        if (l$$7.tag === 0) {
          return [k2$$7, v2$$6, r$$7];
        } else {
          var patternInput = MapTreeModule$$$spliceOutSuccessor(l$$7);
          return [patternInput[0], patternInput[1], MapTreeModule$$$mk(patternInput[2], k2$$7, v2$$6, r$$7)];
        }
      }

    default:
      {
        throw new Error("internal error: Map.spliceOutSuccessor");
      }
  }
}
function MapTreeModule$$$remove(comparer$$9, k$$11, m$$7) {
  switch (m$$7.tag) {
    case 1:
      {
        var k2$$8 = m$$7.fields[0];
        var c$$6 = comparer$$9.Compare(k$$11, k2$$8) | 0;

        if (c$$6 === 0) {
          return new MapTree$00602(0, "MapEmpty");
        } else {
          return m$$7;
        }
      }

    case 2:
      {
        var v2$$7 = m$$7.fields[1];
        var r$$8 = m$$7.fields[3];
        var l$$8 = m$$7.fields[2];
        var k2$$9 = m$$7.fields[0];
        var c$$7 = comparer$$9.Compare(k$$11, k2$$9) | 0;

        if (c$$7 < 0) {
          return MapTreeModule$$$rebalance(MapTreeModule$$$remove(comparer$$9, k$$11, l$$8), k2$$9, v2$$7, r$$8);
        } else if (c$$7 === 0) {
          var matchValue$$1 = [l$$8, r$$8];

          if (matchValue$$1[0].tag === 0) {
            return r$$8;
          } else if (matchValue$$1[1].tag === 0) {
            return l$$8;
          } else {
            var patternInput$$1 = MapTreeModule$$$spliceOutSuccessor(r$$8);
            return MapTreeModule$$$mk(l$$8, patternInput$$1[0], patternInput$$1[1], patternInput$$1[2]);
          }
        } else {
          return MapTreeModule$$$rebalance(l$$8, k2$$9, v2$$7, MapTreeModule$$$remove(comparer$$9, k$$11, r$$8));
        }
      }

    default:
      {
        return MapTreeModule$$$empty();
      }
  }
}
function MapTreeModule$$$mem(comparer$$10, k$$12, m$$8) {
  MapTreeModule$$$mem: while (true) {
    switch (m$$8.tag) {
      case 1:
        {
          var k2$$10 = m$$8.fields[0];
          return comparer$$10.Compare(k$$12, k2$$10) === 0;
        }

      case 2:
        {
          var r$$9 = m$$8.fields[3];
          var l$$9 = m$$8.fields[2];
          var k2$$11 = m$$8.fields[0];
          var c$$8 = comparer$$10.Compare(k$$12, k2$$11) | 0;

          if (c$$8 < 0) {
            var $comparer$$10$$39 = comparer$$10;
            var $k$$12$$40 = k$$12;
            comparer$$10 = $comparer$$10$$39;
            k$$12 = $k$$12$$40;
            m$$8 = l$$9;
            continue MapTreeModule$$$mem;
          } else if (c$$8 === 0) {
            return true;
          } else {
            var $comparer$$10$$41 = comparer$$10;
            var $k$$12$$42 = k$$12;
            comparer$$10 = $comparer$$10$$41;
            k$$12 = $k$$12$$42;
            m$$8 = r$$9;
            continue MapTreeModule$$$mem;
          }
        }

      default:
        {
          return false;
        }
    }

    break;
  }
}
function MapTreeModule$$$iter($arg$$43, $arg$$44) {
  MapTreeModule$$$iter: while (true) {
    var f$$6 = $arg$$43,
        m$$9 = $arg$$44;

    switch (m$$9.tag) {
      case 1:
        {
          var v2$$8 = m$$9.fields[1];
          var k2$$12 = m$$9.fields[0];
          f$$6(k2$$12, v2$$8);
          break;
        }

      case 2:
        {
          var v2$$9 = m$$9.fields[1];
          var r$$10 = m$$9.fields[3];
          var l$$10 = m$$9.fields[2];
          var k2$$13 = m$$9.fields[0];
          MapTreeModule$$$iter(f$$6, l$$10);
          f$$6(k2$$13, v2$$9);
          $arg$$43 = f$$6;
          $arg$$44 = r$$10;
          continue MapTreeModule$$$iter;
          break;
        }

      default:
        {}
    }

    break;
  }
}
function MapTreeModule$$$tryPick($arg$$45, $arg$$46) {
  MapTreeModule$$$tryPick: while (true) {
    var f$$7 = $arg$$45,
        m$$10 = $arg$$46;

    switch (m$$10.tag) {
      case 1:
        {
          var v2$$10 = m$$10.fields[1];
          var k2$$14 = m$$10.fields[0];
          return f$$7(k2$$14, v2$$10);
        }

      case 2:
        {
          var v2$$11 = m$$10.fields[1];
          var r$$11 = m$$10.fields[3];
          var l$$11 = m$$10.fields[2];
          var k2$$15 = m$$10.fields[0];
          var matchValue$$2 = MapTreeModule$$$tryPick(f$$7, l$$11);

          if (matchValue$$2 == null) {
            var matchValue$$3 = f$$7(k2$$15, v2$$11);

            if (matchValue$$3 == null) {
              $arg$$45 = f$$7;
              $arg$$46 = r$$11;
              continue MapTreeModule$$$tryPick;
            } else {
              var res$$1 = matchValue$$3;
              return res$$1;
            }
          } else {
            var res = matchValue$$2;
            return res;
          }
        }

      default:
        {
          return null;
        }
    }

    break;
  }
}
function MapTreeModule$$$exists($arg$$47, $arg$$48) {
  MapTreeModule$$$exists: while (true) {
    var f$$8 = $arg$$47,
        m$$11 = $arg$$48;

    switch (m$$11.tag) {
      case 1:
        {
          var v2$$12 = m$$11.fields[1];
          var k2$$16 = m$$11.fields[0];
          return f$$8(k2$$16, v2$$12);
        }

      case 2:
        {
          var v2$$13 = m$$11.fields[1];
          var r$$12 = m$$11.fields[3];
          var l$$12 = m$$11.fields[2];
          var k2$$17 = m$$11.fields[0];

          if (MapTreeModule$$$exists(f$$8, l$$12) ? true : f$$8(k2$$17, v2$$13)) {
            return true;
          } else {
            $arg$$47 = f$$8;
            $arg$$48 = r$$12;
            continue MapTreeModule$$$exists;
          }
        }

      default:
        {
          return false;
        }
    }

    break;
  }
}
function MapTreeModule$$$forall($arg$$49, $arg$$50) {
  MapTreeModule$$$forall: while (true) {
    var f$$9 = $arg$$49,
        m$$12 = $arg$$50;

    switch (m$$12.tag) {
      case 1:
        {
          var v2$$14 = m$$12.fields[1];
          var k2$$18 = m$$12.fields[0];
          return f$$9(k2$$18, v2$$14);
        }

      case 2:
        {
          var v2$$15 = m$$12.fields[1];
          var r$$13 = m$$12.fields[3];
          var l$$13 = m$$12.fields[2];
          var k2$$19 = m$$12.fields[0];

          if (MapTreeModule$$$forall(f$$9, l$$13) ? f$$9(k2$$19, v2$$15) : false) {
            $arg$$49 = f$$9;
            $arg$$50 = r$$13;
            continue MapTreeModule$$$forall;
          } else {
            return false;
          }
        }

      default:
        {
          return true;
        }
    }

    break;
  }
}
function MapTreeModule$$$map(f$$10, m$$13) {
  switch (m$$13.tag) {
    case 1:
      {
        var v$$9 = m$$13.fields[1];
        var k$$13 = m$$13.fields[0];
        return new MapTree$00602(1, "MapOne", k$$13, f$$10(v$$9));
      }

    case 2:
      {
        var v$$10 = m$$13.fields[1];
        var r$$14 = m$$13.fields[3];
        var l$$14 = m$$13.fields[2];
        var k$$14 = m$$13.fields[0];
        var h$$2 = m$$13.fields[4] | 0;
        var l2 = MapTreeModule$$$map(f$$10, l$$14);
        var v2$$16 = f$$10(v$$10);
        var r2 = MapTreeModule$$$map(f$$10, r$$14);
        return new MapTree$00602(2, "MapNode", k$$14, v2$$16, l2, r2, h$$2);
      }

    default:
      {
        return MapTreeModule$$$empty();
      }
  }
}
function MapTreeModule$$$mapi(f$$11, m$$14) {
  switch (m$$14.tag) {
    case 1:
      {
        var v$$11 = m$$14.fields[1];
        var k$$15 = m$$14.fields[0];
        return new MapTree$00602(1, "MapOne", k$$15, f$$11(k$$15, v$$11));
      }

    case 2:
      {
        var v$$12 = m$$14.fields[1];
        var r$$15 = m$$14.fields[3];
        var l$$15 = m$$14.fields[2];
        var k$$16 = m$$14.fields[0];
        var h$$3 = m$$14.fields[4] | 0;
        var l2$$1 = MapTreeModule$$$mapi(f$$11, l$$15);
        var v2$$17 = f$$11(k$$16, v$$12);
        var r2$$1 = MapTreeModule$$$mapi(f$$11, r$$15);
        return new MapTree$00602(2, "MapNode", k$$16, v2$$17, l2$$1, r2$$1, h$$3);
      }

    default:
      {
        return MapTreeModule$$$empty();
      }
  }
}
function MapTreeModule$$$foldBack($arg$$55, $arg$$56, $arg$$57) {
  MapTreeModule$$$foldBack: while (true) {
    var f$$12 = $arg$$55,
        m$$15 = $arg$$56,
        x$$1 = $arg$$57;

    switch (m$$15.tag) {
      case 1:
        {
          var v$$13 = m$$15.fields[1];
          var k$$17 = m$$15.fields[0];
          return f$$12(k$$17, v$$13, x$$1);
        }

      case 2:
        {
          var v$$14 = m$$15.fields[1];
          var r$$16 = m$$15.fields[3];
          var l$$16 = m$$15.fields[2];
          var k$$18 = m$$15.fields[0];
          var x$$2 = MapTreeModule$$$foldBack(f$$12, r$$16, x$$1);
          var x$$3 = f$$12(k$$18, v$$14, x$$2);
          $arg$$55 = f$$12;
          $arg$$56 = l$$16;
          $arg$$57 = x$$3;
          continue MapTreeModule$$$foldBack;
        }

      default:
        {
          return x$$1;
        }
    }

    break;
  }
}
function MapTreeModule$$$fold($arg$$58, $arg$$59, $arg$$60) {
  MapTreeModule$$$fold: while (true) {
    var f$$13 = $arg$$58,
        x$$4 = $arg$$59,
        m$$16 = $arg$$60;

    switch (m$$16.tag) {
      case 1:
        {
          var v$$15 = m$$16.fields[1];
          var k$$19 = m$$16.fields[0];
          return f$$13(x$$4, k$$19, v$$15);
        }

      case 2:
        {
          var v$$16 = m$$16.fields[1];
          var r$$17 = m$$16.fields[3];
          var l$$17 = m$$16.fields[2];
          var k$$20 = m$$16.fields[0];
          var x$$5 = MapTreeModule$$$fold(f$$13, x$$4, l$$17);
          var x$$6 = f$$13(x$$5, k$$20, v$$16);
          $arg$$58 = f$$13;
          $arg$$59 = x$$6;
          $arg$$60 = r$$17;
          continue MapTreeModule$$$fold;
        }

      default:
        {
          return x$$4;
        }
    }

    break;
  }
}
function MapTreeModule$$$foldFromTo(comparer$$11, lo, hi, f$$14, m$$17, x$$7) {
  switch (m$$17.tag) {
    case 1:
      {
        var v$$17 = m$$17.fields[1];
        var k$$21 = m$$17.fields[0];
        var cLoKey = comparer$$11.Compare(lo, k$$21) | 0;
        var cKeyHi = comparer$$11.Compare(k$$21, hi) | 0;
        var x$$8 = (cLoKey <= 0 ? cKeyHi <= 0 : false) ? f$$14(k$$21, v$$17, x$$7) : x$$7;
        return x$$8;
      }

    case 2:
      {
        var v$$18 = m$$17.fields[1];
        var r$$18 = m$$17.fields[3];
        var l$$18 = m$$17.fields[2];
        var k$$22 = m$$17.fields[0];
        var cLoKey$$1 = comparer$$11.Compare(lo, k$$22) | 0;
        var cKeyHi$$1 = comparer$$11.Compare(k$$22, hi) | 0;
        var x$$9 = cLoKey$$1 < 0 ? MapTreeModule$$$foldFromTo(comparer$$11, lo, hi, f$$14, l$$18, x$$7) : x$$7;
        var x$$10 = (cLoKey$$1 <= 0 ? cKeyHi$$1 <= 0 : false) ? f$$14(k$$22, v$$18, x$$9) : x$$9;
        var x$$11 = cKeyHi$$1 < 0 ? MapTreeModule$$$foldFromTo(comparer$$11, lo, hi, f$$14, r$$18, x$$10) : x$$10;
        return x$$11;
      }

    default:
      {
        return x$$7;
      }
  }
}
function MapTreeModule$$$foldSection(comparer$$12, lo$$1, hi$$1, f$$15, m$$18, x$$12) {
  if (comparer$$12.Compare(lo$$1, hi$$1) === 1) {
    return x$$12;
  } else {
    return MapTreeModule$$$foldFromTo(comparer$$12, lo$$1, hi$$1, f$$15, m$$18, x$$12);
  }
}
function MapTreeModule$$$loop(m$$19, acc$$8) {
  MapTreeModule$$$loop: while (true) {
    switch (m$$19.tag) {
      case 1:
        {
          var v$$19 = m$$19.fields[1];
          var k$$23 = m$$19.fields[0];
          return new __WEBPACK_IMPORTED_MODULE_4__Types__["b" /* List */]([k$$23, v$$19], acc$$8);
        }

      case 2:
        {
          var v$$20 = m$$19.fields[1];
          var r$$19 = m$$19.fields[3];
          var l$$19 = m$$19.fields[2];
          var k$$24 = m$$19.fields[0];
          var $acc$$8$$73 = acc$$8;
          m$$19 = l$$19;
          acc$$8 = new __WEBPACK_IMPORTED_MODULE_4__Types__["b" /* List */]([k$$24, v$$20], MapTreeModule$$$loop(r$$19, $acc$$8$$73));
          continue MapTreeModule$$$loop;
        }

      default:
        {
          return acc$$8;
        }
    }

    break;
  }
}
function MapTreeModule$$$toList(m$$20) {
  return MapTreeModule$$$loop(m$$20, new __WEBPACK_IMPORTED_MODULE_4__Types__["b" /* List */]());
}
function MapTreeModule$$$ofList(comparer$$13, l$$20) {
  return Object(__WEBPACK_IMPORTED_MODULE_6__Seq__["c" /* fold */])(function (acc$$9, tupledArg) {
    return MapTreeModule$$$add(comparer$$13, tupledArg[0], tupledArg[1], acc$$9);
  }, MapTreeModule$$$empty(), l$$20);
}
function MapTreeModule$$$mkFromEnumerator(comparer$$14, acc$$10, e) {
  MapTreeModule$$$mkFromEnumerator: while (true) {
    if (e.MoveNext()) {
      var patternInput$$2 = e.Current;
      var $acc$$10$$75 = acc$$10;
      var $comparer$$14$$74 = comparer$$14;
      var $e$$76 = e;
      comparer$$14 = $comparer$$14$$74;
      acc$$10 = MapTreeModule$$$add($comparer$$14$$74, patternInput$$2[0], patternInput$$2[1], $acc$$10$$75);
      e = $e$$76;
      continue MapTreeModule$$$mkFromEnumerator;
    } else {
      return acc$$10;
    }

    break;
  }
}
function MapTreeModule$$$ofArray(comparer$$15, arr) {
  var res$$2 = MapTreeModule$$$empty();

  for (var i = 0; i <= arr.length - 1; i++) {
    var patternInput$$3 = arr[i];
    res$$2 = MapTreeModule$$$add(comparer$$15, patternInput$$3[0], patternInput$$3[1], res$$2);
  }

  return res$$2;
}
function MapTreeModule$$$ofSeq(comparer$$16, c$$9) {
  var ie = Object(__WEBPACK_IMPORTED_MODULE_6__Seq__["f" /* getEnumerator */])(c$$9);

  try {
    return MapTreeModule$$$mkFromEnumerator(comparer$$16, MapTreeModule$$$empty(), ie);
  } finally {
    if (Object(__WEBPACK_IMPORTED_MODULE_7__Util__["m" /* isDisposable */])(ie)) {
      ie.Dispose();
    }
  }
}
function MapTreeModule$$$copyToArray(s$$4, arr$$1, i$$1) {
  var j = i$$1 | 0;
  MapTreeModule$$$iter(function f$$16(x$$15, y$$2) {
    arr$$1[j] = [x$$15, y$$2];
    j = j + 1;
  }, s$$4);
}
var MapTreeModule$002EMapIterator$00602 = Object(__WEBPACK_IMPORTED_MODULE_4__Types__["e" /* declare */])(function MapTreeModule$002EMapIterator$00602(arg1, arg2) {
  this.stack = arg1;
  this.started = arg2;
}, __WEBPACK_IMPORTED_MODULE_4__Types__["c" /* Record */]);
function MapTreeModule$$$collapseLHS(stack) {
  MapTreeModule$$$collapseLHS: while (true) {
    if (stack.tail != null) {
      if (stack.head.tag === 1) {
        return stack;
      } else if (stack.head.tag === 2) {
        var $stack$$77 = stack;
        stack = new __WEBPACK_IMPORTED_MODULE_4__Types__["b" /* List */]($stack$$77.head.fields[2], new __WEBPACK_IMPORTED_MODULE_4__Types__["b" /* List */](new MapTree$00602(1, "MapOne", $stack$$77.head.fields[0], $stack$$77.head.fields[1]), new __WEBPACK_IMPORTED_MODULE_4__Types__["b" /* List */]($stack$$77.head.fields[3], $stack$$77.tail)));
        continue MapTreeModule$$$collapseLHS;
      } else {
        var $stack$$78 = stack;
        stack = $stack$$78.tail;
        continue MapTreeModule$$$collapseLHS;
      }
    } else {
      return new __WEBPACK_IMPORTED_MODULE_4__Types__["b" /* List */]();
    }

    break;
  }
}
function MapTreeModule$$$mkIterator(s$$5) {
  return new MapTreeModule$002EMapIterator$00602(MapTreeModule$$$collapseLHS(new __WEBPACK_IMPORTED_MODULE_4__Types__["b" /* List */](s$$5, new __WEBPACK_IMPORTED_MODULE_4__Types__["b" /* List */]())), false);
}
function MapTreeModule$$$notStarted() {
  throw new Error("enumeration not started");
}
function MapTreeModule$$$alreadyFinished() {
  throw new Error("enumeration already finished");
}
function MapTreeModule$$$current(i$$2) {
  if (i$$2.started) {
    var matchValue$$4 = i$$2.stack;

    if (matchValue$$4.tail == null) {
      return MapTreeModule$$$alreadyFinished();
    } else if (matchValue$$4.head.tag === 1) {
      return [matchValue$$4.head.fields[0], matchValue$$4.head.fields[1]];
    } else {
      throw new Error("Please report error: Map iterator, unexpected stack for current");
    }
  } else {
    return MapTreeModule$$$notStarted();
  }
}
function MapTreeModule$$$moveNext(i$$3) {
  if (i$$3.started) {
    var matchValue$$5 = i$$3.stack;

    if (matchValue$$5.tail == null) {
      return false;
    } else if (matchValue$$5.head.tag === 1) {
      i$$3.stack = MapTreeModule$$$collapseLHS(matchValue$$5.tail);
      return !(i$$3.stack.tail == null);
    } else {
      throw new Error("Please report error: Map iterator, unexpected stack for moveNext");
    }
  } else {
    i$$3.started = true;
    return !(i$$3.stack.tail == null);
  }
}
var MapTreeModule$002EmkIEnumerator$0027$00602 = Object(__WEBPACK_IMPORTED_MODULE_4__Types__["e" /* declare */])(function MapTreeModule$002EmkIEnumerator$0027$00602(s$$6) {
  var $this$$1 = this;
  $this$$1.s = s$$6;
  $this$$1.i = MapTreeModule$$$mkIterator($this$$1.s);
});
function MapTreeModule$002EmkIEnumerator$0027$00602$$$$002Ector$$Z26BC498C(s$$6) {
  return this != null ? MapTreeModule$002EmkIEnumerator$0027$00602.call(this, s$$6) : new MapTreeModule$002EmkIEnumerator$0027$00602(s$$6);
}
Object.defineProperty(MapTreeModule$002EmkIEnumerator$0027$00602.prototype, "Current", {
  "get": function get() {
    var __ = this;
    return MapTreeModule$$$current(__.i);
  }
});

MapTreeModule$002EmkIEnumerator$0027$00602.prototype.MoveNext = function () {
  var __$$1 = this;
  return MapTreeModule$$$moveNext(__$$1.i);
};

MapTreeModule$002EmkIEnumerator$0027$00602.prototype.Reset = function () {
  var __$$2 = this;
  __$$2.i = MapTreeModule$$$mkIterator(__$$2.s);
};

MapTreeModule$002EmkIEnumerator$0027$00602.prototype.Dispose = function () {};

function MapTreeModule$$$mkIEnumerator(s$$7) {
  return MapTreeModule$002EmkIEnumerator$0027$00602$$$$002Ector$$Z26BC498C(s$$7);
}
function MapTreeModule$$$toSeq(s$$8) {
  var en = MapTreeModule$$$mkIEnumerator(s$$8);
  return Object(__WEBPACK_IMPORTED_MODULE_6__Seq__["m" /* unfold */])(function generator(en$$1) {
    if (en$$1.MoveNext()) {
      return [en$$1.Current, en$$1];
    } else {
      return null;
    }
  }, en);
}
var FSharpMap = Object(__WEBPACK_IMPORTED_MODULE_4__Types__["e" /* declare */])(function FSharpMap(comparer$$17, tree) {
  var $this$$2 = this;
  $this$$2.comparer = comparer$$17;
  $this$$2.tree = tree;
});
function FSharpMap$$$$002Ector$$58ADD115(comparer$$17, tree) {
  return this != null ? FSharpMap.call(this, comparer$$17, tree) : new FSharpMap(comparer$$17, tree);
}
function FSharpMap$$get_Comparer(__$$4) {
  return __$$4.comparer;
}
function FSharpMap$$get_Tree(__$$5) {
  return __$$5.tree;
}
function FSharpMap$$Add$$5BDDA1(__$$6, k$$28, v$$24) {
  return FSharpMap$$$$002Ector$$58ADD115(__$$6.comparer, MapTreeModule$$$add(__$$6.comparer, k$$28, v$$24, __$$6.tree));
}
function FSharpMap$$get_IsEmpty(__$$7) {
  return MapTreeModule$$$isEmpty(__$$7.tree);
}
function FSharpMap$$get_Item$$2B595(__$$8, k$$29) {
  return MapTreeModule$$$find(__$$8.comparer, k$$29, __$$8.tree);
}
function FSharpMap$$TryGetValue$$5BDDA1(__$$9, k$$30, defValue) {
  var matchValue$$6 = MapTreeModule$$$tryFind(__$$9.comparer, k$$30, __$$9.tree);

  if (matchValue$$6 == null) {
    return [false, defValue];
  } else {
    var v$$25 = Object(__WEBPACK_IMPORTED_MODULE_5__Option__["d" /* value */])(matchValue$$6);
    return [true, v$$25];
  }
}
function FSharpMap$$TryPick$$72321DD7(__$$10, f$$17) {
  return MapTreeModule$$$tryPick(f$$17, __$$10.tree);
}
function FSharpMap$$Exists$$Z395DDC35(__$$11, f$$18) {
  return MapTreeModule$$$exists(f$$18, __$$11.tree);
}
function FSharpMap$$Filter$$Z395DDC35(__$$12, f$$19) {
  return FSharpMap$$$$002Ector$$58ADD115(__$$12.comparer, MapTreeModule$$$filter(__$$12.comparer, f$$19, __$$12.tree));
}
function FSharpMap$$ForAll$$Z395DDC35(__$$13, f$$20) {
  return MapTreeModule$$$forall(f$$20, __$$13.tree);
}
function FSharpMap$$Fold(__$$14, f$$21, acc$$11) {
  return MapTreeModule$$$foldBack(f$$21, __$$14.tree, acc$$11);
}
function FSharpMap$$FoldSection(__$$15, lo$$2, hi$$2, f$$22, acc$$12) {
  return MapTreeModule$$$foldSection(__$$15.comparer, lo$$2, hi$$2, f$$22, __$$15.tree, acc$$12);
}
function FSharpMap$$Iterate$$1DCFB91D(__$$16, f$$23) {
  MapTreeModule$$$iter(f$$23, __$$16.tree);
}
function FSharpMap$$MapRange$$6DC7247(__$$17, f$$24) {
  return FSharpMap$$$$002Ector$$58ADD115(__$$17.comparer, MapTreeModule$$$map(f$$24, __$$17.tree));
}
function FSharpMap$$Map$$Z6F6B671C(__$$18, f$$25) {
  return FSharpMap$$$$002Ector$$58ADD115(__$$18.comparer, MapTreeModule$$$mapi(f$$25, __$$18.tree));
}
function FSharpMap$$Partition$$Z395DDC35(__$$19, f$$26) {
  var patternInput$$4 = MapTreeModule$$$partition(__$$19.comparer, f$$26, __$$19.tree);
  return [FSharpMap$$$$002Ector$$58ADD115(__$$19.comparer, patternInput$$4[0]), FSharpMap$$$$002Ector$$58ADD115(__$$19.comparer, patternInput$$4[1])];
}
function FSharpMap$$get_Count(__$$20) {
  return MapTreeModule$$$size(__$$20.tree);
}
function FSharpMap$$ContainsKey$$2B595(__$$21, k$$31) {
  return MapTreeModule$$$mem(__$$21.comparer, k$$31, __$$21.tree);
}
function FSharpMap$$Remove$$2B595(__$$22, k$$32) {
  return FSharpMap$$$$002Ector$$58ADD115(__$$22.comparer, MapTreeModule$$$remove(__$$22.comparer, k$$32, __$$22.tree));
}
function FSharpMap$$TryFind$$2B595(__$$23, k$$33) {
  return MapTreeModule$$$tryFind(__$$23.comparer, k$$33, __$$23.tree);
}
function FSharpMap$$ToList(__$$24) {
  return MapTreeModule$$$toList(__$$24.tree);
}

FSharpMap.prototype.toString = function () {
  var this$ = this;
  return "map [" + __WEBPACK_IMPORTED_MODULE_8__String__["a" /* join */].apply(undefined, ["; "].concat(__WEBPACK_IMPORTED_MODULE_3_babel_runtime_helpers_toConsumableArray___default()(Object(__WEBPACK_IMPORTED_MODULE_6__Seq__["h" /* map */])(function mapping(kv) {
    return Object(__WEBPACK_IMPORTED_MODULE_8__String__["d" /* toText */])(Object(__WEBPACK_IMPORTED_MODULE_8__String__["b" /* printf */])("(%A, %A)"))(kv[0])(kv[1]);
  }, this$)))) + "]";
};

FSharpMap.prototype.GetHashCode = function () {
  var this$$$1 = this;

  var combineHash = function combineHash(x$$16, y$$3) {
    return (x$$16 << 1) + y$$3 + 631;
  };

  var res$$3 = 0;
  var e$$1 = MapTreeModule$$$mkIEnumerator(FSharpMap$$get_Tree(this$$$1));

  while (e$$1.MoveNext()) {
    var activePatternResult3017 = e$$1.Current;
    res$$3 = combineHash(res$$3, Object(__WEBPACK_IMPORTED_MODULE_7__Util__["q" /* structuralHash */])(activePatternResult3017[0]));
    res$$3 = combineHash(res$$3, Object(__WEBPACK_IMPORTED_MODULE_7__Util__["q" /* structuralHash */])(activePatternResult3017[1]));
  }

  return Math.abs(res$$3) | 0;
};

FSharpMap.prototype.Equals = function (that) {
  var this$$$2 = this;
  return this$$$2.CompareTo(that) === 0;
};

FSharpMap.prototype[__WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_symbol_iterator___default.a] = function () {
  var __$$25 = this;
  return Object(__WEBPACK_IMPORTED_MODULE_6__Seq__["l" /* toIterator */])(MapTreeModule$$$mkIEnumerator(__$$25.tree));
};

FSharpMap.prototype.CompareTo = function (obj) {
  var m$$22 = this;
  var m2 = obj;
  var res$$4 = 0;
  var finished = false;
  var e1 = MapTreeModule$$$mkIEnumerator(FSharpMap$$get_Tree(m$$22));

  try {
    var e2 = MapTreeModule$$$mkIEnumerator(FSharpMap$$get_Tree(m2));

    try {
      while (!finished ? res$$4 === 0 : false) {
        var matchValue$$7 = [e1.MoveNext(), e2.MoveNext()];

        if (matchValue$$7[0]) {
          if (matchValue$$7[1]) {
            var kvp1 = e1.Current;
            var kvp2 = e2.Current;
            var c$$10 = m$$22.comparer.Compare(kvp1[0], kvp2[0]) | 0;
            res$$4 = c$$10 !== 0 ? c$$10 : Object(__WEBPACK_IMPORTED_MODULE_7__Util__["c" /* compare */])(kvp1[1], kvp2[1]);
          } else {
            res$$4 = 1;
          }
        } else if (matchValue$$7[1]) {
          res$$4 = -1;
        } else {
          finished = true;
        }
      }

      return res$$4 | 0;
    } finally {
      if (Object(__WEBPACK_IMPORTED_MODULE_7__Util__["m" /* isDisposable */])(e2)) {
        e2.Dispose();
      }
    }
  } finally {
    if (Object(__WEBPACK_IMPORTED_MODULE_7__Util__["m" /* isDisposable */])(e1)) {
      e1.Dispose();
    }
  }
};

function isEmpty(m$$23) {
  return FSharpMap$$get_IsEmpty(m$$23);
}
function add(k$$34, v$$26, m$$24) {
  return FSharpMap$$Add$$5BDDA1(m$$24, k$$34, v$$26);
}
function find(k$$35, m$$25) {
  return FSharpMap$$get_Item$$2B595(m$$25, k$$35);
}
function tryFind(k$$36, m$$26) {
  return FSharpMap$$TryFind$$2B595(m$$26, k$$36);
}
function remove(k$$37, m$$27) {
  return FSharpMap$$Remove$$2B595(m$$27, k$$37);
}
function containsKey(k$$38, m$$28) {
  return FSharpMap$$ContainsKey$$2B595(m$$28, k$$38);
}
function iterate(f$$27, m$$29) {
  FSharpMap$$Iterate$$1DCFB91D(m$$29, f$$27);
}
function tryPick(f$$28, m$$30) {
  return FSharpMap$$TryPick$$72321DD7(m$$30, f$$28);
}
function pick(f$$29, m$$31) {
  var matchValue$$8 = tryPick(f$$29, m$$31);

  if (matchValue$$8 != null) {
    var res$$5 = Object(__WEBPACK_IMPORTED_MODULE_5__Option__["d" /* value */])(matchValue$$8);
    return res$$5;
  } else {
    throw new Error("key not found");
  }
}
function exists(f$$30, m$$32) {
  return FSharpMap$$Exists$$Z395DDC35(m$$32, f$$30);
}
function filter(f$$31, m$$33) {
  return FSharpMap$$Filter$$Z395DDC35(m$$33, f$$31);
}
function partition(f$$32, m$$34) {
  return FSharpMap$$Partition$$Z395DDC35(m$$34, f$$32);
}
function forAll(f$$33, m$$35) {
  return FSharpMap$$ForAll$$Z395DDC35(m$$35, f$$33);
}
function mapRange(f$$34, m$$36) {
  return FSharpMap$$MapRange$$6DC7247(m$$36, f$$34);
}
function map(f$$35, m$$37) {
  return FSharpMap$$Map$$Z6F6B671C(m$$37, f$$35);
}
function fold(f$$36, z, m$$38) {
  return MapTreeModule$$$fold(f$$36, z, FSharpMap$$get_Tree(m$$38));
}
function foldBack(f$$37, m$$39, z$$1) {
  return MapTreeModule$$$foldBack(f$$37, FSharpMap$$get_Tree(m$$39), z$$1);
}
function toSeq(m$$40) {
  return MapTreeModule$$$toSeq(FSharpMap$$get_Tree(m$$40));
}
function findKey(f$$38, m$$41) {
  var _arg1$$1 = MapTreeModule$$$tryPick(function f$$39(k$$39, v$$27) {
    if (f$$38(k$$39, v$$27)) {
      return Object(__WEBPACK_IMPORTED_MODULE_5__Option__["c" /* some */])(k$$39);
    } else {
      return null;
    }
  }, FSharpMap$$get_Tree(m$$41));

  if (_arg1$$1 == null) {
    throw new Error("Key not found");
  } else {
    var k$$40 = Object(__WEBPACK_IMPORTED_MODULE_5__Option__["d" /* value */])(_arg1$$1);
    return k$$40;
  }
}
function tryFindKey(f$$40, m$$43) {
  return MapTreeModule$$$tryPick(function f$$41(k$$41, v$$28) {
    if (f$$40(k$$41, v$$28)) {
      return Object(__WEBPACK_IMPORTED_MODULE_5__Option__["c" /* some */])(k$$41);
    } else {
      return null;
    }
  }, FSharpMap$$get_Tree(m$$43));
}
function ofList(l$$22, comparer$$18) {
  return FSharpMap$$$$002Ector$$58ADD115(comparer$$18, MapTreeModule$$$ofList(comparer$$18, l$$22));
}
function ofSeq(l$$23, comparer$$19) {
  return FSharpMap$$$$002Ector$$58ADD115(comparer$$19, MapTreeModule$$$ofSeq(comparer$$19, l$$23));
}
function ofArray(array, comparer$$20) {
  return FSharpMap$$$$002Ector$$58ADD115(comparer$$20, MapTreeModule$$$ofArray(comparer$$20, array));
}
function toList(m$$45) {
  return FSharpMap$$ToList(m$$45);
}
function toArray(m$$46) {
  var res$$6 = new Array(FSharpMap$$get_Count(m$$46));
  MapTreeModule$$$copyToArray(FSharpMap$$get_Tree(m$$46), res$$6, 0);
  return res$$6;
}
function empty(comparer$$21) {
  return FSharpMap$$$$002Ector$$58ADD115(comparer$$21, new MapTree$00602(0, "MapEmpty"));
}

function createMutablePrivate(comparer$$22, tree$0027) {
  var _ref;

  var tree$$1 = tree$0027;
  return _ref = {
    get size() {
      return MapTreeModule$$$size(tree$$1);
    },

    clear: function clear() {
      tree$$1 = new MapTree$00602(0, "MapEmpty");
    },
    delete: function _delete(x$$18) {
      if (MapTreeModule$$$mem(comparer$$22, x$$18, tree$$1)) {
        tree$$1 = MapTreeModule$$$remove(comparer$$22, x$$18, tree$$1);
        return true;
      } else {
        return false;
      }
    },
    entries: function entries() {
      return MapTreeModule$$$toSeq(tree$$1);
    },
    get: function get(k$$42) {
      return MapTreeModule$$$find(comparer$$22, k$$42, tree$$1);
    },
    has: function has(x$$19) {
      return MapTreeModule$$$mem(comparer$$22, x$$19, tree$$1);
    },
    keys: function keys() {
      return Object(__WEBPACK_IMPORTED_MODULE_6__Seq__["h" /* map */])(function mapping$$1(kv$$1) {
        return kv$$1[0];
      }, MapTreeModule$$$toSeq(tree$$1));
    },
    set: function set(k$$43, v$$29) {
      var this$$$3 = this;
      tree$$1 = MapTreeModule$$$add(comparer$$22, k$$43, v$$29, tree$$1);
      return this$$$3;
    },
    values: function values() {
      return Object(__WEBPACK_IMPORTED_MODULE_6__Seq__["h" /* map */])(function mapping$$2(kv$$2) {
        return kv$$2[1];
      }, MapTreeModule$$$toSeq(tree$$1));
    }
  }, __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_defineProperty___default()(_ref, __WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_symbol_iterator___default.a, function () {
    return Object(__WEBPACK_IMPORTED_MODULE_6__Seq__["l" /* toIterator */])(MapTreeModule$$$mkIEnumerator(tree$$1));
  }), __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_defineProperty___default()(_ref, "GetEnumerator", function GetEnumerator() {
    return MapTreeModule$$$mkIEnumerator(tree$$1);
  }), _ref;
}

function createMutable(source$$3, comparer$$23) {
  return createMutablePrivate(comparer$$23, MapTreeModule$$$ofSeq(comparer$$23, source$$3));
}
function groupBy(projection, xs, comparer$$24) {
  var dict = createMutable(Object(__WEBPACK_IMPORTED_MODULE_6__Seq__["b" /* empty */])(), comparer$$24);
  Object(__WEBPACK_IMPORTED_MODULE_6__Seq__["g" /* iterate */])(function (v$$30) {
    var key = projection(v$$30);

    if (dict.has(key)) {
      dict.get(key).push(v$$30);
    } else {
      dict.set(key, __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_array_from___default()([v$$30]));
    }
  }, xs);
  return Object(__WEBPACK_IMPORTED_MODULE_6__Seq__["h" /* map */])(function mapping$$3(kv$$3) {
    return [kv$$3[0], kv$$3[1]];
  }, dict);
}
function countBy(projection$$1, xs$$1, comparer$$25) {
  var dict$$1 = createMutable(Object(__WEBPACK_IMPORTED_MODULE_6__Seq__["b" /* empty */])(), comparer$$25);
  Object(__WEBPACK_IMPORTED_MODULE_6__Seq__["g" /* iterate */])(function (value$$1) {
    var key$$1 = projection$$1(value$$1);
    dict$$1.has(key$$1) ? dict$$1.set(key$$1, dict$$1.get(key$$1) + 1) : dict$$1.set(key$$1, 1);
  }, xs$$1);
  return Object(__WEBPACK_IMPORTED_MODULE_6__Seq__["h" /* map */])(function mapping$$4(kv$$4) {
    return [kv$$4[0], kv$$4[1]];
  }, dict$$1);
}

/***/ }),
/* 81 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export SetTree$00601 */
/* unused harmony export SetTreeModule$$$countAux */
/* unused harmony export SetTreeModule$$$count */
/* unused harmony export SetTreeModule$$$SetOne */
/* unused harmony export SetTreeModule$$$SetNode */
/* unused harmony export SetTreeModule$$$height */
/* unused harmony export SetTreeModule$$$tolerance */
/* unused harmony export SetTreeModule$$$mk */
/* unused harmony export SetTreeModule$$$rebalance */
/* unused harmony export SetTreeModule$$$add */
/* unused harmony export SetTreeModule$$$balance */
/* unused harmony export SetTreeModule$$$split */
/* unused harmony export SetTreeModule$$$spliceOutSuccessor */
/* unused harmony export SetTreeModule$$$remove */
/* unused harmony export SetTreeModule$$$mem */
/* unused harmony export SetTreeModule$$$iter */
/* unused harmony export SetTreeModule$$$foldBack */
/* unused harmony export SetTreeModule$$$fold */
/* unused harmony export SetTreeModule$$$forall */
/* unused harmony export SetTreeModule$$$exists */
/* unused harmony export SetTreeModule$$$isEmpty */
/* unused harmony export SetTreeModule$$$subset */
/* unused harmony export SetTreeModule$$$psubset */
/* unused harmony export SetTreeModule$$$filterAux */
/* unused harmony export SetTreeModule$$$filter */
/* unused harmony export SetTreeModule$$$diffAux */
/* unused harmony export SetTreeModule$$$diff */
/* unused harmony export SetTreeModule$$$union */
/* unused harmony export SetTreeModule$$$intersectionAux */
/* unused harmony export SetTreeModule$$$intersection */
/* unused harmony export SetTreeModule$$$partition1 */
/* unused harmony export SetTreeModule$$$partitionAux */
/* unused harmony export SetTreeModule$$$partition */
/* unused harmony export SetTreeModule$$$$007CMatchSetNode$007CMatchSetEmpty$007C */
/* unused harmony export SetTreeModule$$$minimumElementAux */
/* unused harmony export SetTreeModule$$$minimumElementOpt */
/* unused harmony export SetTreeModule$$$maximumElementAux */
/* unused harmony export SetTreeModule$$$maximumElementOpt */
/* unused harmony export SetTreeModule$$$minimumElement */
/* unused harmony export SetTreeModule$$$maximumElement */
/* unused harmony export SetTreeModule$002ESetIterator$00601 */
/* unused harmony export SetTreeModule$$$collapseLHS */
/* unused harmony export SetTreeModule$$$mkIterator */
/* unused harmony export SetTreeModule$$$notStarted */
/* unused harmony export SetTreeModule$$$alreadyFinished */
/* unused harmony export SetTreeModule$$$current */
/* unused harmony export SetTreeModule$$$moveNext */
/* unused harmony export SetTreeModule$002EmkIEnumerator$00601 */
/* unused harmony export SetTreeModule$002EmkIEnumerator$00601$$$$002Ector$$Z5B395D56 */
/* unused harmony export SetTreeModule$$$mkIEnumerator */
/* unused harmony export SetTreeModule$$$toSeq */
/* unused harmony export SetTreeModule$$$compareStacks */
/* unused harmony export SetTreeModule$$$compare */
/* unused harmony export SetTreeModule$$$choose */
/* unused harmony export SetTreeModule$$$loop */
/* unused harmony export SetTreeModule$$$toList */
/* unused harmony export SetTreeModule$$$copyToArray */
/* unused harmony export SetTreeModule$$$mkFromEnumerator */
/* unused harmony export SetTreeModule$$$ofSeq */
/* unused harmony export SetTreeModule$$$ofArray */
/* unused harmony export FSharpSet */
/* unused harmony export FSharpSet$$$$002Ector$$2528C5CB */
/* unused harmony export FSharpSet$$get_Comparer */
/* unused harmony export FSharpSet$$get_Tree */
/* unused harmony export FSharpSet$$Add$$2B595 */
/* unused harmony export FSharpSet$$Remove$$2B595 */
/* unused harmony export FSharpSet$$get_Count */
/* unused harmony export FSharpSet$$Contains$$2B595 */
/* unused harmony export FSharpSet$$Iterate$$5028453F */
/* unused harmony export FSharpSet$$Fold */
/* unused harmony export FSharpSet$$get_IsEmpty */
/* unused harmony export FSharpSet$$Partition$$Z1D55A0D7 */
/* unused harmony export FSharpSet$$Filter$$Z1D55A0D7 */
/* unused harmony export FSharpSet$$Map$$38806891 */
/* unused harmony export FSharpSet$$Exists$$Z1D55A0D7 */
/* unused harmony export FSharpSet$$ForAll$$Z1D55A0D7 */
/* unused harmony export FSharpSet$$$op_Subtraction */
/* unused harmony export FSharpSet$$$op_Addition */
/* unused harmony export FSharpSet$$$Intersection$$Z3BE9BFE0 */
/* unused harmony export FSharpSet$$$IntersectionMany$$Z15B59630 */
/* unused harmony export FSharpSet$$$Equality$$Z3BE9BFE0 */
/* unused harmony export FSharpSet$$$Compare$$Z3BE9BFE0 */
/* unused harmony export FSharpSet$$get_Choose */
/* unused harmony export FSharpSet$$get_MinimumElement */
/* unused harmony export FSharpSet$$get_MaximumElement */
/* unused harmony export FSharpSet$$IsSubsetOf$$6A20B1FF */
/* unused harmony export FSharpSet$$IsSupersetOf$$6A20B1FF */
/* unused harmony export FSharpSet$$IsProperSubsetOf$$6A20B1FF */
/* unused harmony export FSharpSet$$IsProperSupersetOf$$6A20B1FF */
/* unused harmony export isEmpty */
/* unused harmony export contains */
/* unused harmony export add */
/* unused harmony export singleton */
/* unused harmony export remove */
/* unused harmony export union */
/* unused harmony export unionMany */
/* unused harmony export intersect */
/* unused harmony export intersectMany */
/* unused harmony export iterate */
/* unused harmony export empty */
/* unused harmony export forAll */
/* unused harmony export exists */
/* unused harmony export filter */
/* unused harmony export partition */
/* unused harmony export fold */
/* unused harmony export foldBack */
/* unused harmony export map */
/* unused harmony export count */
/* unused harmony export minimumElement */
/* unused harmony export maximumElement */
/* unused harmony export ofList */
/* unused harmony export ofArray */
/* unused harmony export toList */
/* unused harmony export toArray */
/* unused harmony export toSeq */
/* unused harmony export ofSeq */
/* unused harmony export difference */
/* unused harmony export isSubset */
/* unused harmony export isSuperset */
/* unused harmony export isProperSubset */
/* unused harmony export isProperSuperset */
/* unused harmony export minElement */
/* unused harmony export maxElement */
/* harmony export (immutable) */ __webpack_exports__["a"] = createMutable;
/* unused harmony export distinct */
/* unused harmony export distinctBy */
/* unused harmony export unionWith */
/* unused harmony export intersectWith */
/* unused harmony export exceptWith */
/* unused harmony export isSubsetOf */
/* unused harmony export isSupersetOf */
/* unused harmony export isProperSubsetOf */
/* unused harmony export isProperSupersetOf */
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_helpers_defineProperty__ = __webpack_require__(56);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_helpers_defineProperty___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_babel_runtime_helpers_defineProperty__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_symbol_iterator__ = __webpack_require__(20);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_symbol_iterator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_symbol_iterator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_babel_runtime_helpers_toConsumableArray__ = __webpack_require__(28);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_babel_runtime_helpers_toConsumableArray___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_babel_runtime_helpers_toConsumableArray__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__Types__ = __webpack_require__(16);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__Option__ = __webpack_require__(22);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__Seq__ = __webpack_require__(32);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__Util__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__String__ = __webpack_require__(45);








var SetTree$00601 = Object(__WEBPACK_IMPORTED_MODULE_3__Types__["e" /* declare */])(function SetTree$00601(tag, name) {
  for (var _len = arguments.length, fields = Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++) {
    fields[_key - 2] = arguments[_key];
  }

  __WEBPACK_IMPORTED_MODULE_3__Types__["d" /* Union */].call.apply(__WEBPACK_IMPORTED_MODULE_3__Types__["d" /* Union */], [this, tag, name].concat(fields));
}, __WEBPACK_IMPORTED_MODULE_3__Types__["d" /* Union */]);
function SetTreeModule$$$countAux(s, acc) {
  SetTreeModule$$$countAux: while (true) {
    switch (s.tag) {
      case 2:
        {
          return acc + 1 | 0;
        }

      case 0:
        {
          return acc | 0;
        }

      default:
        {
          var r = s.fields[2];
          var l = s.fields[1];
          var $acc$$3 = acc;
          s = l;
          acc = SetTreeModule$$$countAux(r, $acc$$3 + 1);
          continue SetTreeModule$$$countAux;
        }
    }

    break;
  }
}
function SetTreeModule$$$count(s$$1) {
  return SetTreeModule$$$countAux(s$$1, 0);
}
function SetTreeModule$$$SetOne(n) {
  return new SetTree$00601(2, "SetOne", n);
}
function SetTreeModule$$$SetNode(x, l$$1, r$$1, h) {
  return new SetTree$00601(1, "SetNode", x, l$$1, r$$1, h);
}
function SetTreeModule$$$height(t) {
  switch (t.tag) {
    case 2:
      {
        return 1;
      }

    case 1:
      {
        var h$$1 = t.fields[3] | 0;
        return h$$1 | 0;
      }

    default:
      {
        return 0;
      }
  }
}
var SetTreeModule$$$tolerance = 2;
function SetTreeModule$$$mk(l$$2, k, r$$2) {
  var matchValue = [l$$2, r$$2];
  var $target$$4;

  if (matchValue[0].tag === 0) {
    if (matchValue[1].tag === 0) {
      $target$$4 = 0;
    } else {
      $target$$4 = 1;
    }
  } else {
    $target$$4 = 1;
  }

  switch ($target$$4) {
    case 0:
      {
        return SetTreeModule$$$SetOne(k);
      }

    case 1:
      {
        var hl = SetTreeModule$$$height(l$$2) | 0;
        var hr = SetTreeModule$$$height(r$$2) | 0;
        var m = (hl < hr ? hr : hl) | 0;
        return SetTreeModule$$$SetNode(k, l$$2, r$$2, m + 1);
      }
  }
}
function SetTreeModule$$$rebalance(t1, k$$1, t2) {
  var t1h = SetTreeModule$$$height(t1) | 0;
  var t2h = SetTreeModule$$$height(t2) | 0;

  if (t2h > t1h + SetTreeModule$$$tolerance) {
    if (t2.tag === 1) {
      var t2r = t2.fields[2];
      var t2l = t2.fields[1];
      var t2k = t2.fields[0];

      if (SetTreeModule$$$height(t2l) > t1h + 1) {
        if (t2l.tag === 1) {
          var t2lr = t2l.fields[2];
          var t2ll = t2l.fields[1];
          var t2lk = t2l.fields[0];
          return SetTreeModule$$$mk(SetTreeModule$$$mk(t1, k$$1, t2ll), t2lk, SetTreeModule$$$mk(t2lr, t2k, t2r));
        } else {
          throw new Error("rebalance");
        }
      } else {
        return SetTreeModule$$$mk(SetTreeModule$$$mk(t1, k$$1, t2l), t2k, t2r);
      }
    } else {
      throw new Error("rebalance");
    }
  } else if (t1h > t2h + SetTreeModule$$$tolerance) {
    if (t1.tag === 1) {
      var t1r = t1.fields[2];
      var t1l = t1.fields[1];
      var t1k = t1.fields[0];

      if (SetTreeModule$$$height(t1r) > t2h + 1) {
        if (t1r.tag === 1) {
          var t1rr = t1r.fields[2];
          var t1rl = t1r.fields[1];
          var t1rk = t1r.fields[0];
          return SetTreeModule$$$mk(SetTreeModule$$$mk(t1l, t1k, t1rl), t1rk, SetTreeModule$$$mk(t1rr, k$$1, t2));
        } else {
          throw new Error("rebalance");
        }
      } else {
        return SetTreeModule$$$mk(t1l, t1k, SetTreeModule$$$mk(t1r, k$$1, t2));
      }
    } else {
      throw new Error("rebalance");
    }
  } else {
    return SetTreeModule$$$mk(t1, k$$1, t2);
  }
}
function SetTreeModule$$$add(comparer, k$$2, t$$1) {
  switch (t$$1.tag) {
    case 2:
      {
        var k2$$1 = t$$1.fields[0];
        var c$$1 = comparer.Compare(k$$2, k2$$1) | 0;

        if (c$$1 < 0) {
          return SetTreeModule$$$SetNode(k$$2, new SetTree$00601(0, "SetEmpty"), t$$1, 2);
        } else if (c$$1 === 0) {
          return t$$1;
        } else {
          return SetTreeModule$$$SetNode(k$$2, t$$1, new SetTree$00601(0, "SetEmpty"), 2);
        }
      }

    case 0:
      {
        return SetTreeModule$$$SetOne(k$$2);
      }

    default:
      {
        var r$$3 = t$$1.fields[2];
        var l$$3 = t$$1.fields[1];
        var k2 = t$$1.fields[0];
        var c = comparer.Compare(k$$2, k2) | 0;

        if (c < 0) {
          return SetTreeModule$$$rebalance(SetTreeModule$$$add(comparer, k$$2, l$$3), k2, r$$3);
        } else if (c === 0) {
          return t$$1;
        } else {
          return SetTreeModule$$$rebalance(l$$3, k2, SetTreeModule$$$add(comparer, k$$2, r$$3));
        }
      }
  }
}
function SetTreeModule$$$balance(comparer$$1, t1$$1, k$$3, t2$$1) {
  var matchValue$$1 = [t1$$1, t2$$1];
  var $target$$5, t2$$2, t1$$2, k1, t2$$3, k2$$2, t1$$3, h1, h2, k1$$1, k2$$3, t11, t12, t21, t22;

  if (matchValue$$1[0].tag === 2) {
    if (matchValue$$1[1].tag === 0) {
      $target$$5 = 1;
      t1$$2 = matchValue$$1[0];
    } else if (matchValue$$1[1].tag === 2) {
      $target$$5 = 2;
      k1 = matchValue$$1[0].fields[0];
      t2$$3 = matchValue$$1[1];
    } else {
      $target$$5 = 2;
      k1 = matchValue$$1[0].fields[0];
      t2$$3 = matchValue$$1[1];
    }
  } else if (matchValue$$1[0].tag === 1) {
    if (matchValue$$1[1].tag === 2) {
      $target$$5 = 3;
      k2$$2 = matchValue$$1[1].fields[0];
      t1$$3 = matchValue$$1[0];
    } else if (matchValue$$1[1].tag === 1) {
      $target$$5 = 4;
      h1 = matchValue$$1[0].fields[3];
      h2 = matchValue$$1[1].fields[3];
      k1$$1 = matchValue$$1[0].fields[0];
      k2$$3 = matchValue$$1[1].fields[0];
      t11 = matchValue$$1[0].fields[1];
      t12 = matchValue$$1[0].fields[2];
      t21 = matchValue$$1[1].fields[1];
      t22 = matchValue$$1[1].fields[2];
    } else {
      $target$$5 = 1;
      t1$$2 = matchValue$$1[0];
    }
  } else {
    $target$$5 = 0;
    t2$$2 = matchValue$$1[1];
  }

  switch ($target$$5) {
    case 0:
      {
        return SetTreeModule$$$add(comparer$$1, k$$3, t2$$2);
      }

    case 1:
      {
        return SetTreeModule$$$add(comparer$$1, k$$3, t1$$2);
      }

    case 2:
      {
        return SetTreeModule$$$add(comparer$$1, k$$3, SetTreeModule$$$add(comparer$$1, k1, t2$$3));
      }

    case 3:
      {
        return SetTreeModule$$$add(comparer$$1, k$$3, SetTreeModule$$$add(comparer$$1, k2$$2, t1$$3));
      }

    case 4:
      {
        if (h1 + SetTreeModule$$$tolerance < h2) {
          return SetTreeModule$$$rebalance(SetTreeModule$$$balance(comparer$$1, t1$$1, k$$3, t21), k2$$3, t22);
        } else if (h2 + SetTreeModule$$$tolerance < h1) {
          return SetTreeModule$$$rebalance(t11, k1$$1, SetTreeModule$$$balance(comparer$$1, t12, k$$3, t2$$1));
        } else {
          return SetTreeModule$$$mk(t1$$1, k$$3, t2$$1);
        }
      }
  }
}
function SetTreeModule$$$split(comparer$$2, pivot, t$$2) {
  switch (t$$2.tag) {
    case 2:
      {
        var k1$$3 = t$$2.fields[0];
        var c$$3 = comparer$$2.Compare(k1$$3, pivot) | 0;

        if (c$$3 < 0) {
          return [t$$2, false, new SetTree$00601(0, "SetEmpty")];
        } else if (c$$3 === 0) {
          return [new SetTree$00601(0, "SetEmpty"), true, new SetTree$00601(0, "SetEmpty")];
        } else {
          return [new SetTree$00601(0, "SetEmpty"), false, t$$2];
        }
      }

    case 0:
      {
        return [new SetTree$00601(0, "SetEmpty"), false, new SetTree$00601(0, "SetEmpty")];
      }

    default:
      {
        var t12$$1 = t$$2.fields[2];
        var t11$$1 = t$$2.fields[1];
        var k1$$2 = t$$2.fields[0];
        var c$$2 = comparer$$2.Compare(pivot, k1$$2) | 0;

        if (c$$2 < 0) {
          var patternInput = SetTreeModule$$$split(comparer$$2, pivot, t11$$1);
          return [patternInput[0], patternInput[1], SetTreeModule$$$balance(comparer$$2, patternInput[2], k1$$2, t12$$1)];
        } else if (c$$2 === 0) {
          return [t11$$1, true, t12$$1];
        } else {
          var patternInput$$1 = SetTreeModule$$$split(comparer$$2, pivot, t12$$1);
          return [SetTreeModule$$$balance(comparer$$2, t11$$1, k1$$2, patternInput$$1[0]), patternInput$$1[1], patternInput$$1[2]];
        }
      }
  }
}
function SetTreeModule$$$spliceOutSuccessor(t$$3) {
  switch (t$$3.tag) {
    case 2:
      {
        var k2$$4 = t$$3.fields[0];
        return [k2$$4, new SetTree$00601(0, "SetEmpty")];
      }

    case 1:
      {
        var r$$4 = t$$3.fields[2];
        var l$$4 = t$$3.fields[1];
        var k2$$5 = t$$3.fields[0];

        if (l$$4.tag === 0) {
          return [k2$$5, r$$4];
        } else {
          var patternInput$$2 = SetTreeModule$$$spliceOutSuccessor(l$$4);
          return [patternInput$$2[0], SetTreeModule$$$mk(patternInput$$2[1], k2$$5, r$$4)];
        }
      }

    default:
      {
        throw new Error("internal error: Set.spliceOutSuccessor");
      }
  }
}
function SetTreeModule$$$remove(comparer$$3, k$$4, t$$4) {
  switch (t$$4.tag) {
    case 2:
      {
        var k2$$6 = t$$4.fields[0];
        var c$$4 = comparer$$3.Compare(k$$4, k2$$6) | 0;

        if (c$$4 === 0) {
          return new SetTree$00601(0, "SetEmpty");
        } else {
          return t$$4;
        }
      }

    case 1:
      {
        var r$$5 = t$$4.fields[2];
        var l$$5 = t$$4.fields[1];
        var k2$$7 = t$$4.fields[0];
        var c$$5 = comparer$$3.Compare(k$$4, k2$$7) | 0;

        if (c$$5 < 0) {
          return SetTreeModule$$$rebalance(SetTreeModule$$$remove(comparer$$3, k$$4, l$$5), k2$$7, r$$5);
        } else if (c$$5 === 0) {
          var matchValue$$2 = [l$$5, r$$5];

          if (matchValue$$2[0].tag === 0) {
            return r$$5;
          } else if (matchValue$$2[1].tag === 0) {
            return l$$5;
          } else {
            var patternInput$$3 = SetTreeModule$$$spliceOutSuccessor(r$$5);
            return SetTreeModule$$$mk(l$$5, patternInput$$3[0], patternInput$$3[1]);
          }
        } else {
          return SetTreeModule$$$rebalance(l$$5, k2$$7, SetTreeModule$$$remove(comparer$$3, k$$4, r$$5));
        }
      }

    default:
      {
        return t$$4;
      }
  }
}
function SetTreeModule$$$mem(comparer$$4, k$$5, t$$5) {
  SetTreeModule$$$mem: while (true) {
    switch (t$$5.tag) {
      case 2:
        {
          var k2$$9 = t$$5.fields[0];
          return comparer$$4.Compare(k$$5, k2$$9) === 0;
        }

      case 0:
        {
          return false;
        }

      default:
        {
          var r$$6 = t$$5.fields[2];
          var l$$6 = t$$5.fields[1];
          var k2$$8 = t$$5.fields[0];
          var c$$6 = comparer$$4.Compare(k$$5, k2$$8) | 0;

          if (c$$6 < 0) {
            var $comparer$$4$$6 = comparer$$4;
            var $k$$5$$7 = k$$5;
            comparer$$4 = $comparer$$4$$6;
            k$$5 = $k$$5$$7;
            t$$5 = l$$6;
            continue SetTreeModule$$$mem;
          } else if (c$$6 === 0) {
            return true;
          } else {
            var $comparer$$4$$8 = comparer$$4;
            var $k$$5$$9 = k$$5;
            comparer$$4 = $comparer$$4$$8;
            k$$5 = $k$$5$$9;
            t$$5 = r$$6;
            continue SetTreeModule$$$mem;
          }
        }
    }

    break;
  }
}
function SetTreeModule$$$iter($arg$$10, $arg$$11) {
  SetTreeModule$$$iter: while (true) {
    var f = $arg$$10,
        t$$6 = $arg$$11;

    switch (t$$6.tag) {
      case 2:
        {
          var k2$$11 = t$$6.fields[0];
          f(k2$$11);
          break;
        }

      case 0:
        {
          break;
        }

      default:
        {
          var r$$7 = t$$6.fields[2];
          var l$$7 = t$$6.fields[1];
          var k2$$10 = t$$6.fields[0];
          SetTreeModule$$$iter(f, l$$7);
          f(k2$$10);
          $arg$$10 = f;
          $arg$$11 = r$$7;
          continue SetTreeModule$$$iter;
        }
    }

    break;
  }
}
function SetTreeModule$$$foldBack($arg$$12, $arg$$13, $arg$$14) {
  SetTreeModule$$$foldBack: while (true) {
    var f$$1 = $arg$$12,
        m$$1 = $arg$$13,
        x$$1 = $arg$$14;

    switch (m$$1.tag) {
      case 2:
        {
          var k$$7 = m$$1.fields[0];
          return f$$1(k$$7, x$$1);
        }

      case 0:
        {
          return x$$1;
        }

      default:
        {
          var r$$8 = m$$1.fields[2];
          var l$$8 = m$$1.fields[1];
          var k$$6 = m$$1.fields[0];
          $arg$$12 = f$$1;
          $arg$$13 = l$$8;
          $arg$$14 = f$$1(k$$6, SetTreeModule$$$foldBack(f$$1, r$$8, x$$1));
          continue SetTreeModule$$$foldBack;
        }
    }

    break;
  }
}
function SetTreeModule$$$fold($arg$$15, $arg$$16, $arg$$17) {
  SetTreeModule$$$fold: while (true) {
    var f$$2 = $arg$$15,
        x$$2 = $arg$$16,
        m$$2 = $arg$$17;

    switch (m$$2.tag) {
      case 2:
        {
          var k$$9 = m$$2.fields[0];
          return f$$2(x$$2, k$$9);
        }

      case 0:
        {
          return x$$2;
        }

      default:
        {
          var r$$9 = m$$2.fields[2];
          var l$$9 = m$$2.fields[1];
          var k$$8 = m$$2.fields[0];
          var x$$3 = SetTreeModule$$$fold(f$$2, x$$2, l$$9);
          var x$$4 = f$$2(x$$3, k$$8);
          $arg$$15 = f$$2;
          $arg$$16 = x$$4;
          $arg$$17 = r$$9;
          continue SetTreeModule$$$fold;
        }
    }

    break;
  }
}
function SetTreeModule$$$forall($arg$$18, $arg$$19) {
  SetTreeModule$$$forall: while (true) {
    var f$$3 = $arg$$18,
        m$$3 = $arg$$19;

    switch (m$$3.tag) {
      case 2:
        {
          var k2$$13 = m$$3.fields[0];
          return f$$3(k2$$13);
        }

      case 0:
        {
          return true;
        }

      default:
        {
          var r$$10 = m$$3.fields[2];
          var l$$10 = m$$3.fields[1];
          var k2$$12 = m$$3.fields[0];

          if (f$$3(k2$$12) ? SetTreeModule$$$forall(f$$3, l$$10) : false) {
            $arg$$18 = f$$3;
            $arg$$19 = r$$10;
            continue SetTreeModule$$$forall;
          } else {
            return false;
          }
        }
    }

    break;
  }
}
function SetTreeModule$$$exists($arg$$20, $arg$$21) {
  SetTreeModule$$$exists: while (true) {
    var f$$4 = $arg$$20,
        m$$4 = $arg$$21;

    switch (m$$4.tag) {
      case 2:
        {
          var k2$$15 = m$$4.fields[0];
          return f$$4(k2$$15);
        }

      case 0:
        {
          return false;
        }

      default:
        {
          var r$$11 = m$$4.fields[2];
          var l$$11 = m$$4.fields[1];
          var k2$$14 = m$$4.fields[0];

          if (f$$4(k2$$14) ? true : SetTreeModule$$$exists(f$$4, l$$11)) {
            return true;
          } else {
            $arg$$20 = f$$4;
            $arg$$21 = r$$11;
            continue SetTreeModule$$$exists;
          }
        }
    }

    break;
  }
}
function SetTreeModule$$$isEmpty(m$$5) {
  if (m$$5.tag === 0) {
    return true;
  } else {
    return false;
  }
}
function SetTreeModule$$$subset(comparer$$5, a, b) {
  return SetTreeModule$$$forall(function (x$$5) {
    return SetTreeModule$$$mem(comparer$$5, x$$5, b);
  }, a);
}
function SetTreeModule$$$psubset(comparer$$6, a$$1, b$$1) {
  if (SetTreeModule$$$forall(function (x$$6) {
    return SetTreeModule$$$mem(comparer$$6, x$$6, b$$1);
  }, a$$1)) {
    return SetTreeModule$$$exists(function (x$$7) {
      return !SetTreeModule$$$mem(comparer$$6, x$$7, a$$1);
    }, b$$1);
  } else {
    return false;
  }
}
function SetTreeModule$$$filterAux($arg$$22, $arg$$23, $arg$$24, $arg$$25) {
  SetTreeModule$$$filterAux: while (true) {
    var comparer$$7 = $arg$$22,
        f$$5 = $arg$$23,
        s$$2 = $arg$$24,
        acc$$1 = $arg$$25;

    switch (s$$2.tag) {
      case 2:
        {
          var k$$11 = s$$2.fields[0];

          if (f$$5(k$$11)) {
            return SetTreeModule$$$add(comparer$$7, k$$11, acc$$1);
          } else {
            return acc$$1;
          }
        }

      case 0:
        {
          return acc$$1;
        }

      default:
        {
          var r$$12 = s$$2.fields[2];
          var l$$12 = s$$2.fields[1];
          var k$$10 = s$$2.fields[0];
          var acc$$2 = f$$5(k$$10) ? SetTreeModule$$$add(comparer$$7, k$$10, acc$$1) : acc$$1;
          $arg$$22 = comparer$$7;
          $arg$$23 = f$$5;
          $arg$$24 = l$$12;
          $arg$$25 = SetTreeModule$$$filterAux(comparer$$7, f$$5, r$$12, acc$$2);
          continue SetTreeModule$$$filterAux;
        }
    }

    break;
  }
}
function SetTreeModule$$$filter(comparer$$8, f$$6, s$$3) {
  return SetTreeModule$$$filterAux(comparer$$8, f$$6, s$$3, new SetTree$00601(0, "SetEmpty"));
}
function SetTreeModule$$$diffAux(comparer$$9, m$$6, acc$$3) {
  SetTreeModule$$$diffAux: while (true) {
    switch (m$$6.tag) {
      case 2:
        {
          var k$$13 = m$$6.fields[0];
          return SetTreeModule$$$remove(comparer$$9, k$$13, acc$$3);
        }

      case 0:
        {
          return acc$$3;
        }

      default:
        {
          var r$$13 = m$$6.fields[2];
          var l$$13 = m$$6.fields[1];
          var k$$12 = m$$6.fields[0];
          var $acc$$3$$30 = acc$$3;
          var $comparer$$9$$29 = comparer$$9;
          comparer$$9 = $comparer$$9$$29;
          m$$6 = l$$13;
          acc$$3 = SetTreeModule$$$diffAux($comparer$$9$$29, r$$13, SetTreeModule$$$remove($comparer$$9$$29, k$$12, $acc$$3$$30));
          continue SetTreeModule$$$diffAux;
        }
    }

    break;
  }
}
function SetTreeModule$$$diff(comparer$$10, a$$2, b$$2) {
  return SetTreeModule$$$diffAux(comparer$$10, b$$2, a$$2);
}
function SetTreeModule$$$union(comparer$$11, t1$$4, t2$$4) {
  var matchValue$$3 = [t1$$4, t2$$4];
  var $target$$31, h1$$1, h2$$1, k1$$4, k2$$16, t11$$2, t12$$2, t21$$1, t22$$1, t$$7, t$$8, k1$$5, t2$$5, k2$$17, t1$$5;

  if (matchValue$$3[0].tag === 0) {
    $target$$31 = 1;
    t$$7 = matchValue$$3[1];
  } else if (matchValue$$3[0].tag === 2) {
    if (matchValue$$3[1].tag === 0) {
      $target$$31 = 2;
      t$$8 = matchValue$$3[0];
    } else if (matchValue$$3[1].tag === 2) {
      $target$$31 = 3;
      k1$$5 = matchValue$$3[0].fields[0];
      t2$$5 = matchValue$$3[1];
    } else {
      $target$$31 = 3;
      k1$$5 = matchValue$$3[0].fields[0];
      t2$$5 = matchValue$$3[1];
    }
  } else if (matchValue$$3[1].tag === 0) {
    $target$$31 = 2;
    t$$8 = matchValue$$3[0];
  } else if (matchValue$$3[1].tag === 2) {
    $target$$31 = 4;
    k2$$17 = matchValue$$3[1].fields[0];
    t1$$5 = matchValue$$3[0];
  } else {
    $target$$31 = 0;
    h1$$1 = matchValue$$3[0].fields[3];
    h2$$1 = matchValue$$3[1].fields[3];
    k1$$4 = matchValue$$3[0].fields[0];
    k2$$16 = matchValue$$3[1].fields[0];
    t11$$2 = matchValue$$3[0].fields[1];
    t12$$2 = matchValue$$3[0].fields[2];
    t21$$1 = matchValue$$3[1].fields[1];
    t22$$1 = matchValue$$3[1].fields[2];
  }

  switch ($target$$31) {
    case 0:
      {
        if (h1$$1 > h2$$1) {
          var patternInput$$4 = SetTreeModule$$$split(comparer$$11, k1$$4, t2$$4);
          return SetTreeModule$$$balance(comparer$$11, SetTreeModule$$$union(comparer$$11, t11$$2, patternInput$$4[0]), k1$$4, SetTreeModule$$$union(comparer$$11, t12$$2, patternInput$$4[2]));
        } else {
          var patternInput$$5 = SetTreeModule$$$split(comparer$$11, k2$$16, t1$$4);
          return SetTreeModule$$$balance(comparer$$11, SetTreeModule$$$union(comparer$$11, t21$$1, patternInput$$5[0]), k2$$16, SetTreeModule$$$union(comparer$$11, t22$$1, patternInput$$5[2]));
        }
      }

    case 1:
      {
        return t$$7;
      }

    case 2:
      {
        return t$$8;
      }

    case 3:
      {
        return SetTreeModule$$$add(comparer$$11, k1$$5, t2$$5);
      }

    case 4:
      {
        return SetTreeModule$$$add(comparer$$11, k2$$17, t1$$5);
      }
  }
}
function SetTreeModule$$$intersectionAux(comparer$$12, b$$3, m$$7, acc$$4) {
  SetTreeModule$$$intersectionAux: while (true) {
    switch (m$$7.tag) {
      case 2:
        {
          var k$$15 = m$$7.fields[0];

          if (SetTreeModule$$$mem(comparer$$12, k$$15, b$$3)) {
            return SetTreeModule$$$add(comparer$$12, k$$15, acc$$4);
          } else {
            return acc$$4;
          }
        }

      case 0:
        {
          return acc$$4;
        }

      default:
        {
          var r$$14 = m$$7.fields[2];
          var l$$14 = m$$7.fields[1];
          var k$$14 = m$$7.fields[0];
          var acc$$5 = SetTreeModule$$$intersectionAux(comparer$$12, b$$3, r$$14, acc$$4);
          var acc$$6 = SetTreeModule$$$mem(comparer$$12, k$$14, b$$3) ? SetTreeModule$$$add(comparer$$12, k$$14, acc$$5) : acc$$5;
          var $b$$3$$33 = b$$3;
          var $comparer$$12$$32 = comparer$$12;
          comparer$$12 = $comparer$$12$$32;
          b$$3 = $b$$3$$33;
          m$$7 = l$$14;
          acc$$4 = acc$$6;
          continue SetTreeModule$$$intersectionAux;
        }
    }

    break;
  }
}
function SetTreeModule$$$intersection(comparer$$13, a$$3, b$$4) {
  return SetTreeModule$$$intersectionAux(comparer$$13, b$$4, a$$3, new SetTree$00601(0, "SetEmpty"));
}
function SetTreeModule$$$partition1(comparer$$14, f$$7, k$$16, acc1, acc2) {
  if (f$$7(k$$16)) {
    return [SetTreeModule$$$add(comparer$$14, k$$16, acc1), acc2];
  } else {
    return [acc1, SetTreeModule$$$add(comparer$$14, k$$16, acc2)];
  }
}
function SetTreeModule$$$partitionAux($arg$$39, $arg$$40, $arg$$41, $arg$$42, $arg$$43) {
  SetTreeModule$$$partitionAux: while (true) {
    var comparer$$15 = $arg$$39,
        f$$8 = $arg$$40,
        s$$4 = $arg$$41,
        acc_0 = $arg$$42,
        acc_1 = $arg$$43;
    var acc$$7 = [acc_0, acc_1];

    switch (s$$4.tag) {
      case 2:
        {
          var k$$18 = s$$4.fields[0];
          return SetTreeModule$$$partition1(comparer$$15, f$$8, k$$18, acc$$7[0], acc$$7[1]);
        }

      case 0:
        {
          return acc$$7;
        }

      default:
        {
          var r$$15 = s$$4.fields[2];
          var l$$15 = s$$4.fields[1];
          var k$$17 = s$$4.fields[0];
          var acc$$8 = SetTreeModule$$$partitionAux(comparer$$15, f$$8, r$$15, acc$$7[0], acc$$7[1]);
          var acc$$9 = SetTreeModule$$$partition1(comparer$$15, f$$8, k$$17, acc$$8[0], acc$$8[1]);
          $arg$$39 = comparer$$15;
          $arg$$40 = f$$8;
          $arg$$41 = l$$15;
          $arg$$42 = acc$$9[0];
          $arg$$43 = acc$$9[1];
          continue SetTreeModule$$$partitionAux;
        }
    }

    break;
  }
}
function SetTreeModule$$$partition(comparer$$16, f$$9, s$$5) {
  var seed = [new SetTree$00601(0, "SetEmpty"), new SetTree$00601(0, "SetEmpty")];
  return SetTreeModule$$$partitionAux(comparer$$16, f$$9, s$$5, seed[0], seed[1]);
}
function SetTreeModule$$$$007CMatchSetNode$007CMatchSetEmpty$007C(s$$6) {
  switch (s$$6.tag) {
    case 2:
      {
        var k2$$19 = s$$6.fields[0];
        return new __WEBPACK_IMPORTED_MODULE_4__Option__["a" /* Choice */](0, "Choice1Of2", [k2$$19, new SetTree$00601(0, "SetEmpty"), new SetTree$00601(0, "SetEmpty")]);
      }

    case 0:
      {
        return new __WEBPACK_IMPORTED_MODULE_4__Option__["a" /* Choice */](1, "Choice2Of2", null);
      }

    default:
      {
        var r$$16 = s$$6.fields[2];
        var l$$16 = s$$6.fields[1];
        var k2$$18 = s$$6.fields[0];
        return new __WEBPACK_IMPORTED_MODULE_4__Option__["a" /* Choice */](0, "Choice1Of2", [k2$$18, l$$16, r$$16]);
      }
  }
}
function SetTreeModule$$$minimumElementAux(s$$7, n$$1) {
  SetTreeModule$$$minimumElementAux: while (true) {
    switch (s$$7.tag) {
      case 2:
        {
          var k$$20 = s$$7.fields[0];
          return k$$20;
        }

      case 0:
        {
          return n$$1;
        }

      default:
        {
          var l$$17 = s$$7.fields[1];
          var k$$19 = s$$7.fields[0];
          s$$7 = l$$17;
          n$$1 = k$$19;
          continue SetTreeModule$$$minimumElementAux;
        }
    }

    break;
  }
}
function SetTreeModule$$$minimumElementOpt(s$$8) {
  switch (s$$8.tag) {
    case 2:
      {
        var k$$22 = s$$8.fields[0];
        return Object(__WEBPACK_IMPORTED_MODULE_4__Option__["c" /* some */])(k$$22);
      }

    case 0:
      {
        return null;
      }

    default:
      {
        var l$$18 = s$$8.fields[1];
        var k$$21 = s$$8.fields[0];
        return Object(__WEBPACK_IMPORTED_MODULE_4__Option__["c" /* some */])(SetTreeModule$$$minimumElementAux(l$$18, k$$21));
      }
  }
}
function SetTreeModule$$$maximumElementAux(s$$9, n$$2) {
  SetTreeModule$$$maximumElementAux: while (true) {
    switch (s$$9.tag) {
      case 2:
        {
          var k$$24 = s$$9.fields[0];
          return k$$24;
        }

      case 0:
        {
          return n$$2;
        }

      default:
        {
          var r$$17 = s$$9.fields[2];
          var k$$23 = s$$9.fields[0];
          s$$9 = r$$17;
          n$$2 = k$$23;
          continue SetTreeModule$$$maximumElementAux;
        }
    }

    break;
  }
}
function SetTreeModule$$$maximumElementOpt(s$$10) {
  switch (s$$10.tag) {
    case 2:
      {
        var k$$26 = s$$10.fields[0];
        return Object(__WEBPACK_IMPORTED_MODULE_4__Option__["c" /* some */])(k$$26);
      }

    case 0:
      {
        return null;
      }

    default:
      {
        var r$$18 = s$$10.fields[2];
        var k$$25 = s$$10.fields[0];
        return Object(__WEBPACK_IMPORTED_MODULE_4__Option__["c" /* some */])(SetTreeModule$$$maximumElementAux(r$$18, k$$25));
      }
  }
}
function SetTreeModule$$$minimumElement(s$$11) {
  var matchValue$$4 = SetTreeModule$$$minimumElementOpt(s$$11);

  if (matchValue$$4 == null) {
    throw new Error("Set contains no elements");
  } else {
    var k$$27 = Object(__WEBPACK_IMPORTED_MODULE_4__Option__["d" /* value */])(matchValue$$4);
    return k$$27;
  }
}
function SetTreeModule$$$maximumElement(s$$12) {
  var matchValue$$5 = SetTreeModule$$$maximumElementOpt(s$$12);

  if (matchValue$$5 == null) {
    throw new Error("Set contains no elements");
  } else {
    var k$$28 = Object(__WEBPACK_IMPORTED_MODULE_4__Option__["d" /* value */])(matchValue$$5);
    return k$$28;
  }
}
var SetTreeModule$002ESetIterator$00601 = Object(__WEBPACK_IMPORTED_MODULE_3__Types__["e" /* declare */])(function SetTreeModule$002ESetIterator$00601(arg1, arg2) {
  this.stack = arg1;
  this.started = arg2;
}, __WEBPACK_IMPORTED_MODULE_3__Types__["c" /* Record */]);
function SetTreeModule$$$collapseLHS(stack) {
  SetTreeModule$$$collapseLHS: while (true) {
    if (stack.tail != null) {
      if (stack.head.tag === 2) {
        return stack;
      } else if (stack.head.tag === 1) {
        var $stack$$47 = stack;
        stack = new __WEBPACK_IMPORTED_MODULE_3__Types__["b" /* List */]($stack$$47.head.fields[1], new __WEBPACK_IMPORTED_MODULE_3__Types__["b" /* List */](SetTreeModule$$$SetOne($stack$$47.head.fields[0]), new __WEBPACK_IMPORTED_MODULE_3__Types__["b" /* List */]($stack$$47.head.fields[2], $stack$$47.tail)));
        continue SetTreeModule$$$collapseLHS;
      } else {
        var $stack$$48 = stack;
        stack = $stack$$48.tail;
        continue SetTreeModule$$$collapseLHS;
      }
    } else {
      return new __WEBPACK_IMPORTED_MODULE_3__Types__["b" /* List */]();
    }

    break;
  }
}
function SetTreeModule$$$mkIterator(s$$13) {
  return new SetTreeModule$002ESetIterator$00601(SetTreeModule$$$collapseLHS(new __WEBPACK_IMPORTED_MODULE_3__Types__["b" /* List */](s$$13, new __WEBPACK_IMPORTED_MODULE_3__Types__["b" /* List */]())), false);
}
function SetTreeModule$$$notStarted() {
  throw new Error("Enumeration not started");
}
function SetTreeModule$$$alreadyFinished() {
  throw new Error("Enumeration already started");
}
function SetTreeModule$$$current(i) {
  if (i.started) {
    var matchValue$$6 = i.stack;

    if (matchValue$$6.tail == null) {
      return SetTreeModule$$$alreadyFinished();
    } else if (matchValue$$6.head.tag === 2) {
      return matchValue$$6.head.fields[0];
    } else {
      throw new Error("Please report error: Set iterator, unexpected stack for current");
    }
  } else {
    return SetTreeModule$$$notStarted();
  }
}
function SetTreeModule$$$moveNext(i$$1) {
  if (i$$1.started) {
    var matchValue$$7 = i$$1.stack;

    if (matchValue$$7.tail == null) {
      return false;
    } else if (matchValue$$7.head.tag === 2) {
      i$$1.stack = SetTreeModule$$$collapseLHS(matchValue$$7.tail);
      return !(i$$1.stack.tail == null);
    } else {
      throw new Error("Please report error: Set iterator, unexpected stack for moveNext");
    }
  } else {
    i$$1.started = true;
    return !(i$$1.stack.tail == null);
  }
}
var SetTreeModule$002EmkIEnumerator$00601 = Object(__WEBPACK_IMPORTED_MODULE_3__Types__["e" /* declare */])(function SetTreeModule$002EmkIEnumerator$00601(s$$14) {
  var $this$$1 = this;
  $this$$1.s = s$$14;
  $this$$1.i = SetTreeModule$$$mkIterator($this$$1.s);
});
function SetTreeModule$002EmkIEnumerator$00601$$$$002Ector$$Z5B395D56(s$$14) {
  return this != null ? SetTreeModule$002EmkIEnumerator$00601.call(this, s$$14) : new SetTreeModule$002EmkIEnumerator$00601(s$$14);
}
Object.defineProperty(SetTreeModule$002EmkIEnumerator$00601.prototype, "Current", {
  "get": function get() {
    var __ = this;
    return SetTreeModule$$$current(__.i);
  }
});

SetTreeModule$002EmkIEnumerator$00601.prototype.MoveNext = function () {
  var __$$1 = this;
  return SetTreeModule$$$moveNext(__$$1.i);
};

SetTreeModule$002EmkIEnumerator$00601.prototype.Reset = function () {
  var __$$2 = this;
  __$$2.i = SetTreeModule$$$mkIterator(__$$2.s);
};

SetTreeModule$002EmkIEnumerator$00601.prototype.Dispose = function () {};

function SetTreeModule$$$mkIEnumerator(s$$15) {
  return SetTreeModule$002EmkIEnumerator$00601$$$$002Ector$$Z5B395D56(s$$15);
}
function SetTreeModule$$$toSeq(s$$16) {
  var en = SetTreeModule$$$mkIEnumerator(s$$16);
  return Object(__WEBPACK_IMPORTED_MODULE_5__Seq__["m" /* unfold */])(function generator(en$$1) {
    if (en$$1.MoveNext()) {
      return [en$$1.Current, en$$1];
    } else {
      return null;
    }
  }, en);
}
function SetTreeModule$$$compareStacks(comparer$$17, l1, l2) {
  SetTreeModule$$$compareStacks: while (true) {
    var matchValue$$8 = [l1, l2];
    var $target$$49, t1$$6, t2$$6, n1k, n2k, t1$$7, t2$$7, n1k$$1, n2k$$1, n2r, t1$$8, t2$$8, emp, n1k$$2, n1r, n2k$$2, t1$$9, t2$$9, n1k$$3, n1r$$1, n2k$$3, n2r$$1, t1$$10, t2$$10, n1k$$4, t1$$11, n1k$$5, n1l, n1r$$2, t1$$12, n2k$$4, t2$$11, n2k$$5, n2l, n2r$$2, t2$$12;

    if (matchValue$$8[0].tail != null) {
      if (matchValue$$8[1].tail != null) {
        if (matchValue$$8[1].head.tag === 2) {
          if (matchValue$$8[0].head.tag === 2) {
            $target$$49 = 4;
            n1k = matchValue$$8[0].head.fields[0];
            n2k = matchValue$$8[1].head.fields[0];
            t1$$7 = matchValue$$8[0].tail;
            t2$$7 = matchValue$$8[1].tail;
          } else if (matchValue$$8[0].head.tag === 1) {
            if (matchValue$$8[0].head.fields[1].tag === 0) {
              $target$$49 = 6;
              emp = matchValue$$8[0].head.fields[1];
              n1k$$2 = matchValue$$8[0].head.fields[0];
              n1r = matchValue$$8[0].head.fields[2];
              n2k$$2 = matchValue$$8[1].head.fields[0];
              t1$$9 = matchValue$$8[0].tail;
              t2$$9 = matchValue$$8[1].tail;
            } else {
              $target$$49 = 9;
              n1k$$5 = matchValue$$8[0].head.fields[0];
              n1l = matchValue$$8[0].head.fields[1];
              n1r$$2 = matchValue$$8[0].head.fields[2];
              t1$$12 = matchValue$$8[0].tail;
            }
          } else {
            $target$$49 = 10;
            n2k$$4 = matchValue$$8[1].head.fields[0];
            t2$$11 = matchValue$$8[1].tail;
          }
        } else if (matchValue$$8[1].head.tag === 1) {
          if (matchValue$$8[1].head.fields[1].tag === 0) {
            if (matchValue$$8[0].head.tag === 2) {
              $target$$49 = 5;
              n1k$$1 = matchValue$$8[0].head.fields[0];
              n2k$$1 = matchValue$$8[1].head.fields[0];
              n2r = matchValue$$8[1].head.fields[2];
              t1$$8 = matchValue$$8[0].tail;
              t2$$8 = matchValue$$8[1].tail;
            } else if (matchValue$$8[0].head.tag === 1) {
              if (matchValue$$8[0].head.fields[1].tag === 0) {
                $target$$49 = 7;
                n1k$$3 = matchValue$$8[0].head.fields[0];
                n1r$$1 = matchValue$$8[0].head.fields[2];
                n2k$$3 = matchValue$$8[1].head.fields[0];
                n2r$$1 = matchValue$$8[1].head.fields[2];
                t1$$10 = matchValue$$8[0].tail;
                t2$$10 = matchValue$$8[1].tail;
              } else {
                $target$$49 = 9;
                n1k$$5 = matchValue$$8[0].head.fields[0];
                n1l = matchValue$$8[0].head.fields[1];
                n1r$$2 = matchValue$$8[0].head.fields[2];
                t1$$12 = matchValue$$8[0].tail;
              }
            } else {
              $target$$49 = 11;
              n2k$$5 = matchValue$$8[1].head.fields[0];
              n2l = matchValue$$8[1].head.fields[1];
              n2r$$2 = matchValue$$8[1].head.fields[2];
              t2$$12 = matchValue$$8[1].tail;
            }
          } else if (matchValue$$8[0].head.tag === 2) {
            $target$$49 = 8;
            n1k$$4 = matchValue$$8[0].head.fields[0];
            t1$$11 = matchValue$$8[0].tail;
          } else if (matchValue$$8[0].head.tag === 1) {
            $target$$49 = 9;
            n1k$$5 = matchValue$$8[0].head.fields[0];
            n1l = matchValue$$8[0].head.fields[1];
            n1r$$2 = matchValue$$8[0].head.fields[2];
            t1$$12 = matchValue$$8[0].tail;
          } else {
            $target$$49 = 11;
            n2k$$5 = matchValue$$8[1].head.fields[0];
            n2l = matchValue$$8[1].head.fields[1];
            n2r$$2 = matchValue$$8[1].head.fields[2];
            t2$$12 = matchValue$$8[1].tail;
          }
        } else if (matchValue$$8[0].head.tag === 2) {
          $target$$49 = 8;
          n1k$$4 = matchValue$$8[0].head.fields[0];
          t1$$11 = matchValue$$8[0].tail;
        } else if (matchValue$$8[0].head.tag === 1) {
          $target$$49 = 9;
          n1k$$5 = matchValue$$8[0].head.fields[0];
          n1l = matchValue$$8[0].head.fields[1];
          n1r$$2 = matchValue$$8[0].head.fields[2];
          t1$$12 = matchValue$$8[0].tail;
        } else {
          $target$$49 = 3;
          t1$$6 = matchValue$$8[0].tail;
          t2$$6 = matchValue$$8[1].tail;
        }
      } else {
        $target$$49 = 2;
      }
    } else if (matchValue$$8[1].tail != null) {
      $target$$49 = 1;
    } else {
      $target$$49 = 0;
    }

    switch ($target$$49) {
      case 0:
        {
          return 0;
        }

      case 1:
        {
          return -1 | 0;
        }

      case 2:
        {
          return 1;
        }

      case 3:
        {
          var $comparer$$17$$50 = comparer$$17;
          comparer$$17 = $comparer$$17$$50;
          l1 = t1$$6;
          l2 = t2$$6;
          continue SetTreeModule$$$compareStacks;
        }

      case 4:
        {
          var c$$7 = comparer$$17.Compare(n1k, n2k) | 0;

          if (c$$7 !== 0) {
            return c$$7 | 0;
          } else {
            var $comparer$$17$$51 = comparer$$17;
            comparer$$17 = $comparer$$17$$51;
            l1 = t1$$7;
            l2 = t2$$7;
            continue SetTreeModule$$$compareStacks;
          }
        }

      case 5:
        {
          var c$$8 = comparer$$17.Compare(n1k$$1, n2k$$1) | 0;

          if (c$$8 !== 0) {
            return c$$8 | 0;
          } else {
            var $comparer$$17$$52 = comparer$$17;
            comparer$$17 = $comparer$$17$$52;
            l1 = new __WEBPACK_IMPORTED_MODULE_3__Types__["b" /* List */](new SetTree$00601(0, "SetEmpty"), t1$$8);
            l2 = new __WEBPACK_IMPORTED_MODULE_3__Types__["b" /* List */](n2r, t2$$8);
            continue SetTreeModule$$$compareStacks;
          }
        }

      case 6:
        {
          var c$$9 = comparer$$17.Compare(n1k$$2, n2k$$2) | 0;

          if (c$$9 !== 0) {
            return c$$9 | 0;
          } else {
            var $comparer$$17$$53 = comparer$$17;
            comparer$$17 = $comparer$$17$$53;
            l1 = new __WEBPACK_IMPORTED_MODULE_3__Types__["b" /* List */](n1r, t1$$9);
            l2 = new __WEBPACK_IMPORTED_MODULE_3__Types__["b" /* List */](emp, t2$$9);
            continue SetTreeModule$$$compareStacks;
          }
        }

      case 7:
        {
          var c$$10 = comparer$$17.Compare(n1k$$3, n2k$$3) | 0;

          if (c$$10 !== 0) {
            return c$$10 | 0;
          } else {
            var $comparer$$17$$54 = comparer$$17;
            comparer$$17 = $comparer$$17$$54;
            l1 = new __WEBPACK_IMPORTED_MODULE_3__Types__["b" /* List */](n1r$$1, t1$$10);
            l2 = new __WEBPACK_IMPORTED_MODULE_3__Types__["b" /* List */](n2r$$1, t2$$10);
            continue SetTreeModule$$$compareStacks;
          }
        }

      case 8:
        {
          var $comparer$$17$$55 = comparer$$17;
          var $l2$$56 = l2;
          comparer$$17 = $comparer$$17$$55;
          l1 = new __WEBPACK_IMPORTED_MODULE_3__Types__["b" /* List */](new SetTree$00601(0, "SetEmpty"), new __WEBPACK_IMPORTED_MODULE_3__Types__["b" /* List */](SetTreeModule$$$SetOne(n1k$$4), t1$$11));
          l2 = $l2$$56;
          continue SetTreeModule$$$compareStacks;
        }

      case 9:
        {
          var $comparer$$17$$57 = comparer$$17;
          var $l2$$58 = l2;
          comparer$$17 = $comparer$$17$$57;
          l1 = new __WEBPACK_IMPORTED_MODULE_3__Types__["b" /* List */](n1l, new __WEBPACK_IMPORTED_MODULE_3__Types__["b" /* List */](SetTreeModule$$$SetNode(n1k$$5, new SetTree$00601(0, "SetEmpty"), n1r$$2, 0), t1$$12));
          l2 = $l2$$58;
          continue SetTreeModule$$$compareStacks;
        }

      case 10:
        {
          var $comparer$$17$$59 = comparer$$17;
          var $l1$$60 = l1;
          comparer$$17 = $comparer$$17$$59;
          l1 = $l1$$60;
          l2 = new __WEBPACK_IMPORTED_MODULE_3__Types__["b" /* List */](new SetTree$00601(0, "SetEmpty"), new __WEBPACK_IMPORTED_MODULE_3__Types__["b" /* List */](SetTreeModule$$$SetOne(n2k$$4), t2$$11));
          continue SetTreeModule$$$compareStacks;
        }

      case 11:
        {
          var $comparer$$17$$61 = comparer$$17;
          var $l1$$62 = l1;
          comparer$$17 = $comparer$$17$$61;
          l1 = $l1$$62;
          l2 = new __WEBPACK_IMPORTED_MODULE_3__Types__["b" /* List */](n2l, new __WEBPACK_IMPORTED_MODULE_3__Types__["b" /* List */](SetTreeModule$$$SetNode(n2k$$5, new SetTree$00601(0, "SetEmpty"), n2r$$2, 0), t2$$12));
          continue SetTreeModule$$$compareStacks;
        }
    }

    break;
  }
}
function SetTreeModule$$$compare(comparer$$18, s1, s2) {
  var matchValue$$9 = [s1, s2];

  if (matchValue$$9[0].tag === 0) {
    if (matchValue$$9[1].tag === 0) {
      return 0;
    } else {
      return -1 | 0;
    }
  } else if (matchValue$$9[1].tag === 0) {
    return 1;
  } else {
    return SetTreeModule$$$compareStacks(comparer$$18, new __WEBPACK_IMPORTED_MODULE_3__Types__["b" /* List */](s1, new __WEBPACK_IMPORTED_MODULE_3__Types__["b" /* List */]()), new __WEBPACK_IMPORTED_MODULE_3__Types__["b" /* List */](s2, new __WEBPACK_IMPORTED_MODULE_3__Types__["b" /* List */]())) | 0;
  }
}
function SetTreeModule$$$choose(s$$17) {
  return SetTreeModule$$$minimumElement(s$$17);
}
function SetTreeModule$$$loop(m$$8, acc$$10) {
  SetTreeModule$$$loop: while (true) {
    switch (m$$8.tag) {
      case 2:
        {
          var k$$32 = m$$8.fields[0];
          return new __WEBPACK_IMPORTED_MODULE_3__Types__["b" /* List */](k$$32, acc$$10);
        }

      case 0:
        {
          return acc$$10;
        }

      default:
        {
          var r$$20 = m$$8.fields[2];
          var l$$20 = m$$8.fields[1];
          var k$$31 = m$$8.fields[0];
          var $acc$$10$$63 = acc$$10;
          m$$8 = l$$20;
          acc$$10 = new __WEBPACK_IMPORTED_MODULE_3__Types__["b" /* List */](k$$31, SetTreeModule$$$loop(r$$20, $acc$$10$$63));
          continue SetTreeModule$$$loop;
        }
    }

    break;
  }
}
function SetTreeModule$$$toList(s$$18) {
  return SetTreeModule$$$loop(s$$18, new __WEBPACK_IMPORTED_MODULE_3__Types__["b" /* List */]());
}
function SetTreeModule$$$copyToArray(s$$19, arr, i$$2) {
  var j = i$$2 | 0;
  SetTreeModule$$$iter(function (x$$8) {
    arr[j] = x$$8;
    j = j + 1;
  }, s$$19);
}
function SetTreeModule$$$mkFromEnumerator(comparer$$19, acc$$11, e) {
  SetTreeModule$$$mkFromEnumerator: while (true) {
    if (e.MoveNext()) {
      var $acc$$11$$65 = acc$$11;
      var $comparer$$19$$64 = comparer$$19;
      var $e$$66 = e;
      comparer$$19 = $comparer$$19$$64;
      acc$$11 = SetTreeModule$$$add($comparer$$19$$64, $e$$66.Current, $acc$$11$$65);
      e = $e$$66;
      continue SetTreeModule$$$mkFromEnumerator;
    } else {
      return acc$$11;
    }

    break;
  }
}
function SetTreeModule$$$ofSeq(comparer$$20, c$$11) {
  var ie = Object(__WEBPACK_IMPORTED_MODULE_5__Seq__["f" /* getEnumerator */])(c$$11);

  try {
    return SetTreeModule$$$mkFromEnumerator(comparer$$20, new SetTree$00601(0, "SetEmpty"), ie);
  } finally {
    if (Object(__WEBPACK_IMPORTED_MODULE_6__Util__["m" /* isDisposable */])(ie)) {
      ie.Dispose();
    }
  }
}
function SetTreeModule$$$ofArray(comparer$$21, arr$$1) {
  var acc$$12 = new SetTree$00601(0, "SetEmpty");

  for (var i$$3 = 0; i$$3 <= arr$$1.length - 1; i$$3++) {
    acc$$12 = SetTreeModule$$$add(comparer$$21, arr$$1[i$$3], acc$$12);
  }

  return acc$$12;
}
var FSharpSet = Object(__WEBPACK_IMPORTED_MODULE_3__Types__["e" /* declare */])(function FSharpSet(comparer$$22, tree) {
  var $this$$2 = this;
  $this$$2.comparer = comparer$$22;
  $this$$2.tree = tree;
});
function FSharpSet$$$$002Ector$$2528C5CB(comparer$$22, tree) {
  return this != null ? FSharpSet.call(this, comparer$$22, tree) : new FSharpSet(comparer$$22, tree);
}
function FSharpSet$$get_Comparer(__$$4) {
  return __$$4.comparer;
}
function FSharpSet$$get_Tree(__$$5) {
  return __$$5.tree;
}
function FSharpSet$$Add$$2B595(s$$20, x$$9) {
  return FSharpSet$$$$002Ector$$2528C5CB(FSharpSet$$get_Comparer(s$$20), SetTreeModule$$$add(FSharpSet$$get_Comparer(s$$20), x$$9, FSharpSet$$get_Tree(s$$20)));
}
function FSharpSet$$Remove$$2B595(s$$21, x$$10) {
  return FSharpSet$$$$002Ector$$2528C5CB(FSharpSet$$get_Comparer(s$$21), SetTreeModule$$$remove(FSharpSet$$get_Comparer(s$$21), x$$10, FSharpSet$$get_Tree(s$$21)));
}
function FSharpSet$$get_Count(s$$22) {
  return SetTreeModule$$$count(FSharpSet$$get_Tree(s$$22));
}
function FSharpSet$$Contains$$2B595(s$$23, x$$11) {
  return SetTreeModule$$$mem(FSharpSet$$get_Comparer(s$$23), x$$11, FSharpSet$$get_Tree(s$$23));
}
function FSharpSet$$Iterate$$5028453F(s$$24, x$$12) {
  SetTreeModule$$$iter(x$$12, FSharpSet$$get_Tree(s$$24));
}
function FSharpSet$$Fold(s$$25, f$$10, z) {
  return SetTreeModule$$$fold(function (x$$13, z$$1) {
    return f$$10(z$$1, x$$13);
  }, z, FSharpSet$$get_Tree(s$$25));
}
function FSharpSet$$get_IsEmpty(s$$26) {
  return SetTreeModule$$$isEmpty(FSharpSet$$get_Tree(s$$26));
}
function FSharpSet$$Partition$$Z1D55A0D7(s$$27, f$$11) {
  if (FSharpSet$$get_Tree(s$$27).tag === 0) {
    return [s$$27, s$$27];
  } else {
    var patternInput$$6 = SetTreeModule$$$partition(FSharpSet$$get_Comparer(s$$27), f$$11, FSharpSet$$get_Tree(s$$27));
    return [FSharpSet$$$$002Ector$$2528C5CB(FSharpSet$$get_Comparer(s$$27), patternInput$$6[0]), FSharpSet$$$$002Ector$$2528C5CB(FSharpSet$$get_Comparer(s$$27), patternInput$$6[1])];
  }
}
function FSharpSet$$Filter$$Z1D55A0D7(s$$28, f$$12) {
  if (FSharpSet$$get_Tree(s$$28).tag === 0) {
    return s$$28;
  } else {
    return FSharpSet$$$$002Ector$$2528C5CB(FSharpSet$$get_Comparer(s$$28), SetTreeModule$$$filter(FSharpSet$$get_Comparer(s$$28), f$$12, FSharpSet$$get_Tree(s$$28)));
  }
}
function FSharpSet$$Map$$38806891(s$$29, f$$13, comparer$$23) {
  return FSharpSet$$$$002Ector$$2528C5CB(comparer$$23, SetTreeModule$$$fold(function (acc$$13, k$$33) {
    return SetTreeModule$$$add(comparer$$23, f$$13(k$$33), acc$$13);
  }, new SetTree$00601(0, "SetEmpty"), FSharpSet$$get_Tree(s$$29)));
}
function FSharpSet$$Exists$$Z1D55A0D7(s$$30, f$$14) {
  return SetTreeModule$$$exists(f$$14, FSharpSet$$get_Tree(s$$30));
}
function FSharpSet$$ForAll$$Z1D55A0D7(s$$31, f$$15) {
  return SetTreeModule$$$forall(f$$15, FSharpSet$$get_Tree(s$$31));
}
function FSharpSet$$$op_Subtraction(a$$4, b$$5) {
  if (FSharpSet$$get_Tree(a$$4).tag === 0) {
    return a$$4;
  } else if (FSharpSet$$get_Tree(b$$5).tag === 0) {
    return a$$4;
  } else {
    return FSharpSet$$$$002Ector$$2528C5CB(FSharpSet$$get_Comparer(a$$4), SetTreeModule$$$diff(FSharpSet$$get_Comparer(a$$4), FSharpSet$$get_Tree(a$$4), FSharpSet$$get_Tree(b$$5)));
  }
}
function FSharpSet$$$op_Addition(a$$5, b$$6) {
  if (FSharpSet$$get_Tree(b$$6).tag === 0) {
    return a$$5;
  } else if (FSharpSet$$get_Tree(a$$5).tag === 0) {
    return b$$6;
  } else {
    return FSharpSet$$$$002Ector$$2528C5CB(FSharpSet$$get_Comparer(a$$5), SetTreeModule$$$union(FSharpSet$$get_Comparer(a$$5), FSharpSet$$get_Tree(a$$5), FSharpSet$$get_Tree(b$$6)));
  }
}
function FSharpSet$$$Intersection$$Z3BE9BFE0(a$$6, b$$7) {
  if (FSharpSet$$get_Tree(b$$7).tag === 0) {
    return b$$7;
  } else if (FSharpSet$$get_Tree(a$$6).tag === 0) {
    return a$$6;
  } else {
    return FSharpSet$$$$002Ector$$2528C5CB(FSharpSet$$get_Comparer(a$$6), SetTreeModule$$$intersection(FSharpSet$$get_Comparer(a$$6), FSharpSet$$get_Tree(a$$6), FSharpSet$$get_Tree(b$$7)));
  }
}
function FSharpSet$$$IntersectionMany$$Z15B59630(sets) {
  return Object(__WEBPACK_IMPORTED_MODULE_5__Seq__["i" /* reduce */])(FSharpSet$$$Intersection$$Z3BE9BFE0, sets);
}
function FSharpSet$$$Equality$$Z3BE9BFE0(a$$7, b$$8) {
  return SetTreeModule$$$compare(FSharpSet$$get_Comparer(a$$7), FSharpSet$$get_Tree(a$$7), FSharpSet$$get_Tree(b$$8)) === 0;
}
function FSharpSet$$$Compare$$Z3BE9BFE0(a$$8, b$$9) {
  return SetTreeModule$$$compare(FSharpSet$$get_Comparer(a$$8), FSharpSet$$get_Tree(a$$8), FSharpSet$$get_Tree(b$$9));
}
function FSharpSet$$get_Choose(x$$14) {
  return SetTreeModule$$$choose(FSharpSet$$get_Tree(x$$14));
}
function FSharpSet$$get_MinimumElement(x$$15) {
  return SetTreeModule$$$minimumElement(FSharpSet$$get_Tree(x$$15));
}
function FSharpSet$$get_MaximumElement(x$$16) {
  return SetTreeModule$$$maximumElement(FSharpSet$$get_Tree(x$$16));
}
function FSharpSet$$IsSubsetOf$$6A20B1FF(x$$17, y) {
  return SetTreeModule$$$subset(FSharpSet$$get_Comparer(x$$17), FSharpSet$$get_Tree(x$$17), FSharpSet$$get_Tree(y));
}
function FSharpSet$$IsSupersetOf$$6A20B1FF(x$$18, y$$1) {
  return SetTreeModule$$$subset(FSharpSet$$get_Comparer(x$$18), FSharpSet$$get_Tree(y$$1), FSharpSet$$get_Tree(x$$18));
}
function FSharpSet$$IsProperSubsetOf$$6A20B1FF(x$$19, y$$2) {
  return SetTreeModule$$$psubset(FSharpSet$$get_Comparer(x$$19), FSharpSet$$get_Tree(x$$19), FSharpSet$$get_Tree(y$$2));
}
function FSharpSet$$IsProperSupersetOf$$6A20B1FF(x$$20, y$$3) {
  return SetTreeModule$$$psubset(FSharpSet$$get_Comparer(x$$20), FSharpSet$$get_Tree(y$$3), FSharpSet$$get_Tree(x$$20));
}

FSharpSet.prototype.toString = function () {
  var this$ = this;
  return "set [" + __WEBPACK_IMPORTED_MODULE_7__String__["a" /* join */].apply(undefined, ["; "].concat(__WEBPACK_IMPORTED_MODULE_2_babel_runtime_helpers_toConsumableArray___default()(Object(__WEBPACK_IMPORTED_MODULE_5__Seq__["h" /* map */])(String, this$)))) + "]";
};

FSharpSet.prototype.GetHashCode = function () {
  var this$$$1 = this;

  var combineHash = function combineHash(x$$22, y$$4) {
    return (x$$22 << 1) + y$$4 + 631;
  };

  var res = 0;
  var e$$1 = SetTreeModule$$$mkIEnumerator(FSharpSet$$get_Tree(this$$$1));

  while (e$$1.MoveNext()) {
    res = combineHash(res, Object(__WEBPACK_IMPORTED_MODULE_6__Util__["q" /* structuralHash */])(e$$1.Current));
  }

  return Math.abs(res) | 0;
};

FSharpSet.prototype.Equals = function (that) {
  var this$$$2 = this;
  return SetTreeModule$$$compare(FSharpSet$$get_Comparer(this$$$2), FSharpSet$$get_Tree(this$$$2), FSharpSet$$get_Tree(that)) === 0;
};

FSharpSet.prototype.CompareTo = function (that$$1) {
  var this$$$3 = this;
  return SetTreeModule$$$compare(FSharpSet$$get_Comparer(this$$$3), FSharpSet$$get_Tree(this$$$3), FSharpSet$$get_Tree(that$$1)) | 0;
};

FSharpSet.prototype[__WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_symbol_iterator___default.a] = function () {
  var s$$32 = this;
  return Object(__WEBPACK_IMPORTED_MODULE_5__Seq__["l" /* toIterator */])(SetTreeModule$$$mkIEnumerator(FSharpSet$$get_Tree(s$$32)));
};

function isEmpty(s$$33) {
  return FSharpSet$$get_IsEmpty(s$$33);
}
function contains(x$$23, s$$34) {
  return FSharpSet$$Contains$$2B595(s$$34, x$$23);
}
function add(x$$24, s$$35) {
  return FSharpSet$$Add$$2B595(s$$35, x$$24);
}
function singleton(x$$25, comparer$$24) {
  return FSharpSet$$$$002Ector$$2528C5CB(comparer$$24, new SetTree$00601(2, "SetOne", x$$25));
}
function remove(x$$26, s$$36) {
  return FSharpSet$$Remove$$2B595(s$$36, x$$26);
}
function union(s1$$2, s2$$2) {
  return FSharpSet$$$op_Addition(s1$$2, s2$$2);
}
function unionMany(sets$$1, comparer$$25) {
  return Object(__WEBPACK_IMPORTED_MODULE_5__Seq__["c" /* fold */])(FSharpSet$$$op_Addition, FSharpSet$$$$002Ector$$2528C5CB(comparer$$25, new SetTree$00601(0, "SetEmpty")), sets$$1);
}
function intersect(s1$$3, s2$$3) {
  return FSharpSet$$$Intersection$$Z3BE9BFE0(s1$$3, s2$$3);
}
function intersectMany(sets$$2) {
  return FSharpSet$$$IntersectionMany$$Z15B59630(sets$$2);
}
function iterate(f$$16, s$$37) {
  FSharpSet$$Iterate$$5028453F(s$$37, f$$16);
}
function empty(comparer$$26) {
  return FSharpSet$$$$002Ector$$2528C5CB(comparer$$26, new SetTree$00601(0, "SetEmpty"));
}
function forAll(f$$17, s$$38) {
  return FSharpSet$$ForAll$$Z1D55A0D7(s$$38, f$$17);
}
function exists(f$$18, s$$39) {
  return FSharpSet$$Exists$$Z1D55A0D7(s$$39, f$$18);
}
function filter(f$$19, s$$40) {
  return FSharpSet$$Filter$$Z1D55A0D7(s$$40, f$$19);
}
function partition(f$$20, s$$41) {
  return FSharpSet$$Partition$$Z1D55A0D7(s$$41, f$$20);
}
function fold(f$$21, z$$2, s$$42) {
  return SetTreeModule$$$fold(f$$21, z$$2, FSharpSet$$get_Tree(s$$42));
}
function foldBack(f$$22, s$$43, z$$3) {
  return SetTreeModule$$$foldBack(f$$22, FSharpSet$$get_Tree(s$$43), z$$3);
}
function map(f$$23, s$$44, comparer$$27) {
  return FSharpSet$$Map$$38806891(s$$44, f$$23, comparer$$27);
}
function count(s$$45) {
  return FSharpSet$$get_Count(s$$45);
}
function minimumElement(s$$46) {
  return FSharpSet$$get_MinimumElement(s$$46);
}
function maximumElement(s$$47) {
  return FSharpSet$$get_MaximumElement(s$$47);
}
function ofList(li, comparer$$28) {
  return FSharpSet$$$$002Ector$$2528C5CB(comparer$$28, SetTreeModule$$$ofSeq(comparer$$28, li));
}
function ofArray(arr$$2, comparer$$29) {
  return FSharpSet$$$$002Ector$$2528C5CB(comparer$$29, SetTreeModule$$$ofArray(comparer$$29, arr$$2));
}
function toList(s$$48) {
  return SetTreeModule$$$toList(FSharpSet$$get_Tree(s$$48));
}
function toArray(s$$49, cons) {
  var n$$3 = count(s$$49) | 0;
  var res$$1 = new cons(n$$3);
  SetTreeModule$$$copyToArray(FSharpSet$$get_Tree(s$$49), res$$1, 0);
  return res$$1;
}
function toSeq(s$$50) {
  return SetTreeModule$$$toSeq(FSharpSet$$get_Tree(s$$50));
}
function ofSeq(elements, comparer$$30) {
  return FSharpSet$$$$002Ector$$2528C5CB(comparer$$30, SetTreeModule$$$ofSeq(comparer$$30, elements));
}
function difference(x$$28, y$$6) {
  return FSharpSet$$$op_Subtraction(x$$28, y$$6);
}
function isSubset(x$$29, y$$7) {
  return FSharpSet$$IsSubsetOf$$6A20B1FF(x$$29, y$$7);
}
function isSuperset(x$$30, y$$8) {
  return FSharpSet$$IsSupersetOf$$6A20B1FF(x$$30, y$$8);
}
function isProperSubset(x$$31, y$$9) {
  return FSharpSet$$IsProperSubsetOf$$6A20B1FF(x$$31, y$$9);
}
function isProperSuperset(x$$32, y$$10) {
  return FSharpSet$$IsProperSupersetOf$$6A20B1FF(x$$32, y$$10);
}
function minElement(s$$51) {
  return FSharpSet$$get_MinimumElement(s$$51);
}
function maxElement(s$$52) {
  return FSharpSet$$get_MaximumElement(s$$52);
}

function createMutablePrivate(comparer$$31, tree$0027) {
  var _ref;

  var tree$$1 = tree$0027;
  return _ref = {
    get size() {
      return SetTreeModule$$$count(tree$$1);
    },

    add: function add(x$$33) {
      var this$$$4 = this;
      tree$$1 = SetTreeModule$$$add(comparer$$31, x$$33, tree$$1);
      return this$$$4;
    },
    add_: function add_(x$$34) {
      if (SetTreeModule$$$mem(comparer$$31, x$$34, tree$$1)) {
        return false;
      } else {
        tree$$1 = SetTreeModule$$$add(comparer$$31, x$$34, tree$$1);
        return true;
      }
    },
    clear: function clear() {
      tree$$1 = new SetTree$00601(0, "SetEmpty");
    },
    delete: function _delete(x$$35) {
      if (SetTreeModule$$$mem(comparer$$31, x$$35, tree$$1)) {
        tree$$1 = SetTreeModule$$$remove(comparer$$31, x$$35, tree$$1);
        return true;
      } else {
        return false;
      }
    },
    has: function has(x$$36) {
      return SetTreeModule$$$mem(comparer$$31, x$$36, tree$$1);
    },
    values: function values() {
      return SetTreeModule$$$toSeq(tree$$1);
    }
  }, __WEBPACK_IMPORTED_MODULE_0_babel_runtime_helpers_defineProperty___default()(_ref, __WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_symbol_iterator___default.a, function () {
    return Object(__WEBPACK_IMPORTED_MODULE_5__Seq__["l" /* toIterator */])(SetTreeModule$$$mkIEnumerator(tree$$1));
  }), __WEBPACK_IMPORTED_MODULE_0_babel_runtime_helpers_defineProperty___default()(_ref, "GetEnumerator", function GetEnumerator() {
    return SetTreeModule$$$mkIEnumerator(tree$$1);
  }), _ref;
}

function createMutable(source, comparer$$32) {
  return createMutablePrivate(comparer$$32, SetTreeModule$$$ofSeq(comparer$$32, source));
}
function distinct(xs, comparer$$33) {
  return createMutable(xs, comparer$$33);
}
function distinctBy(projection, xs$$1, comparer$$34) {
  var li$$1 = [];
  var hashSet = createMutable(Object(__WEBPACK_IMPORTED_MODULE_5__Seq__["b" /* empty */])(), comparer$$34);
  Object(__WEBPACK_IMPORTED_MODULE_5__Seq__["g" /* iterate */])(function (x$$37) {
    if (hashSet.add_(projection(x$$37))) {
      li$$1.push(x$$37);
    }
  }, xs$$1);
  return li$$1;
}
function unionWith(s1$$4, s2$$4) {
  return Object(__WEBPACK_IMPORTED_MODULE_5__Seq__["c" /* fold */])(function folder(acc$$14, x$$38) {
    return acc$$14.add(x$$38);
  }, s1$$4, s2$$4);
}
function intersectWith(s1$$5, s2$$5, comparer$$35) {
  var s2$$6 = ofSeq(s2$$5, comparer$$35);
  Object(__WEBPACK_IMPORTED_MODULE_5__Seq__["g" /* iterate */])(function (x$$39) {
    if (!FSharpSet$$Contains$$2B595(s2$$6, x$$39)) {
      s1$$5.delete(x$$39);
    }
  }, s1$$5);
}
function exceptWith(s1$$6, s2$$7) {
  Object(__WEBPACK_IMPORTED_MODULE_5__Seq__["g" /* iterate */])(function (x$$40) {
    s1$$6.delete(x$$40);
  }, s2$$7);
}
function isSubsetOf(s1$$7, s2$$8, comparer$$36) {
  return isSubset(ofSeq(s1$$7, comparer$$36), ofSeq(s2$$8, comparer$$36));
}
function isSupersetOf(s1$$8, s2$$9, comparer$$37) {
  return isSuperset(ofSeq(s1$$8, comparer$$37), ofSeq(s2$$9, comparer$$37));
}
function isProperSubsetOf(s1$$9, s2$$10, comparer$$38) {
  return isProperSubset(ofSeq(s1$$9, comparer$$38), ofSeq(s2$$10, comparer$$38));
}
function isProperSupersetOf(s1$$10, s2$$11, comparer$$39) {
  return isProperSuperset(ofSeq(s1$$10, comparer$$39), ofSeq(s2$$11, comparer$$39));
}

/***/ }),
/* 82 */
/***/ (function(module, exports) {

module.exports = require("electron");

/***/ }),
/* 83 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var fs = __webpack_require__(23)

module.exports = clone(fs)

function clone (obj) {
  if (obj === null || typeof obj !== 'object')
    return obj

  if (obj instanceof Object)
    var copy = { __proto__: obj.__proto__ }
  else
    var copy = Object.create(null)

  Object.getOwnPropertyNames(obj).forEach(function (key) {
    Object.defineProperty(copy, key, Object.getOwnPropertyDescriptor(obj, key))
  })

  return copy
}


/***/ }),
/* 84 */
/***/ (function(module, exports) {

module.exports = require("path");

/***/ }),
/* 85 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__Main_fs__ = __webpack_require__(86);
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "printHelpMessage", function() { return __WEBPACK_IMPORTED_MODULE_0__Main_fs__["j"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "args", function() { return __WEBPACK_IMPORTED_MODULE_0__Main_fs__["b"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "argFlagIsOn", function() { return __WEBPACK_IMPORTED_MODULE_0__Main_fs__["a"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "isValidFlag", function() { return __WEBPACK_IMPORTED_MODULE_0__Main_fs__["h"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "hasHelpArgs", function() { return __WEBPACK_IMPORTED_MODULE_0__Main_fs__["g"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "hasDebugArgs", function() { return __WEBPACK_IMPORTED_MODULE_0__Main_fs__["f"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "mainWindow", function() { return __WEBPACK_IMPORTED_MODULE_0__Main_fs__["i"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "shouldQuit", function() { return __WEBPACK_IMPORTED_MODULE_0__Main_fs__["l"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "settings", function() { return __WEBPACK_IMPORTED_MODULE_0__Main_fs__["k"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "dTrace", function() { return __WEBPACK_IMPORTED_MODULE_0__Main_fs__["d"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "enableHotReload", function() { return __WEBPACK_IMPORTED_MODULE_0__Main_fs__["e"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "createMainWindow", function() { return __WEBPACK_IMPORTED_MODULE_0__Main_fs__["c"]; });


/***/ }),
/* 86 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["j"] = printHelpMessage;
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return args; });
/* harmony export (immutable) */ __webpack_exports__["a"] = argFlagIsOn;
/* harmony export (immutable) */ __webpack_exports__["h"] = isValidFlag;
/* harmony export (immutable) */ __webpack_exports__["g"] = hasHelpArgs;
/* harmony export (immutable) */ __webpack_exports__["f"] = hasDebugArgs;
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "i", function() { return mainWindow; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "l", function() { return shouldQuit; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "k", function() { return settings; });
/* harmony export (immutable) */ __webpack_exports__["d"] = dTrace;
/* harmony export (immutable) */ __webpack_exports__["e"] = enableHotReload;
/* harmony export (immutable) */ __webpack_exports__["c"] = createMainWindow;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_array_from__ = __webpack_require__(13);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_array_from___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_array_from__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__fable_fable_core_2_0_11_String__ = __webpack_require__(45);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__fable_fable_core_2_0_11_List__ = __webpack_require__(141);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__fable_fable_core_2_0_11_Util__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_electron__ = __webpack_require__(82);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_electron___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_electron__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_electron_settings__ = __webpack_require__(148);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_electron_settings___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5_electron_settings__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_path__ = __webpack_require__(84);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_path___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_6_path__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7_fs__ = __webpack_require__(23);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7_fs___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_7_fs__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8_url__ = __webpack_require__(160);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8_url___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_8_url__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__fable_fable_core_2_0_11_Types__ = __webpack_require__(16);










function printHelpMessage() {
  Object(__WEBPACK_IMPORTED_MODULE_1__fable_fable_core_2_0_11_String__["c" /* toConsole */])(Object(__WEBPACK_IMPORTED_MODULE_1__fable_fable_core_2_0_11_String__["b" /* printf */])("\r\nVisual2 command line options\r\n----------------------------\r\n-h, --help      - print this help message\r\n-d, --debug     - run with browser dev tools initially open, for startup debug info logged to console\r\n                - <F12> to open or close dev tools after startup\r\n"));
}
var args = Object(__WEBPACK_IMPORTED_MODULE_2__fable_fable_core_2_0_11_List__["c" /* map */])(function mapping(s) {
  return s.toLocaleLowerCase();
}, Object(__WEBPACK_IMPORTED_MODULE_2__fable_fable_core_2_0_11_List__["e" /* ofSeq */])(process.argv));
function argFlagIsOn(flags) {
  var fl = Object(__WEBPACK_IMPORTED_MODULE_2__fable_fable_core_2_0_11_List__["c" /* map */])(function (s$$1) {
    return s$$1.toLocaleLowerCase();
  }, flags);
  return Object(__WEBPACK_IMPORTED_MODULE_2__fable_fable_core_2_0_11_List__["b" /* exists */])(function (flag) {
    return Object(__WEBPACK_IMPORTED_MODULE_2__fable_fable_core_2_0_11_List__["a" /* contains */])(flag, args, {
      Equals: function Equals($x$$1, $y$$2) {
        return $x$$1 === $y$$2;
      },
      GetHashCode: __WEBPACK_IMPORTED_MODULE_3__fable_fable_core_2_0_11_Util__["q" /* structuralHash */]
    });
  }, fl);
}
function isValidFlag(fl$$1) {
  return Object(__WEBPACK_IMPORTED_MODULE_2__fable_fable_core_2_0_11_List__["a" /* contains */])(fl$$1, Object(__WEBPACK_IMPORTED_MODULE_2__fable_fable_core_2_0_11_List__["d" /* ofArray */])(["-h", "--help", "-d", "--debug", "-w", "."]), {
    Equals: function Equals($x$$3, $y$$4) {
      return $x$$3 === $y$$4;
    },
    GetHashCode: __WEBPACK_IMPORTED_MODULE_3__fable_fable_core_2_0_11_Util__["q" /* structuralHash */]
  });
}
function hasHelpArgs() {
  if (argFlagIsOn(Object(__WEBPACK_IMPORTED_MODULE_2__fable_fable_core_2_0_11_List__["d" /* ofArray */])(["--help", "-h"]))) {
    return true;
  } else {
    return Object(__WEBPACK_IMPORTED_MODULE_2__fable_fable_core_2_0_11_List__["b" /* exists */])(function (arg) {
      return !isValidFlag(arg);
    }, Object(__WEBPACK_IMPORTED_MODULE_2__fable_fable_core_2_0_11_List__["f" /* tail */])(args));
  }
}

if (hasHelpArgs() ? !argFlagIsOn(Object(__WEBPACK_IMPORTED_MODULE_2__fable_fable_core_2_0_11_List__["d" /* ofArray */])(["--help", "-h"])) : false) {
  Object(__WEBPACK_IMPORTED_MODULE_1__fable_fable_core_2_0_11_String__["c" /* toConsole */])(Object(__WEBPACK_IMPORTED_MODULE_1__fable_fable_core_2_0_11_String__["b" /* printf */])("Bad arguments: %A"))(args);
}

function hasDebugArgs() {
  return argFlagIsOn(Object(__WEBPACK_IMPORTED_MODULE_2__fable_fable_core_2_0_11_List__["d" /* ofArray */])(["--debug", "-d"]));
}
var mainWindow = Object(__WEBPACK_IMPORTED_MODULE_3__fable_fable_core_2_0_11_Util__["h" /* createAtom */])(null);
var shouldQuit = __WEBPACK_IMPORTED_MODULE_4_electron___default.a.app.makeSingleInstance(function (_arg2, _arg1) {
  if (mainWindow() == null) {} else {
    var win = mainWindow();

    if (win.isMinimized()) {
      win.restore();
    }

    win.focus();
  }
});

if (shouldQuit) {
  __WEBPACK_IMPORTED_MODULE_4_electron___default.a.app.quit();
}

var settings = __WEBPACK_IMPORTED_MODULE_5_electron_settings___default.a;
function dTrace(fmt, s$$2) {
  if (hasDebugArgs()) {
    Object(__WEBPACK_IMPORTED_MODULE_1__fable_fable_core_2_0_11_String__["c" /* toConsole */])(fmt)(s$$2);
  }
}
dTrace(Object(__WEBPACK_IMPORTED_MODULE_1__fable_fable_core_2_0_11_String__["b" /* printf */])("settings=%A"), settings.get("editor-theme"));
function enableHotReload(window$) {
  Object(__WEBPACK_IMPORTED_MODULE_1__fable_fable_core_2_0_11_String__["c" /* toConsole */])(Object(__WEBPACK_IMPORTED_MODULE_1__fable_fable_core_2_0_11_String__["b" /* printf */])("Enabling development hot reload..."));
  __WEBPACK_IMPORTED_MODULE_7_fs__["watch"](__WEBPACK_IMPORTED_MODULE_6_path__["join"](__dirname, "/main.js"), function (_arg2$$1, _arg1$$1) {
    window$.webContents.reloadIgnoringCache();
  });
  __WEBPACK_IMPORTED_MODULE_7_fs__["watch"](__WEBPACK_IMPORTED_MODULE_6_path__["join"](__dirname, "/app/js"), function (_arg4, _arg3) {
    window$.webContents.reloadIgnoringCache();
  });
  __WEBPACK_IMPORTED_MODULE_7_fs__["watch"](__WEBPACK_IMPORTED_MODULE_6_path__["join"](__dirname, "/app/css"), function (_arg6, _arg5) {
    window$.webContents.reloadIgnoringCache();
  });
  __WEBPACK_IMPORTED_MODULE_7_fs__["watch"](__WEBPACK_IMPORTED_MODULE_6_path__["join"](__dirname, "/app/index.html"), function (_arg8, _arg7) {
    window$.webContents.reloadIgnoringCache();
  });
}
function createMainWindow() {
  if (hasHelpArgs()) {
    printHelpMessage();
  } else {
    if (hasDebugArgs()) {
      Object(__WEBPACK_IMPORTED_MODULE_1__fable_fable_core_2_0_11_String__["c" /* toConsole */])(Object(__WEBPACK_IMPORTED_MODULE_1__fable_fable_core_2_0_11_String__["b" /* printf */])("Starting to create app window..."));
    }

    var options = {};
    options.width = 1200;
    options.height = 800;
    options.show = false;
    var prefs = {};
    prefs.devTools = argFlagIsOn(Object(__WEBPACK_IMPORTED_MODULE_2__fable_fable_core_2_0_11_List__["d" /* ofArray */])(["-w", "-d", "--debug"]));
    options.webPreferences = prefs;
    options.frame = true;
    options.hasShadow = true;
    options.backgroundColor = "#5F9EA0";
    options.icon = "app/visual.ico";
    var window$$$1 = new __WEBPACK_IMPORTED_MODULE_4_electron___default.a.BrowserWindow(options);

    if (hasDebugArgs()) {
      window$$$1.webContents.openDevTools();
    }

    var opts = {};
    opts.pathname = __WEBPACK_IMPORTED_MODULE_6_path__["join"](__dirname, "/app/index.html");
    opts.protocol = "file:";
    dTrace(Object(__WEBPACK_IMPORTED_MODULE_1__fable_fable_core_2_0_11_String__["b" /* printf */])("Loading HTML: %A"), opts.pathname);
    window$$$1.loadURL(__WEBPACK_IMPORTED_MODULE_8_url__["format"](opts));
    dTrace(Object(__WEBPACK_IMPORTED_MODULE_1__fable_fable_core_2_0_11_String__["b" /* printf */])("%s"), "load complete");
    var closeAfterSave = false;
    window$$$1.on("close", function (e) {
      if (!closeAfterSave) {
        dTrace(Object(__WEBPACK_IMPORTED_MODULE_1__fable_fable_core_2_0_11_String__["b" /* printf */])("%s"), "Close event received!");
        e.preventDefault();
        window$$$1.webContents.send("closingWindow");
      }
    });
    window$$$1.on("closed", function () {
      mainWindow(null);
    });
    window$$$1.on("resize", function (_arg1$$2) {
      window$$$1.webContents.send("resizeWindow");
    });
    window$$$1.webContents.on("new-window", function (e$$1, x) {
      Object(__WEBPACK_IMPORTED_MODULE_1__fable_fable_core_2_0_11_String__["c" /* toConsole */])(Object(__WEBPACK_IMPORTED_MODULE_1__fable_fable_core_2_0_11_String__["b" /* printf */])("Opening new window! %A %A"))(e$$1)(x);
      e$$1.preventDefault();
      __WEBPACK_IMPORTED_MODULE_4_electron___default.a.shell.openExternal(x);
    });
    __WEBPACK_IMPORTED_MODULE_4_electron___default.a.ipcMain.on("doClose", function () {
      closeAfterSave = true;
      dTrace(Object(__WEBPACK_IMPORTED_MODULE_1__fable_fable_core_2_0_11_String__["b" /* printf */])("%s"), "Closing window NOW!");
      return window$$$1.close();
    });

    var template = __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_array_from___default()([{}]);

    __WEBPACK_IMPORTED_MODULE_4_electron___default.a.Menu.setApplicationMenu(__WEBPACK_IMPORTED_MODULE_4_electron___default.a.Menu.buildFromTemplate(template));
    window$$$1.on("ready-to-show", function () {
      window$$$1.show();
      options.backgroundColor = "#F0F0F0";
      window$$$1.focus();
      dTrace(Object(__WEBPACK_IMPORTED_MODULE_1__fable_fable_core_2_0_11_String__["b" /* printf */])("%s"), "Window on!");

      if (argFlagIsOn(new __WEBPACK_IMPORTED_MODULE_9__fable_fable_core_2_0_11_Types__["b" /* List */]("-w", new __WEBPACK_IMPORTED_MODULE_9__fable_fable_core_2_0_11_Types__["b" /* List */]()))) {
        enableHotReload(window$$$1);
      }
    });
    mainWindow(window$$$1);
  }
}
__WEBPACK_IMPORTED_MODULE_4_electron___default.a.app.on("ready", function () {
  createMainWindow();
});
__WEBPACK_IMPORTED_MODULE_4_electron___default.a.app.on("window-all-closed", function () {
  __WEBPACK_IMPORTED_MODULE_4_electron___default.a.app.quit();
});
__WEBPACK_IMPORTED_MODULE_4_electron___default.a.app.on("activate", function () {
  if (mainWindow() == null) {
    createMainWindow();
  }
});

/***/ }),
/* 87 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(24);
__webpack_require__(94);
module.exports = __webpack_require__(0).Array.from;


/***/ }),
/* 88 */
/***/ (function(module, exports, __webpack_require__) {

var toInteger = __webpack_require__(33);
var defined = __webpack_require__(34);
// true  -> String#at
// false -> String#codePointAt
module.exports = function (TO_STRING) {
  return function (that, pos) {
    var s = String(defined(that));
    var i = toInteger(pos);
    var l = s.length;
    var a, b;
    if (i < 0 || i >= l) return TO_STRING ? '' : undefined;
    a = s.charCodeAt(i);
    return a < 0xd800 || a > 0xdbff || i + 1 === l || (b = s.charCodeAt(i + 1)) < 0xdc00 || b > 0xdfff
      ? TO_STRING ? s.charAt(i) : a
      : TO_STRING ? s.slice(i, i + 2) : (a - 0xd800 << 10) + (b - 0xdc00) + 0x10000;
  };
};


/***/ }),
/* 89 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var create = __webpack_require__(38);
var descriptor = __webpack_require__(18);
var setToStringTag = __webpack_require__(27);
var IteratorPrototype = {};

// 25.1.2.1.1 %IteratorPrototype%[@@iterator]()
__webpack_require__(7)(IteratorPrototype, __webpack_require__(1)('iterator'), function () { return this; });

module.exports = function (Constructor, NAME, next) {
  Constructor.prototype = create(IteratorPrototype, { next: descriptor(1, next) });
  setToStringTag(Constructor, NAME + ' Iterator');
};


/***/ }),
/* 90 */
/***/ (function(module, exports, __webpack_require__) {

var dP = __webpack_require__(6);
var anObject = __webpack_require__(8);
var getKeys = __webpack_require__(19);

module.exports = __webpack_require__(9) ? Object.defineProperties : function defineProperties(O, Properties) {
  anObject(O);
  var keys = getKeys(Properties);
  var length = keys.length;
  var i = 0;
  var P;
  while (length > i) dP.f(O, P = keys[i++], Properties[P]);
  return O;
};


/***/ }),
/* 91 */
/***/ (function(module, exports, __webpack_require__) {

// false -> Array#indexOf
// true  -> Array#includes
var toIObject = __webpack_require__(12);
var toLength = __webpack_require__(25);
var toAbsoluteIndex = __webpack_require__(92);
module.exports = function (IS_INCLUDES) {
  return function ($this, el, fromIndex) {
    var O = toIObject($this);
    var length = toLength(O.length);
    var index = toAbsoluteIndex(fromIndex, length);
    var value;
    // Array#includes uses SameValueZero equality algorithm
    // eslint-disable-next-line no-self-compare
    if (IS_INCLUDES && el != el) while (length > index) {
      value = O[index++];
      // eslint-disable-next-line no-self-compare
      if (value != value) return true;
    // Array#indexOf ignores holes, Array#includes - not
    } else for (;length > index; index++) if (IS_INCLUDES || index in O) {
      if (O[index] === el) return IS_INCLUDES || index || 0;
    } return !IS_INCLUDES && -1;
  };
};


/***/ }),
/* 92 */
/***/ (function(module, exports, __webpack_require__) {

var toInteger = __webpack_require__(33);
var max = Math.max;
var min = Math.min;
module.exports = function (index, length) {
  index = toInteger(index);
  return index < 0 ? max(index + length, 0) : min(index, length);
};


/***/ }),
/* 93 */
/***/ (function(module, exports, __webpack_require__) {

var document = __webpack_require__(5).document;
module.exports = document && document.documentElement;


/***/ }),
/* 94 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var ctx = __webpack_require__(17);
var $export = __webpack_require__(2);
var toObject = __webpack_require__(15);
var call = __webpack_require__(64);
var isArrayIter = __webpack_require__(65);
var toLength = __webpack_require__(25);
var createProperty = __webpack_require__(95);
var getIterFn = __webpack_require__(44);

$export($export.S + $export.F * !__webpack_require__(96)(function (iter) { Array.from(iter); }), 'Array', {
  // 22.1.2.1 Array.from(arrayLike, mapfn = undefined, thisArg = undefined)
  from: function from(arrayLike /* , mapfn = undefined, thisArg = undefined */) {
    var O = toObject(arrayLike);
    var C = typeof this == 'function' ? this : Array;
    var aLen = arguments.length;
    var mapfn = aLen > 1 ? arguments[1] : undefined;
    var mapping = mapfn !== undefined;
    var index = 0;
    var iterFn = getIterFn(O);
    var length, result, step, iterator;
    if (mapping) mapfn = ctx(mapfn, aLen > 2 ? arguments[2] : undefined, 2);
    // if object isn't iterable or it's array with default iterator - use simple case
    if (iterFn != undefined && !(C == Array && isArrayIter(iterFn))) {
      for (iterator = iterFn.call(O), result = new C(); !(step = iterator.next()).done; index++) {
        createProperty(result, index, mapping ? call(iterator, mapfn, [step.value, index], true) : step.value);
      }
    } else {
      length = toLength(O.length);
      for (result = new C(length); length > index; index++) {
        createProperty(result, index, mapping ? mapfn(O[index], index) : O[index]);
      }
    }
    result.length = index;
    return result;
  }
});


/***/ }),
/* 95 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $defineProperty = __webpack_require__(6);
var createDesc = __webpack_require__(18);

module.exports = function (object, index, value) {
  if (index in object) $defineProperty.f(object, index, createDesc(0, value));
  else object[index] = value;
};


/***/ }),
/* 96 */
/***/ (function(module, exports, __webpack_require__) {

var ITERATOR = __webpack_require__(1)('iterator');
var SAFE_CLOSING = false;

try {
  var riter = [7][ITERATOR]();
  riter['return'] = function () { SAFE_CLOSING = true; };
  // eslint-disable-next-line no-throw-literal
  Array.from(riter, function () { throw 2; });
} catch (e) { /* empty */ }

module.exports = function (exec, skipClosing) {
  if (!skipClosing && !SAFE_CLOSING) return false;
  var safe = false;
  try {
    var arr = [7];
    var iter = arr[ITERATOR]();
    iter.next = function () { return { done: safe = true }; };
    arr[ITERATOR] = function () { return iter; };
    exec(arr);
  } catch (e) { /* empty */ }
  return safe;
};


/***/ }),
/* 97 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(24);
__webpack_require__(29);
module.exports = __webpack_require__(46).f('iterator');


/***/ }),
/* 98 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var addToUnscopables = __webpack_require__(99);
var step = __webpack_require__(100);
var Iterators = __webpack_require__(14);
var toIObject = __webpack_require__(12);

// 22.1.3.4 Array.prototype.entries()
// 22.1.3.13 Array.prototype.keys()
// 22.1.3.29 Array.prototype.values()
// 22.1.3.30 Array.prototype[@@iterator]()
module.exports = __webpack_require__(58)(Array, 'Array', function (iterated, kind) {
  this._t = toIObject(iterated); // target
  this._i = 0;                   // next index
  this._k = kind;                // kind
// 22.1.5.2.1 %ArrayIteratorPrototype%.next()
}, function () {
  var O = this._t;
  var kind = this._k;
  var index = this._i++;
  if (!O || index >= O.length) {
    this._t = undefined;
    return step(1);
  }
  if (kind == 'keys') return step(0, index);
  if (kind == 'values') return step(0, O[index]);
  return step(0, [index, O[index]]);
}, 'values');

// argumentsList[@@iterator] is %ArrayProto_values% (9.4.4.6, 9.4.4.7)
Iterators.Arguments = Iterators.Array;

addToUnscopables('keys');
addToUnscopables('values');
addToUnscopables('entries');


/***/ }),
/* 99 */
/***/ (function(module, exports) {

module.exports = function () { /* empty */ };


/***/ }),
/* 100 */
/***/ (function(module, exports) {

module.exports = function (done, value) {
  return { value: value, done: !!done };
};


/***/ }),
/* 101 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(102), __esModule: true };

/***/ }),
/* 102 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(103);
__webpack_require__(71);
__webpack_require__(106);
__webpack_require__(107);
module.exports = __webpack_require__(0).Symbol;


/***/ }),
/* 103 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// ECMAScript 6 symbols shim
var global = __webpack_require__(5);
var has = __webpack_require__(11);
var DESCRIPTORS = __webpack_require__(9);
var $export = __webpack_require__(2);
var redefine = __webpack_require__(37);
var META = __webpack_require__(30).KEY;
var $fails = __webpack_require__(10);
var shared = __webpack_require__(42);
var setToStringTag = __webpack_require__(27);
var uid = __webpack_require__(26);
var wks = __webpack_require__(1);
var wksExt = __webpack_require__(46);
var wksDefine = __webpack_require__(47);
var enumKeys = __webpack_require__(104);
var isArray = __webpack_require__(68);
var anObject = __webpack_require__(8);
var isObject = __webpack_require__(4);
var toIObject = __webpack_require__(12);
var toPrimitive = __webpack_require__(36);
var createDesc = __webpack_require__(18);
var _create = __webpack_require__(38);
var gOPNExt = __webpack_require__(105);
var $GOPD = __webpack_require__(70);
var $DP = __webpack_require__(6);
var $keys = __webpack_require__(19);
var gOPD = $GOPD.f;
var dP = $DP.f;
var gOPN = gOPNExt.f;
var $Symbol = global.Symbol;
var $JSON = global.JSON;
var _stringify = $JSON && $JSON.stringify;
var PROTOTYPE = 'prototype';
var HIDDEN = wks('_hidden');
var TO_PRIMITIVE = wks('toPrimitive');
var isEnum = {}.propertyIsEnumerable;
var SymbolRegistry = shared('symbol-registry');
var AllSymbols = shared('symbols');
var OPSymbols = shared('op-symbols');
var ObjectProto = Object[PROTOTYPE];
var USE_NATIVE = typeof $Symbol == 'function';
var QObject = global.QObject;
// Don't use setters in Qt Script, https://github.com/zloirock/core-js/issues/173
var setter = !QObject || !QObject[PROTOTYPE] || !QObject[PROTOTYPE].findChild;

// fallback for old Android, https://code.google.com/p/v8/issues/detail?id=687
var setSymbolDesc = DESCRIPTORS && $fails(function () {
  return _create(dP({}, 'a', {
    get: function () { return dP(this, 'a', { value: 7 }).a; }
  })).a != 7;
}) ? function (it, key, D) {
  var protoDesc = gOPD(ObjectProto, key);
  if (protoDesc) delete ObjectProto[key];
  dP(it, key, D);
  if (protoDesc && it !== ObjectProto) dP(ObjectProto, key, protoDesc);
} : dP;

var wrap = function (tag) {
  var sym = AllSymbols[tag] = _create($Symbol[PROTOTYPE]);
  sym._k = tag;
  return sym;
};

var isSymbol = USE_NATIVE && typeof $Symbol.iterator == 'symbol' ? function (it) {
  return typeof it == 'symbol';
} : function (it) {
  return it instanceof $Symbol;
};

var $defineProperty = function defineProperty(it, key, D) {
  if (it === ObjectProto) $defineProperty(OPSymbols, key, D);
  anObject(it);
  key = toPrimitive(key, true);
  anObject(D);
  if (has(AllSymbols, key)) {
    if (!D.enumerable) {
      if (!has(it, HIDDEN)) dP(it, HIDDEN, createDesc(1, {}));
      it[HIDDEN][key] = true;
    } else {
      if (has(it, HIDDEN) && it[HIDDEN][key]) it[HIDDEN][key] = false;
      D = _create(D, { enumerable: createDesc(0, false) });
    } return setSymbolDesc(it, key, D);
  } return dP(it, key, D);
};
var $defineProperties = function defineProperties(it, P) {
  anObject(it);
  var keys = enumKeys(P = toIObject(P));
  var i = 0;
  var l = keys.length;
  var key;
  while (l > i) $defineProperty(it, key = keys[i++], P[key]);
  return it;
};
var $create = function create(it, P) {
  return P === undefined ? _create(it) : $defineProperties(_create(it), P);
};
var $propertyIsEnumerable = function propertyIsEnumerable(key) {
  var E = isEnum.call(this, key = toPrimitive(key, true));
  if (this === ObjectProto && has(AllSymbols, key) && !has(OPSymbols, key)) return false;
  return E || !has(this, key) || !has(AllSymbols, key) || has(this, HIDDEN) && this[HIDDEN][key] ? E : true;
};
var $getOwnPropertyDescriptor = function getOwnPropertyDescriptor(it, key) {
  it = toIObject(it);
  key = toPrimitive(key, true);
  if (it === ObjectProto && has(AllSymbols, key) && !has(OPSymbols, key)) return;
  var D = gOPD(it, key);
  if (D && has(AllSymbols, key) && !(has(it, HIDDEN) && it[HIDDEN][key])) D.enumerable = true;
  return D;
};
var $getOwnPropertyNames = function getOwnPropertyNames(it) {
  var names = gOPN(toIObject(it));
  var result = [];
  var i = 0;
  var key;
  while (names.length > i) {
    if (!has(AllSymbols, key = names[i++]) && key != HIDDEN && key != META) result.push(key);
  } return result;
};
var $getOwnPropertySymbols = function getOwnPropertySymbols(it) {
  var IS_OP = it === ObjectProto;
  var names = gOPN(IS_OP ? OPSymbols : toIObject(it));
  var result = [];
  var i = 0;
  var key;
  while (names.length > i) {
    if (has(AllSymbols, key = names[i++]) && (IS_OP ? has(ObjectProto, key) : true)) result.push(AllSymbols[key]);
  } return result;
};

// 19.4.1.1 Symbol([description])
if (!USE_NATIVE) {
  $Symbol = function Symbol() {
    if (this instanceof $Symbol) throw TypeError('Symbol is not a constructor!');
    var tag = uid(arguments.length > 0 ? arguments[0] : undefined);
    var $set = function (value) {
      if (this === ObjectProto) $set.call(OPSymbols, value);
      if (has(this, HIDDEN) && has(this[HIDDEN], tag)) this[HIDDEN][tag] = false;
      setSymbolDesc(this, tag, createDesc(1, value));
    };
    if (DESCRIPTORS && setter) setSymbolDesc(ObjectProto, tag, { configurable: true, set: $set });
    return wrap(tag);
  };
  redefine($Symbol[PROTOTYPE], 'toString', function toString() {
    return this._k;
  });

  $GOPD.f = $getOwnPropertyDescriptor;
  $DP.f = $defineProperty;
  __webpack_require__(69).f = gOPNExt.f = $getOwnPropertyNames;
  __webpack_require__(31).f = $propertyIsEnumerable;
  __webpack_require__(48).f = $getOwnPropertySymbols;

  if (DESCRIPTORS && !__webpack_require__(35)) {
    redefine(ObjectProto, 'propertyIsEnumerable', $propertyIsEnumerable, true);
  }

  wksExt.f = function (name) {
    return wrap(wks(name));
  };
}

$export($export.G + $export.W + $export.F * !USE_NATIVE, { Symbol: $Symbol });

for (var es6Symbols = (
  // 19.4.2.2, 19.4.2.3, 19.4.2.4, 19.4.2.6, 19.4.2.8, 19.4.2.9, 19.4.2.10, 19.4.2.11, 19.4.2.12, 19.4.2.13, 19.4.2.14
  'hasInstance,isConcatSpreadable,iterator,match,replace,search,species,split,toPrimitive,toStringTag,unscopables'
).split(','), j = 0; es6Symbols.length > j;)wks(es6Symbols[j++]);

for (var wellKnownSymbols = $keys(wks.store), k = 0; wellKnownSymbols.length > k;) wksDefine(wellKnownSymbols[k++]);

$export($export.S + $export.F * !USE_NATIVE, 'Symbol', {
  // 19.4.2.1 Symbol.for(key)
  'for': function (key) {
    return has(SymbolRegistry, key += '')
      ? SymbolRegistry[key]
      : SymbolRegistry[key] = $Symbol(key);
  },
  // 19.4.2.5 Symbol.keyFor(sym)
  keyFor: function keyFor(sym) {
    if (!isSymbol(sym)) throw TypeError(sym + ' is not a symbol!');
    for (var key in SymbolRegistry) if (SymbolRegistry[key] === sym) return key;
  },
  useSetter: function () { setter = true; },
  useSimple: function () { setter = false; }
});

$export($export.S + $export.F * !USE_NATIVE, 'Object', {
  // 19.1.2.2 Object.create(O [, Properties])
  create: $create,
  // 19.1.2.4 Object.defineProperty(O, P, Attributes)
  defineProperty: $defineProperty,
  // 19.1.2.3 Object.defineProperties(O, Properties)
  defineProperties: $defineProperties,
  // 19.1.2.6 Object.getOwnPropertyDescriptor(O, P)
  getOwnPropertyDescriptor: $getOwnPropertyDescriptor,
  // 19.1.2.7 Object.getOwnPropertyNames(O)
  getOwnPropertyNames: $getOwnPropertyNames,
  // 19.1.2.8 Object.getOwnPropertySymbols(O)
  getOwnPropertySymbols: $getOwnPropertySymbols
});

// 24.3.2 JSON.stringify(value [, replacer [, space]])
$JSON && $export($export.S + $export.F * (!USE_NATIVE || $fails(function () {
  var S = $Symbol();
  // MS Edge converts symbol values to JSON as {}
  // WebKit converts symbol values to JSON as null
  // V8 throws on boxed symbols
  return _stringify([S]) != '[null]' || _stringify({ a: S }) != '{}' || _stringify(Object(S)) != '{}';
})), 'JSON', {
  stringify: function stringify(it) {
    var args = [it];
    var i = 1;
    var replacer, $replacer;
    while (arguments.length > i) args.push(arguments[i++]);
    $replacer = replacer = args[1];
    if (!isObject(replacer) && it === undefined || isSymbol(it)) return; // IE8 returns string on undefined
    if (!isArray(replacer)) replacer = function (key, value) {
      if (typeof $replacer == 'function') value = $replacer.call(this, key, value);
      if (!isSymbol(value)) return value;
    };
    args[1] = replacer;
    return _stringify.apply($JSON, args);
  }
});

// 19.4.3.4 Symbol.prototype[@@toPrimitive](hint)
$Symbol[PROTOTYPE][TO_PRIMITIVE] || __webpack_require__(7)($Symbol[PROTOTYPE], TO_PRIMITIVE, $Symbol[PROTOTYPE].valueOf);
// 19.4.3.5 Symbol.prototype[@@toStringTag]
setToStringTag($Symbol, 'Symbol');
// 20.2.1.9 Math[@@toStringTag]
setToStringTag(Math, 'Math', true);
// 24.3.3 JSON[@@toStringTag]
setToStringTag(global.JSON, 'JSON', true);


/***/ }),
/* 104 */
/***/ (function(module, exports, __webpack_require__) {

// all enumerable object keys, includes symbols
var getKeys = __webpack_require__(19);
var gOPS = __webpack_require__(48);
var pIE = __webpack_require__(31);
module.exports = function (it) {
  var result = getKeys(it);
  var getSymbols = gOPS.f;
  if (getSymbols) {
    var symbols = getSymbols(it);
    var isEnum = pIE.f;
    var i = 0;
    var key;
    while (symbols.length > i) if (isEnum.call(it, key = symbols[i++])) result.push(key);
  } return result;
};


/***/ }),
/* 105 */
/***/ (function(module, exports, __webpack_require__) {

// fallback for IE11 buggy Object.getOwnPropertyNames with iframe and window
var toIObject = __webpack_require__(12);
var gOPN = __webpack_require__(69).f;
var toString = {}.toString;

var windowNames = typeof window == 'object' && window && Object.getOwnPropertyNames
  ? Object.getOwnPropertyNames(window) : [];

var getWindowNames = function (it) {
  try {
    return gOPN(it);
  } catch (e) {
    return windowNames.slice();
  }
};

module.exports.f = function getOwnPropertyNames(it) {
  return windowNames && toString.call(it) == '[object Window]' ? getWindowNames(it) : gOPN(toIObject(it));
};


/***/ }),
/* 106 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(47)('asyncIterator');


/***/ }),
/* 107 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(47)('observable');


/***/ }),
/* 108 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(29);
__webpack_require__(24);
module.exports = __webpack_require__(109);


/***/ }),
/* 109 */
/***/ (function(module, exports, __webpack_require__) {

var anObject = __webpack_require__(8);
var get = __webpack_require__(44);
module.exports = __webpack_require__(0).getIterator = function (it) {
  var iterFn = get(it);
  if (typeof iterFn != 'function') throw TypeError(it + ' is not iterable!');
  return anObject(iterFn.call(it));
};


/***/ }),
/* 110 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export offsetRegex */
/* unused harmony export dateOffsetToString */
/* unused harmony export dateToHalfUTCString */
/* harmony export (immutable) */ __webpack_exports__["a"] = toString;
/* unused harmony export default */
/* unused harmony export fromTicks */
/* unused harmony export fromDateTimeOffset */
/* unused harmony export getTicks */
/* unused harmony export minValue */
/* unused harmony export maxValue */
/* unused harmony export parseRaw */
/* unused harmony export parse */
/* unused harmony export tryParse */
/* unused harmony export create */
/* unused harmony export now */
/* unused harmony export utcNow */
/* unused harmony export today */
/* unused harmony export isLeapYear */
/* unused harmony export daysInMonth */
/* unused harmony export toUniversalTime */
/* unused harmony export toLocalTime */
/* unused harmony export timeOfDay */
/* unused harmony export date */
/* unused harmony export day */
/* unused harmony export hour */
/* unused harmony export millisecond */
/* unused harmony export minute */
/* unused harmony export month */
/* unused harmony export second */
/* unused harmony export year */
/* unused harmony export dayOfWeek */
/* unused harmony export dayOfYear */
/* unused harmony export add */
/* unused harmony export addDays */
/* unused harmony export addHours */
/* unused harmony export addMinutes */
/* unused harmony export addSeconds */
/* unused harmony export addMilliseconds */
/* unused harmony export addYears */
/* unused harmony export addMonths */
/* unused harmony export subtract */
/* unused harmony export toLongDateString */
/* unused harmony export toShortDateString */
/* unused harmony export toLongTimeString */
/* unused harmony export toShortTimeString */
/* unused harmony export equals */
/* unused harmony export compare */
/* unused harmony export compareTo */
/* unused harmony export op_Addition */
/* unused harmony export op_Subtraction */
/* unused harmony export isDaylightSavingTime */
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__Long__ = __webpack_require__(49);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__Util__ = __webpack_require__(3);
/**
 * DateTimeOffset functions.
 *
 * Note: Date instances are always DateObjects in local
 * timezone (because JS dates are all kinds of messed up).
 * A local date returns UTC epoc when `.getTime()` is called.
 *
 * Basically; invariant: date.getTime() always return UTC time.
 */


var offsetRegex = /(?:Z|[+-](\d+):?([0-5]?\d)?)\s*$/;
function dateOffsetToString(offset) {
    var isMinus = offset < 0;
    offset = Math.abs(offset);
    var hours = ~~(offset / 3600000);
    var minutes = offset % 3600000 / 60000;
    return (isMinus ? "-" : "+") + Object(__WEBPACK_IMPORTED_MODULE_1__Util__["p" /* padWithZeros */])(hours, 2) + ":" + Object(__WEBPACK_IMPORTED_MODULE_1__Util__["p" /* padWithZeros */])(minutes, 2);
}
function dateToHalfUTCString(date, half) {
    var str = date.toISOString();
    return half === "first" ? str.substring(0, str.indexOf("T")) : str.substring(str.indexOf("T") + 1, str.length - 1);
}
function dateToISOString(d, utc) {
    if (utc) {
        return d.toISOString();
    } else {
        // JS Date is always local
        var printOffset = d.kind == null ? true : d.kind === 2 /* Local */;
        return Object(__WEBPACK_IMPORTED_MODULE_1__Util__["p" /* padWithZeros */])(d.getFullYear(), 4) + "-" + Object(__WEBPACK_IMPORTED_MODULE_1__Util__["p" /* padWithZeros */])(d.getMonth() + 1, 2) + "-" + Object(__WEBPACK_IMPORTED_MODULE_1__Util__["p" /* padWithZeros */])(d.getDate(), 2) + "T" + Object(__WEBPACK_IMPORTED_MODULE_1__Util__["p" /* padWithZeros */])(d.getHours(), 2) + ":" + Object(__WEBPACK_IMPORTED_MODULE_1__Util__["p" /* padWithZeros */])(d.getMinutes(), 2) + ":" + Object(__WEBPACK_IMPORTED_MODULE_1__Util__["p" /* padWithZeros */])(d.getSeconds(), 2) + "." + Object(__WEBPACK_IMPORTED_MODULE_1__Util__["p" /* padWithZeros */])(d.getMilliseconds(), 3) + (printOffset ? dateOffsetToString(d.getTimezoneOffset() * -60000) : "");
    }
}
function dateToISOStringWithOffset(dateWithOffset, offset) {
    var str = dateWithOffset.toISOString();
    return str.substring(0, str.length - 1) + dateOffsetToString(offset);
}
function dateToStringWithCustomFormat(date, format, utc) {
    return format.replace(/(\w)\1*/g, function (match) {
        var rep = match;
        switch (match.substring(0, 1)) {
            case "y":
                var y = utc ? date.getUTCFullYear() : date.getFullYear();
                rep = match.length < 4 ? y % 100 : y;
                break;
            case "M":
                rep = (utc ? date.getUTCMonth() : date.getMonth()) + 1;
                break;
            case "d":
                rep = utc ? date.getUTCDate() : date.getDate();
                break;
            case "H":
                rep = utc ? date.getUTCHours() : date.getHours();
                break;
            case "h":
                var h = utc ? date.getUTCHours() : date.getHours();
                rep = h > 12 ? h % 12 : h;
                break;
            case "m":
                rep = utc ? date.getUTCMinutes() : date.getMinutes();
                break;
            case "s":
                rep = utc ? date.getUTCSeconds() : date.getSeconds();
                break;
        }
        if (rep !== match && rep < 10 && match.length > 1) {
            rep = "0" + rep;
        }
        return rep;
    });
}
function dateToStringWithOffset(date, format) {
    var d = new Date(date.getTime() + date.offset);
    if (typeof format !== "string") {
        return d.toISOString().replace(/\.\d+/, "").replace(/[A-Z]|\.\d+/g, " ") + dateOffsetToString(date.offset);
    } else if (format.length === 1) {
        switch (format) {
            case "D":
            case "d":
                return dateToHalfUTCString(d, "first");
            case "T":
            case "t":
                return dateToHalfUTCString(d, "second");
            case "O":
            case "o":
                return dateToISOStringWithOffset(d, date.offset);
            default:
                throw new Error("Unrecognized Date print format");
        }
    } else {
        return dateToStringWithCustomFormat(d, format, true);
    }
}
function dateToStringWithKind(date, format) {
    var utc = date.kind === 1 /* UTC */;
    if (typeof format !== "string") {
        return utc ? date.toUTCString() : date.toLocaleString();
    } else if (format.length === 1) {
        switch (format) {
            case "D":
            case "d":
                return utc ? dateToHalfUTCString(date, "first") : date.toLocaleDateString();
            case "T":
            case "t":
                return utc ? dateToHalfUTCString(date, "second") : date.toLocaleTimeString();
            case "O":
            case "o":
                return dateToISOString(date, utc);
            default:
                throw new Error("Unrecognized Date print format");
        }
    } else {
        return dateToStringWithCustomFormat(date, format, utc);
    }
}
function toString(date, format) {
    return date.offset != null ? dateToStringWithOffset(date, format) : dateToStringWithKind(date, format);
}
function DateTime(value, kind) {
    var d = new Date(value);
    d.kind = (kind == null ? 0 /* Unspecified */ : kind) | 0;
    return d;
}
function fromTicks(ticks, kind) {
    ticks = Object(__WEBPACK_IMPORTED_MODULE_0__Long__["c" /* fromValue */])(ticks);
    kind = kind != null ? kind : 0 /* Unspecified */;
    var date = DateTime(Object(__WEBPACK_IMPORTED_MODULE_0__Long__["e" /* ticksToUnixEpochMilliseconds */])(ticks), kind);
    // Ticks are local to offset (in this case, either UTC or Local/Unknown).
    // If kind is anything but UTC, that means that the tick number was not
    // in utc, thus getTime() cannot return UTC, and needs to be shifted.
    if (kind !== 1 /* UTC */) {
            date = DateTime(date.getTime() - Object(__WEBPACK_IMPORTED_MODULE_1__Util__["i" /* dateOffset */])(date), kind);
        }
    return date;
}
function fromDateTimeOffset(date, kind) {
    switch (kind) {
        case 1 /* UTC */:
            return DateTime(date.getTime(), 1 /* UTC */);
        case 2 /* Local */:
            return DateTime(date.getTime(), 2 /* Local */);
        default:
            var d = DateTime(date.getTime() + date.offset, kind);
            return DateTime(d.getTime() - Object(__WEBPACK_IMPORTED_MODULE_1__Util__["i" /* dateOffset */])(d), kind);
    }
}
function getTicks(date) {
    return Object(__WEBPACK_IMPORTED_MODULE_0__Long__["h" /* unixEpochMillisecondsToTicks */])(date.getTime(), Object(__WEBPACK_IMPORTED_MODULE_1__Util__["i" /* dateOffset */])(date));
}
function minValue() {
    // This is "0001-01-01T00:00:00.000Z", actual JS min value is -8640000000000000
    return DateTime(-62135596800000, 0 /* Unspecified */);
}
function maxValue() {
    // This is "9999-12-31T23:59:59.999Z", actual JS max value is 8640000000000000
    return DateTime(253402300799999, 0 /* Unspecified */);
}
function parseRaw(str) {
    var date = new Date(str);
    if (isNaN(date.getTime())) {
        // Try to check strings JS Date cannot parse (see #1045, #1422)
        // tslint:disable-next-line:max-line-length
        var m = /^\s*(\d+[^\w\s:]\d+[^\w\s:]\d+)?\s*(\d+:\d+(?::\d+(?:\.\d+)?)?)?\s*([AaPp][Mm])?\s*([+-]\d+(?::\d+)?)?\s*$/.exec(str);
        if (m != null) {
            var baseDate = null;
            var timeInSeconds = 0;
            if (m[2] != null) {
                var timeParts = m[2].split(":");
                timeInSeconds = parseInt(timeParts[0], 10) * 3600 + parseInt(timeParts[1] || "0", 10) * 60 + parseFloat(timeParts[2] || "0");
                if (m[3] != null && m[3].toUpperCase() === "PM") {
                    timeInSeconds += 720;
                }
            }
            if (m[4] != null) {
                // There's an offset, parse as UTC
                if (m[1] != null) {
                    baseDate = new Date(m[1] + " UTC");
                } else {
                    var d = new Date();
                    baseDate = new Date(d.getUTCFullYear() + "/" + (d.getUTCMonth() + 1) + "/" + d.getUTCDate());
                }
                var offsetParts = m[4].substr(1).split(":");
                var offsetInMinutes = parseInt(offsetParts[0], 10) * 60 + parseInt(offsetParts[1] || "0", 10);
                if (m[4][0] === "+") {
                    offsetInMinutes *= -1;
                }
                timeInSeconds += offsetInMinutes * 60;
            } else {
                if (m[1] != null) {
                    baseDate = new Date(m[1]);
                } else {
                    var _d = new Date();
                    baseDate = new Date(_d.getFullYear() + "/" + (_d.getMonth() + 1) + "/" + _d.getDate());
                }
            }
            date = new Date(baseDate.getTime() + timeInSeconds * 1000);
            // correct for daylight savings time
            date = new Date(date.getTime() + (date.getTimezoneOffset() - baseDate.getTimezoneOffset()) * 60000);
        } else {
            throw new Error("The string is not a valid Date.");
        }
    }
    return date;
}
function parse(str) {
    var detectUTC = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;

    var date = parseRaw(str);
    var offset = offsetRegex.exec(str);
    // .NET always parses DateTime as Local if there's offset info (even "Z")
    // Newtonsoft.Json uses UTC if the offset is "Z"
    var kind = offset != null ? detectUTC && offset[0] === "Z" ? 1 /* UTC */ : 2 /* Local */ : 0 /* Unspecified */;
    return DateTime(date.getTime(), kind);
}
function tryParse(v) {
    try {
        return [true, parse(v)];
    } catch (_err) {
        return [false, minValue()];
    }
}
function create(year, month, day) {
    var h = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 0;
    var m = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : 0;
    var s = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : 0;
    var ms = arguments.length > 6 && arguments[6] !== undefined ? arguments[6] : 0;
    var kind = arguments[7];

    var dateValue = kind === 1 /* UTC */
    ? Date.UTC(year, month - 1, day, h, m, s, ms) : new Date(year, month - 1, day, h, m, s, ms).getTime();
    if (isNaN(dateValue)) {
        throw new Error("The parameters describe an unrepresentable Date.");
    }
    var date = DateTime(dateValue, kind);
    if (year <= 99) {
        date.setFullYear(year, month - 1, day);
    }
    return date;
}
function now() {
    return DateTime(Date.now(), 2 /* Local */);
}
function utcNow() {
    return DateTime(Date.now(), 1 /* UTC */);
}
function today() {
    return date(now());
}
function isLeapYear(year) {
    return year % 4 === 0 && year % 100 !== 0 || year % 400 === 0;
}
function daysInMonth(year, month) {
    return month === 2 ? isLeapYear(year) ? 29 : 28 : month >= 8 ? month % 2 === 0 ? 31 : 30 : month % 2 === 0 ? 30 : 31;
}
function toUniversalTime(date) {
    return date.kind === 1 /* UTC */ ? date : DateTime(date.getTime(), 1 /* UTC */);
}
function toLocalTime(date) {
    return date.kind === 2 /* Local */ ? date : DateTime(date.getTime(), 2 /* Local */);
}
function timeOfDay(d) {
    return hour(d) * 3600000 + minute(d) * 60000 + second(d) * 1000 + millisecond(d);
}
function date(d) {
    return create(year(d), month(d), day(d), 0, 0, 0, 0, d.kind);
}
function day(d) {
    return d.kind === 1 /* UTC */ ? d.getUTCDate() : d.getDate();
}
function hour(d) {
    return d.kind === 1 /* UTC */ ? d.getUTCHours() : d.getHours();
}
function millisecond(d) {
    return d.kind === 1 /* UTC */ ? d.getUTCMilliseconds() : d.getMilliseconds();
}
function minute(d) {
    return d.kind === 1 /* UTC */ ? d.getUTCMinutes() : d.getMinutes();
}
function month(d) {
    return (d.kind === 1 /* UTC */ ? d.getUTCMonth() : d.getMonth()) + 1;
}
function second(d) {
    return d.kind === 1 /* UTC */ ? d.getUTCSeconds() : d.getSeconds();
}
function year(d) {
    return d.kind === 1 /* UTC */ ? d.getUTCFullYear() : d.getFullYear();
}
function dayOfWeek(d) {
    return d.kind === 1 /* UTC */ ? d.getUTCDay() : d.getDay();
}
function dayOfYear(d) {
    var _year = year(d);
    var _month = month(d);
    var _day = day(d);
    for (var i = 1; i < _month; i++) {
        _day += daysInMonth(_year, i);
    }
    return _day;
}
function add(d, ts) {
    return DateTime(d.getTime() + ts, d.kind);
}
function addDays(d, v) {
    return DateTime(d.getTime() + v * 86400000, d.kind);
}
function addHours(d, v) {
    return DateTime(d.getTime() + v * 3600000, d.kind);
}
function addMinutes(d, v) {
    return DateTime(d.getTime() + v * 60000, d.kind);
}
function addSeconds(d, v) {
    return DateTime(d.getTime() + v * 1000, d.kind);
}
function addMilliseconds(d, v) {
    return DateTime(d.getTime() + v, d.kind);
}
function addYears(d, v) {
    var newMonth = month(d);
    var newYear = year(d) + v;
    var _daysInMonth = daysInMonth(newYear, newMonth);
    var newDay = Math.min(_daysInMonth, day(d));
    return create(newYear, newMonth, newDay, hour(d), minute(d), second(d), millisecond(d), d.kind);
}
function addMonths(d, v) {
    var newMonth = month(d) + v;
    var newMonth_ = 0;
    var yearOffset = 0;
    if (newMonth > 12) {
        newMonth_ = newMonth % 12;
        yearOffset = Math.floor(newMonth / 12);
        newMonth = newMonth_;
    } else if (newMonth < 1) {
        newMonth_ = 12 + newMonth % 12;
        yearOffset = Math.floor(newMonth / 12) + (newMonth_ === 12 ? -1 : 0);
        newMonth = newMonth_;
    }
    var newYear = year(d) + yearOffset;
    var _daysInMonth = daysInMonth(newYear, newMonth);
    var newDay = Math.min(_daysInMonth, day(d));
    return create(newYear, newMonth, newDay, hour(d), minute(d), second(d), millisecond(d), d.kind);
}
function subtract(d, that) {
    return typeof that === "number" ? DateTime(d.getTime() - that, d.kind) : d.getTime() - that.getTime();
}
function toLongDateString(d) {
    return d.toDateString();
}
function toShortDateString(d) {
    return d.toLocaleDateString();
}
function toLongTimeString(d) {
    return d.toLocaleTimeString();
}
function toShortTimeString(d) {
    return d.toLocaleTimeString().replace(/:\d\d(?!:)/, "");
}
function equals(d1, d2) {
    return d1.getTime() === d2.getTime();
}
var compare = __WEBPACK_IMPORTED_MODULE_1__Util__["e" /* compareDates */];
var compareTo = __WEBPACK_IMPORTED_MODULE_1__Util__["e" /* compareDates */];
function op_Addition(x, y) {
    return add(x, y);
}
function op_Subtraction(x, y) {
    return subtract(x, y);
}
function isDaylightSavingTime(x) {
    var jan = new Date(x.getFullYear(), 0, 1);
    var jul = new Date(x.getFullYear(), 6, 1);
    return isDST(jan.getTimezoneOffset(), jul.getTimezoneOffset(), x.getTimezoneOffset());
}
function isDST(janOffset, julOffset, tOffset) {
    return Math.min(janOffset, julOffset) === tOffset;
}

/***/ }),
/* 111 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = isValid;
/* unused harmony export tryParse */
/* unused harmony export parse */
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_number_is_nan__ = __webpack_require__(112);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_number_is_nan___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_number_is_nan__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_slicedToArray__ = __webpack_require__(72);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_slicedToArray___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_slicedToArray__);


var parseRadix = /^\s*([\+\-])?(0[xXoObB])?([0-9a-fA-F]+)\s*$/;
var invalidRadix2 = /[^0-1]/;
var invalidRadix8 = /[^0-7]/;
var invalidRadix10 = /[^0-9]/;
var invalidRadix16 = /[^0-9a-fA-F]/;
function validResponse(regexMatch, radix) {
    var _regexMatch = __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_slicedToArray___default()(regexMatch, 4),
        _all = _regexMatch[0],
        sign = _regexMatch[1],
        prefix = _regexMatch[2],
        digits = _regexMatch[3];

    return {
        sign: sign || "",
        prefix: prefix,
        digits: digits,
        radix: radix
    };
}
function isValid(s, radix) {
    var res = parseRadix.exec(s);
    if (res != null) {
        if (radix == null) {
            switch (res[2]) {
                case "0b":
                case "0B":
                    radix = 2;
                    break;
                case "0o":
                case "0O":
                    radix = 8;
                    break;
                case "0x":
                case "0X":
                    radix = 16;
                    break;
                default:
                    radix = 10;
                    break;
            }
        }
        switch (radix) {
            case 2:
                return invalidRadix2.test(res[3]) ? null : validResponse(res, 2);
            case 8:
                return invalidRadix8.test(res[3]) ? null : validResponse(res, 8);
            case 10:
                return invalidRadix10.test(res[3]) ? null : validResponse(res, 10);
            case 16:
                return invalidRadix16.test(res[3]) ? null : validResponse(res, 16);
            default:
                throw new Error("Invalid Base.");
        }
    }
    return null;
}
// TODO does this perfectly match the .NET behavior ?
function tryParse(s, radix, initial) {
    var res = isValid(s, radix);
    if (res !== null) {
        var v = parseInt(res.sign + res.digits, res.radix);
        if (!__WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_number_is_nan___default()(v)) {
            return [true, v];
        }
    }
    return [false, initial];
}
function parse(s, radix) {
    var a = tryParse(s, radix, 0);
    if (a[0]) {
        return a[1];
    } else {
        throw new Error("Input string was not in a correct format.");
    }
}

/***/ }),
/* 112 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(113), __esModule: true };

/***/ }),
/* 113 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(114);
module.exports = __webpack_require__(0).Number.isNaN;


/***/ }),
/* 114 */
/***/ (function(module, exports, __webpack_require__) {

// 20.1.2.4 Number.isNaN(number)
var $export = __webpack_require__(2);

$export($export.S, 'Number', {
  isNaN: function isNaN(number) {
    // eslint-disable-next-line no-self-compare
    return number != number;
  }
});


/***/ }),
/* 115 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(29);
__webpack_require__(24);
module.exports = __webpack_require__(116);


/***/ }),
/* 116 */
/***/ (function(module, exports, __webpack_require__) {

var classof = __webpack_require__(66);
var ITERATOR = __webpack_require__(1)('iterator');
var Iterators = __webpack_require__(14);
module.exports = __webpack_require__(0).isIterable = function (it) {
  var O = Object(it);
  return O[ITERATOR] !== undefined
    || '@@iterator' in O
    // eslint-disable-next-line no-prototype-builtins
    || Iterators.hasOwnProperty(classof(O));
};


/***/ }),
/* 117 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(118), __esModule: true };

/***/ }),
/* 118 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(71);
__webpack_require__(29);
__webpack_require__(119);
__webpack_require__(124);
__webpack_require__(126);
module.exports = __webpack_require__(0).WeakMap;


/***/ }),
/* 119 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var each = __webpack_require__(50)(0);
var redefine = __webpack_require__(37);
var meta = __webpack_require__(30);
var assign = __webpack_require__(74);
var weak = __webpack_require__(122);
var isObject = __webpack_require__(4);
var fails = __webpack_require__(10);
var validate = __webpack_require__(77);
var WEAK_MAP = 'WeakMap';
var getWeak = meta.getWeak;
var isExtensible = Object.isExtensible;
var uncaughtFrozenStore = weak.ufstore;
var tmp = {};
var InternalMap;

var wrapper = function (get) {
  return function WeakMap() {
    return get(this, arguments.length > 0 ? arguments[0] : undefined);
  };
};

var methods = {
  // 23.3.3.3 WeakMap.prototype.get(key)
  get: function get(key) {
    if (isObject(key)) {
      var data = getWeak(key);
      if (data === true) return uncaughtFrozenStore(validate(this, WEAK_MAP)).get(key);
      return data ? data[this._i] : undefined;
    }
  },
  // 23.3.3.5 WeakMap.prototype.set(key, value)
  set: function set(key, value) {
    return weak.def(validate(this, WEAK_MAP), key, value);
  }
};

// 23.3 WeakMap Objects
var $WeakMap = module.exports = __webpack_require__(123)(WEAK_MAP, wrapper, methods, weak, true, true);

// IE11 WeakMap frozen keys fix
if (fails(function () { return new $WeakMap().set((Object.freeze || Object)(tmp), 7).get(tmp) != 7; })) {
  InternalMap = weak.getConstructor(wrapper, WEAK_MAP);
  assign(InternalMap.prototype, methods);
  meta.NEED = true;
  each(['delete', 'has', 'get', 'set'], function (key) {
    var proto = $WeakMap.prototype;
    var method = proto[key];
    redefine(proto, key, function (a, b) {
      // store frozen objects on internal weakmap shim
      if (isObject(a) && !isExtensible(a)) {
        if (!this._f) this._f = new InternalMap();
        var result = this._f[key](a, b);
        return key == 'set' ? this : result;
      // store all the rest on native weakmap
      } return method.call(this, a, b);
    });
  });
}


/***/ }),
/* 120 */
/***/ (function(module, exports, __webpack_require__) {

// 9.4.2.3 ArraySpeciesCreate(originalArray, length)
var speciesConstructor = __webpack_require__(121);

module.exports = function (original, length) {
  return new (speciesConstructor(original))(length);
};


/***/ }),
/* 121 */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(4);
var isArray = __webpack_require__(68);
var SPECIES = __webpack_require__(1)('species');

module.exports = function (original) {
  var C;
  if (isArray(original)) {
    C = original.constructor;
    // cross-realm fallback
    if (typeof C == 'function' && (C === Array || isArray(C.prototype))) C = undefined;
    if (isObject(C)) {
      C = C[SPECIES];
      if (C === null) C = undefined;
    }
  } return C === undefined ? Array : C;
};


/***/ }),
/* 122 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var redefineAll = __webpack_require__(75);
var getWeak = __webpack_require__(30).getWeak;
var anObject = __webpack_require__(8);
var isObject = __webpack_require__(4);
var anInstance = __webpack_require__(76);
var forOf = __webpack_require__(51);
var createArrayMethod = __webpack_require__(50);
var $has = __webpack_require__(11);
var validate = __webpack_require__(77);
var arrayFind = createArrayMethod(5);
var arrayFindIndex = createArrayMethod(6);
var id = 0;

// fallback for uncaught frozen keys
var uncaughtFrozenStore = function (that) {
  return that._l || (that._l = new UncaughtFrozenStore());
};
var UncaughtFrozenStore = function () {
  this.a = [];
};
var findUncaughtFrozen = function (store, key) {
  return arrayFind(store.a, function (it) {
    return it[0] === key;
  });
};
UncaughtFrozenStore.prototype = {
  get: function (key) {
    var entry = findUncaughtFrozen(this, key);
    if (entry) return entry[1];
  },
  has: function (key) {
    return !!findUncaughtFrozen(this, key);
  },
  set: function (key, value) {
    var entry = findUncaughtFrozen(this, key);
    if (entry) entry[1] = value;
    else this.a.push([key, value]);
  },
  'delete': function (key) {
    var index = arrayFindIndex(this.a, function (it) {
      return it[0] === key;
    });
    if (~index) this.a.splice(index, 1);
    return !!~index;
  }
};

module.exports = {
  getConstructor: function (wrapper, NAME, IS_MAP, ADDER) {
    var C = wrapper(function (that, iterable) {
      anInstance(that, C, NAME, '_i');
      that._t = NAME;      // collection type
      that._i = id++;      // collection id
      that._l = undefined; // leak store for uncaught frozen objects
      if (iterable != undefined) forOf(iterable, IS_MAP, that[ADDER], that);
    });
    redefineAll(C.prototype, {
      // 23.3.3.2 WeakMap.prototype.delete(key)
      // 23.4.3.3 WeakSet.prototype.delete(value)
      'delete': function (key) {
        if (!isObject(key)) return false;
        var data = getWeak(key);
        if (data === true) return uncaughtFrozenStore(validate(this, NAME))['delete'](key);
        return data && $has(data, this._i) && delete data[this._i];
      },
      // 23.3.3.4 WeakMap.prototype.has(key)
      // 23.4.3.4 WeakSet.prototype.has(value)
      has: function has(key) {
        if (!isObject(key)) return false;
        var data = getWeak(key);
        if (data === true) return uncaughtFrozenStore(validate(this, NAME)).has(key);
        return data && $has(data, this._i);
      }
    });
    return C;
  },
  def: function (that, key, value) {
    var data = getWeak(anObject(key), true);
    if (data === true) uncaughtFrozenStore(that).set(key, value);
    else data[that._i] = value;
    return that;
  },
  ufstore: uncaughtFrozenStore
};


/***/ }),
/* 123 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var global = __webpack_require__(5);
var $export = __webpack_require__(2);
var meta = __webpack_require__(30);
var fails = __webpack_require__(10);
var hide = __webpack_require__(7);
var redefineAll = __webpack_require__(75);
var forOf = __webpack_require__(51);
var anInstance = __webpack_require__(76);
var isObject = __webpack_require__(4);
var setToStringTag = __webpack_require__(27);
var dP = __webpack_require__(6).f;
var each = __webpack_require__(50)(0);
var DESCRIPTORS = __webpack_require__(9);

module.exports = function (NAME, wrapper, methods, common, IS_MAP, IS_WEAK) {
  var Base = global[NAME];
  var C = Base;
  var ADDER = IS_MAP ? 'set' : 'add';
  var proto = C && C.prototype;
  var O = {};
  if (!DESCRIPTORS || typeof C != 'function' || !(IS_WEAK || proto.forEach && !fails(function () {
    new C().entries().next();
  }))) {
    // create collection constructor
    C = common.getConstructor(wrapper, NAME, IS_MAP, ADDER);
    redefineAll(C.prototype, methods);
    meta.NEED = true;
  } else {
    C = wrapper(function (target, iterable) {
      anInstance(target, C, NAME, '_c');
      target._c = new Base();
      if (iterable != undefined) forOf(iterable, IS_MAP, target[ADDER], target);
    });
    each('add,clear,delete,forEach,get,has,set,keys,values,entries,toJSON'.split(','), function (KEY) {
      var IS_ADDER = KEY == 'add' || KEY == 'set';
      if (KEY in proto && !(IS_WEAK && KEY == 'clear')) hide(C.prototype, KEY, function (a, b) {
        anInstance(this, C, KEY);
        if (!IS_ADDER && IS_WEAK && !isObject(a)) return KEY == 'get' ? undefined : false;
        var result = this._c[KEY](a === 0 ? 0 : a, b);
        return IS_ADDER ? this : result;
      });
    });
    IS_WEAK || dP(C.prototype, 'size', {
      get: function () {
        return this._c.size;
      }
    });
  }

  setToStringTag(C, NAME);

  O[NAME] = C;
  $export($export.G + $export.W + $export.F, O);

  if (!IS_WEAK) common.setStrong(C, NAME, IS_MAP);

  return C;
};


/***/ }),
/* 124 */
/***/ (function(module, exports, __webpack_require__) {

// https://tc39.github.io/proposal-setmap-offrom/#sec-weakmap.of
__webpack_require__(125)('WeakMap');


/***/ }),
/* 125 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://tc39.github.io/proposal-setmap-offrom/
var $export = __webpack_require__(2);

module.exports = function (COLLECTION) {
  $export($export.S, COLLECTION, { of: function of() {
    var length = arguments.length;
    var A = new Array(length);
    while (length--) A[length] = arguments[length];
    return new this(A);
  } });
};


/***/ }),
/* 126 */
/***/ (function(module, exports, __webpack_require__) {

// https://tc39.github.io/proposal-setmap-offrom/#sec-weakmap.from
__webpack_require__(127)('WeakMap');


/***/ }),
/* 127 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://tc39.github.io/proposal-setmap-offrom/
var $export = __webpack_require__(2);
var aFunction = __webpack_require__(59);
var ctx = __webpack_require__(17);
var forOf = __webpack_require__(51);

module.exports = function (COLLECTION) {
  $export($export.S, COLLECTION, { from: function from(source /* , mapFn, thisArg */) {
    var mapFn = arguments[1];
    var mapping, A, n, cb;
    aFunction(this);
    mapping = mapFn !== undefined;
    if (mapping) aFunction(mapFn);
    if (source == undefined) return new this();
    A = [];
    if (mapping) {
      n = 0;
      cb = ctx(mapFn, arguments[2], 2);
      forOf(source, false, function (nextItem) {
        A.push(cb(nextItem, n++));
      });
    } else {
      forOf(source, false, A.push, A);
    }
    return new this(A);
  } });
};


/***/ }),
/* 128 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(129);
var $Object = __webpack_require__(0).Object;
module.exports = function defineProperty(it, key, desc) {
  return $Object.defineProperty(it, key, desc);
};


/***/ }),
/* 129 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(2);
// 19.1.2.4 / 15.2.3.6 Object.defineProperty(O, P, Attributes)
$export($export.S + $export.F * !__webpack_require__(9), 'Object', { defineProperty: __webpack_require__(6).f });


/***/ }),
/* 130 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(131), __esModule: true };

/***/ }),
/* 131 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(132);
module.exports = __webpack_require__(0).Object.assign;


/***/ }),
/* 132 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.3.1 Object.assign(target, source)
var $export = __webpack_require__(2);

$export($export.S + $export.F, 'Object', { assign: __webpack_require__(74) });


/***/ }),
/* 133 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(134), __esModule: true };

/***/ }),
/* 134 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(135);
var $Object = __webpack_require__(0).Object;
module.exports = function getOwnPropertyDescriptor(it, key) {
  return $Object.getOwnPropertyDescriptor(it, key);
};


/***/ }),
/* 135 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.6 Object.getOwnPropertyDescriptor(O, P)
var toIObject = __webpack_require__(12);
var $getOwnPropertyDescriptor = __webpack_require__(70).f;

__webpack_require__(55)('getOwnPropertyDescriptor', function () {
  return function getOwnPropertyDescriptor(it, key) {
    return $getOwnPropertyDescriptor(toIObject(it), key);
  };
});


/***/ }),
/* 136 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(137);
module.exports = __webpack_require__(0).Object.keys;


/***/ }),
/* 137 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.14 Object.keys(O)
var toObject = __webpack_require__(15);
var $keys = __webpack_require__(19);

__webpack_require__(55)('keys', function () {
  return function keys(it) {
    return $keys(toObject(it));
  };
});


/***/ }),
/* 138 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export get_Zero */
/* unused harmony export get_One */
/* unused harmony export compare */
/* unused harmony export equals */
/* unused harmony export abs */
/* unused harmony export round */
/* unused harmony export ceil */
/* unused harmony export floor */
/* unused harmony export pow */
/* unused harmony export sqrt */
/* unused harmony export op_Subtraction */
/* unused harmony export op_Modulus */
/* unused harmony export op_Addition */
/* unused harmony export op_Division */
/* unused harmony export op_Multiply */
/* unused harmony export op_UnaryNegation */
/* unused harmony export toString */
/* unused harmony export parse */
/* unused harmony export tryParse */
/* unused harmony export toNumber */
/* unused harmony export getBytes */
/* unused harmony export fromBytes */
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__lib_big__ = __webpack_require__(139);

/* harmony default export */ __webpack_exports__["a"] = (__WEBPACK_IMPORTED_MODULE_0__lib_big__["a" /* default */]);
var get_Zero = new __WEBPACK_IMPORTED_MODULE_0__lib_big__["a" /* default */](0);
var get_One = new __WEBPACK_IMPORTED_MODULE_0__lib_big__["a" /* default */](1);
function compare(x, y) {
    return x.cmp(y);
}
function equals(x, y) {
    return !x.cmp(y);
}
function abs(x) {
    return x.abs();
}
function round(x) {
    return x.round(0, x.cmp(0) >= 0 ? 1 /* ROUND_HALF_UP */ : 2 /* ROUND_HALF_EVEN */);
}
function ceil(x) {
    return x.round(0, x.cmp(0) >= 0 ? 3 /* ROUND_UP */ : 0 /* ROUND_DOWN */);
}
function floor(x) {
    return x.round(0, x.cmp(0) >= 0 ? 0 /* ROUND_DOWN */ : 3 /* ROUND_UP */);
}
function pow(x, n) {
    return x.pow(n);
}
function sqrt(x) {
    return x.sqrt();
}
function op_Subtraction(x, y) {
    return x.sub(y);
}
function op_Modulus(x, y) {
    return x.mod(y);
}
function op_Addition(x, y) {
    return x.add(y);
}
function op_Division(x, y) {
    return x.div(y);
}
function op_Multiply(x, y) {
    return x.mul(y);
}
function op_UnaryNegation(x) {
    var x2 = new __WEBPACK_IMPORTED_MODULE_0__lib_big__["a" /* default */](x);
    x2.s = -x2.s || 0;
    return x2;
}
function toString(x) {
    return x.toString();
}
function parse(str) {
    return new __WEBPACK_IMPORTED_MODULE_0__lib_big__["a" /* default */](str.trim());
}
function tryParse(str, defaultValue) {
    try {
        return [true, new __WEBPACK_IMPORTED_MODULE_0__lib_big__["a" /* default */](str.trim())];
    } catch (_a) {
        return [false, defaultValue];
    }
}
function toNumber(x) {
    return +x;
}
// tslint:disable
// From https://github.com/bridgedotnet/Bridge/blob/e99e7eab5eda0f9ef74e11fbc3aebd3c24e8c0b1/Bridge/Resources/Decimal.js#L516
// https://github.com/bridgedotnet/Bridge/blob/master/LICENSE.md
// tslint:enable
function getBytes(x) {
    var s = x.s;
    var e = x.e;
    var d = x.c;
    var bytes = new Uint8Array(23);
    bytes[0] = s & 255;
    bytes[1] = e;
    if (d && d.length > 0) {
        bytes[2] = d.length * 4;
        for (var i = 0; i < d.length; i++) {
            bytes[i * 4 + 3] = d[i] & 255;
            bytes[i * 4 + 4] = d[i] >> 8 & 255;
            bytes[i * 4 + 5] = d[i] >> 16 & 255;
            bytes[i * 4 + 6] = d[i] >> 24 & 255;
        }
    } else {
        bytes[2] = 0;
    }
    return bytes;
}
function fromBytes(bytes) {
    var value = new __WEBPACK_IMPORTED_MODULE_0__lib_big__["a" /* default */](0);
    var s = bytes[0] & 255;
    var e = bytes[1];
    var ln = bytes[2];
    var d = [];
    value.s = s;
    value.e = e;
    if (ln > 0) {
        for (var i = 3; i < ln + 3;) {
            d.push(bytes[i] | bytes[i + 1] << 8 | bytes[i + 2] << 16 | bytes[i + 3] << 24);
            i = i + 4;
        }
    }
    value.c = d;
    return value;
}

/***/ }),
/* 139 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export Big */
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__Util__ = __webpack_require__(3);
// https://github.com/MikeMcl/big.js/blob/01b3ce3a6b0ba7b42442ea48ec4ffc88d1669ec4/big.mjs
/* tslint:disable */

// The shared prototype object.
var P = {
    GetHashCode: function GetHashCode() {
        return Object(__WEBPACK_IMPORTED_MODULE_0__Util__["b" /* combineHashCodes */])([this.s, this.e].concat(this.c));
    },
    Equals: function Equals(x) {
        return !this.cmp(x);
    },
    CompareTo: function CompareTo(x) {
        return this.cmp(x);
    }
};
/*
 *  big.js v5.2.2
 *  A small, fast, easy-to-use library for arbitrary-precision decimal arithmetic.
 *  Copyright (c) 2018 Michael Mclaughlin <M8ch88l@gmail.com>
 *  https://github.com/MikeMcl/big.js/LICENCE
 */
/************************************** EDITABLE DEFAULTS *****************************************/
// The default values below must be integers within the stated ranges.
/*
 * The maximum number of decimal places (DP) of the results of operations involving division:
 * div and sqrt, and pow with negative exponents.
 */
var DP = 20,
    // 0 to MAX_DP
/*
 * The rounding mode (RM) used when rounding to the above decimal places.
 *
 *  0  Towards zero (i.e. truncate, no rounding).       (ROUND_DOWN)
 *  1  To nearest neighbour. If equidistant, round up.  (ROUND_HALF_UP)
 *  2  To nearest neighbour. If equidistant, to even.   (ROUND_HALF_EVEN)
 *  3  Away from zero.                                  (ROUND_UP)
 */
RM = 1,
    // 0, 1, 2 or 3
// The maximum value of DP and Big.DP.
MAX_DP = 1E6,
    // 0 to 1000000
// The maximum magnitude of the exponent argument to the pow method.
MAX_POWER = 1E6,
    // 1 to 1000000
/*
 * The negative exponent (NE) at and beneath which toString returns exponential notation.
 * (JavaScript numbers: -7)
 * -1000000 is the minimum recommended exponent value of a Big.
 */
NE = -7,
    // 0 to -1000000
/*
 * The positive exponent (PE) at and above which toString returns exponential notation.
 * (JavaScript numbers: 21)
 * 1000000 is the maximum recommended exponent value of a Big.
 * (This limit is not enforced or checked.)
 */
PE = 21,
    // 0 to 1000000
/**************************************************************************************************/
// Error messages.
NAME = "[big.js] ",
    INVALID = NAME + "Invalid ",
    INVALID_DP = INVALID + "decimal places",
    INVALID_RM = INVALID + "rounding mode",
    DIV_BY_ZERO = NAME + "Division by zero",
    UNDEFINED = void 0,
    NUMERIC = /^-?(\d+(\.\d*)?|\.\d+)(e[+-]?\d+)?$/i;
/*
 * Create and return a Big constructor.
 *
 */
function _Big_() {
    /*
     * The Big constructor and exported function.
     * Create and return a new instance of a Big number object.
     *
     * n {number|string|Big} A numeric value.
     */
    function Big(n) {
        var x = this;
        // Enable constructor usage without new.
        if (!(x instanceof Big)) return n === UNDEFINED ? _Big_() : new Big(n);
        // Duplicate.
        if (n instanceof Big) {
            x.s = n.s;
            x.e = n.e;
            x.c = n.c.slice();
        } else {
            parse(x, n);
        }
        /*
         * Retain a reference to this Big constructor, and shadow Big.prototype.constructor which
         * points to Object.
         */
        x.constructor = Big;
    }
    Big.prototype = P;
    Big.DP = DP;
    Big.RM = RM;
    Big.NE = NE;
    Big.PE = PE;
    Big.version = "5.2.2";
    return Big;
}
/*
 * Parse the number or string value passed to a Big constructor.
 *
 * x {Big} A Big number instance.
 * n {number|string} A numeric value.
 */
function parse(x, n) {
    var e, i, nl;
    // Minus zero?
    if (n === 0 && 1 / n < 0) n = "-0";else if (!NUMERIC.test(n += "")) throw Error(INVALID + "number");
    // Determine sign.
    x.s = n.charAt(0) == "-" ? (n = n.slice(1), -1) : 1;
    // Decimal point?
    if ((e = n.indexOf(".")) > -1) n = n.replace(".", "");
    // Exponential form?
    if ((i = n.search(/e/i)) > 0) {
        // Determine exponent.
        if (e < 0) e = i;
        e += +n.slice(i + 1);
        n = n.substring(0, i);
    } else if (e < 0) {
        // Integer.
        e = n.length;
    }
    nl = n.length;
    // Determine leading zeros.
    for (i = 0; i < nl && n.charAt(i) == "0";) {
        ++i;
    }if (i == nl) {
        // Zero.
        x.c = [x.e = 0];
    } else {
        // Determine trailing zeros.
        for (; nl > 0 && n.charAt(--nl) == "0";) {}
        x.e = e - i - 1;
        x.c = [];
        // Convert string to array of digits without leading/trailing zeros.
        for (e = 0; i <= nl;) {
            x.c[e++] = +n.charAt(i++);
        }
    }
    return x;
}
/*
 * Round Big x to a maximum of dp decimal places using rounding mode rm.
 * Called by stringify, P.div, P.round and P.sqrt.
 *
 * x {Big} The Big to round.
 * dp {number} Integer, 0 to MAX_DP inclusive.
 * rm {number} 0, 1, 2 or 3 (DOWN, HALF_UP, HALF_EVEN, UP)
 * [more] {boolean} Whether the result of division was truncated.
 */
function round(x, dp, rm, more) {
    var xc = x.c,
        i = x.e + dp + 1;
    if (i < xc.length) {
        if (rm === 1) {
            // xc[i] is the digit after the digit that may be rounded up.
            more = xc[i] >= 5;
        } else if (rm === 2) {
            more = xc[i] > 5 || xc[i] == 5 && (more || i < 0 || xc[i + 1] !== UNDEFINED || xc[i - 1] & 1);
        } else if (rm === 3) {
            more = more || !!xc[0];
        } else {
            more = false;
            if (rm !== 0) throw Error(INVALID_RM);
        }
        if (i < 1) {
            xc.length = 1;
            if (more) {
                // 1, 0.1, 0.01, 0.001, 0.0001 etc.
                x.e = -dp;
                xc[0] = 1;
            } else {
                // Zero.
                xc[0] = x.e = 0;
            }
        } else {
            // Remove any digits after the required decimal places.
            xc.length = i--;
            // Round up?
            if (more) {
                // Rounding up may mean the previous digit has to be rounded up.
                for (; ++xc[i] > 9;) {
                    xc[i] = 0;
                    if (!i--) {
                        ++x.e;
                        xc.unshift(1);
                    }
                }
            }
            // Remove trailing zeros.
            for (i = xc.length; !xc[--i];) {
                xc.pop();
            }
        }
    } else if (rm < 0 || rm > 3 || rm !== ~~rm) {
        throw Error(INVALID_RM);
    }
    return x;
}
/*
 * Return a string representing the value of Big x in normal or exponential notation.
 * Handles P.toExponential, P.toFixed, P.toJSON, P.toPrecision, P.toString and P.valueOf.
 *
 * x {Big}
 * id? {number} Caller id.
 *         1 toExponential
 *         2 toFixed
 *         3 toPrecision
 *         4 valueOf
 * n? {number|undefined} Caller's argument.
 * k? {number|undefined}
 */
function stringify(x, id, n, k) {
    var e,
        s,
        Big = x.constructor,
        z = !x.c[0];
    if (n !== UNDEFINED) {
        if (n !== ~~n || n < (id == 3) || n > MAX_DP) {
            throw Error(id == 3 ? INVALID + "precision" : INVALID_DP);
        }
        x = new Big(x);
        // The index of the digit that may be rounded up.
        n = k - x.e;
        // Round?
        if (x.c.length > ++k) round(x, n, Big.RM);
        // toFixed: recalculate k as x.e may have changed if value rounded up.
        if (id == 2) k = x.e + n + 1;
        // Append zeros?
        for (; x.c.length < k;) {
            x.c.push(0);
        }
    }
    e = x.e;
    s = x.c.join("");
    n = s.length;
    // Exponential notation?
    if (id != 2 && (id == 1 || id == 3 && k <= e || e <= Big.NE || e >= Big.PE)) {
        s = s.charAt(0) + (n > 1 ? "." + s.slice(1) : "") + (e < 0 ? "e" : "e+") + e;
        // Normal notation.
    } else if (e < 0) {
        for (; ++e;) {
            s = "0" + s;
        }s = "0." + s;
    } else if (e > 0) {
        if (++e > n) for (e -= n; e--;) {
            s += "0";
        } else if (e < n) s = s.slice(0, e) + "." + s.slice(e);
    } else if (n > 1) {
        s = s.charAt(0) + "." + s.slice(1);
    }
    return x.s < 0 && (!z || id == 4) ? "-" + s : s;
}
// Prototype/instance methods
/*
 * Return a new Big whose value is the absolute value of this Big.
 */
P.abs = function () {
    var x = new this.constructor(this);
    x.s = 1;
    return x;
};
/*
 * Return 1 if the value of this Big is greater than the value of Big y,
 *       -1 if the value of this Big is less than the value of Big y, or
 *        0 if they have the same value.
*/
P.cmp = function (y) {
    var isneg,
        x = this,
        xc = x.c,
        yc = (y = new x.constructor(y)).c,
        i = x.s,
        j = y.s,
        k = x.e,
        l = y.e;
    // Either zero?
    if (!xc[0] || !yc[0]) return !xc[0] ? !yc[0] ? 0 : -j : i;
    // Signs differ?
    if (i != j) return i;
    isneg = i < 0;
    // Compare exponents.
    if (k != l) return k > l ^ isneg ? 1 : -1;
    j = (k = xc.length) < (l = yc.length) ? k : l;
    // Compare digit by digit.
    for (i = -1; ++i < j;) {
        if (xc[i] != yc[i]) return xc[i] > yc[i] ^ isneg ? 1 : -1;
    }
    // Compare lengths.
    return k == l ? 0 : k > l ^ isneg ? 1 : -1;
};
/*
 * Return a new Big whose value is the value of this Big divided by the value of Big y, rounded,
 * if necessary, to a maximum of Big.DP decimal places using rounding mode Big.RM.
 */
P.div = function (y) {
    var x = this,
        Big = x.constructor,
        a = x.c,
        // dividend
    b = (y = new Big(y)).c,
        // divisor
    k = x.s == y.s ? 1 : -1,
        dp = Big.DP;
    if (dp !== ~~dp || dp < 0 || dp > MAX_DP) throw Error(INVALID_DP);
    // Divisor is zero?
    if (!b[0]) throw Error(DIV_BY_ZERO);
    // Dividend is 0? Return +-0.
    if (!a[0]) return new Big(k * 0);
    var bl,
        bt,
        n,
        cmp,
        ri,
        bz = b.slice(),
        ai = bl = b.length,
        al = a.length,
        r = a.slice(0, bl),
        // remainder
    rl = r.length,
        q = y,
        // quotient
    qc = q.c = [],
        qi = 0,
        d = dp + (q.e = x.e - y.e) + 1; // number of digits of the result
    q.s = k;
    k = d < 0 ? 0 : d;
    // Create version of divisor with leading zero.
    bz.unshift(0);
    // Add zeros to make remainder as long as divisor.
    for (; rl++ < bl;) {
        r.push(0);
    }do {
        // n is how many times the divisor goes into current remainder.
        for (n = 0; n < 10; n++) {
            // Compare divisor and remainder.
            if (bl != (rl = r.length)) {
                cmp = bl > rl ? 1 : -1;
            } else {
                for (ri = -1, cmp = 0; ++ri < bl;) {
                    if (b[ri] != r[ri]) {
                        cmp = b[ri] > r[ri] ? 1 : -1;
                        break;
                    }
                }
            }
            // If divisor < remainder, subtract divisor from remainder.
            if (cmp < 0) {
                // Remainder can't be more than 1 digit longer than divisor.
                // Equalise lengths using divisor with extra leading zero?
                for (bt = rl == bl ? b : bz; rl;) {
                    if (r[--rl] < bt[rl]) {
                        ri = rl;
                        for (; ri && !r[--ri];) {
                            r[ri] = 9;
                        }--r[ri];
                        r[rl] += 10;
                    }
                    r[rl] -= bt[rl];
                }
                for (; !r[0];) {
                    r.shift();
                }
            } else {
                break;
            }
        }
        // Add the digit n to the result array.
        qc[qi++] = cmp ? n : ++n;
        // Update the remainder.
        if (r[0] && cmp) r[rl] = a[ai] || 0;else r = [a[ai]];
    } while ((ai++ < al || r[0] !== UNDEFINED) && k--);
    // Leading zero? Do not remove if result is simply zero (qi == 1).
    if (!qc[0] && qi != 1) {
        // There can't be more than one zero.
        qc.shift();
        q.e--;
    }
    // Round?
    if (qi > d) round(q, dp, Big.RM, r[0] !== UNDEFINED);
    return q;
};
/*
 * Return true if the value of this Big is equal to the value of Big y, otherwise return false.
 */
P.eq = function (y) {
    return !this.cmp(y);
};
/*
 * Return true if the value of this Big is greater than the value of Big y, otherwise return
 * false.
 */
P.gt = function (y) {
    return this.cmp(y) > 0;
};
/*
 * Return true if the value of this Big is greater than or equal to the value of Big y, otherwise
 * return false.
 */
P.gte = function (y) {
    return this.cmp(y) > -1;
};
/*
 * Return true if the value of this Big is less than the value of Big y, otherwise return false.
 */
P.lt = function (y) {
    return this.cmp(y) < 0;
};
/*
 * Return true if the value of this Big is less than or equal to the value of Big y, otherwise
 * return false.
 */
P.lte = function (y) {
    return this.cmp(y) < 1;
};
/*
 * Return a new Big whose value is the value of this Big minus the value of Big y.
 */
P.minus = P.sub = function (y) {
    var i,
        j,
        t,
        xlty,
        x = this,
        Big = x.constructor,
        a = x.s,
        b = (y = new Big(y)).s;
    // Signs differ?
    if (a != b) {
        y.s = -b;
        return x.plus(y);
    }
    var xc = x.c.slice(),
        xe = x.e,
        yc = y.c,
        ye = y.e;
    // Either zero?
    if (!xc[0] || !yc[0]) {
        // y is non-zero? x is non-zero? Or both are zero.
        return yc[0] ? (y.s = -b, y) : new Big(xc[0] ? x : 0);
    }
    // Determine which is the bigger number. Prepend zeros to equalise exponents.
    if (a = xe - ye) {
        if (xlty = a < 0) {
            a = -a;
            t = xc;
        } else {
            ye = xe;
            t = yc;
        }
        t.reverse();
        for (b = a; b--;) {
            t.push(0);
        }t.reverse();
    } else {
        // Exponents equal. Check digit by digit.
        j = ((xlty = xc.length < yc.length) ? xc : yc).length;
        for (a = b = 0; b < j; b++) {
            if (xc[b] != yc[b]) {
                xlty = xc[b] < yc[b];
                break;
            }
        }
    }
    // x < y? Point xc to the array of the bigger number.
    if (xlty) {
        t = xc;
        xc = yc;
        yc = t;
        y.s = -y.s;
    }
    /*
     * Append zeros to xc if shorter. No need to add zeros to yc if shorter as subtraction only
     * needs to start at yc.length.
     */
    if ((b = (j = yc.length) - (i = xc.length)) > 0) for (; b--;) {
        xc[i++] = 0;
    } // Subtract yc from xc.
    for (b = i; j > a;) {
        if (xc[--j] < yc[j]) {
            for (i = j; i && !xc[--i];) {
                xc[i] = 9;
            }--xc[i];
            xc[j] += 10;
        }
        xc[j] -= yc[j];
    }
    // Remove trailing zeros.
    for (; xc[--b] === 0;) {
        xc.pop();
    } // Remove leading zeros and adjust exponent accordingly.
    for (; xc[0] === 0;) {
        xc.shift();
        --ye;
    }
    if (!xc[0]) {
        // n - n = +0
        y.s = 1;
        // Result must be zero.
        xc = [ye = 0];
    }
    y.c = xc;
    y.e = ye;
    return y;
};
/*
 * Return a new Big whose value is the value of this Big modulo the value of Big y.
 */
P.mod = function (y) {
    var ygtx,
        x = this,
        Big = x.constructor,
        a = x.s,
        b = (y = new Big(y)).s;
    if (!y.c[0]) throw Error(DIV_BY_ZERO);
    x.s = y.s = 1;
    ygtx = y.cmp(x) == 1;
    x.s = a;
    y.s = b;
    if (ygtx) return new Big(x);
    a = Big.DP;
    b = Big.RM;
    Big.DP = Big.RM = 0;
    x = x.div(y);
    Big.DP = a;
    Big.RM = b;
    return this.minus(x.times(y));
};
/*
 * Return a new Big whose value is the value of this Big plus the value of Big y.
 */
P.plus = P.add = function (y) {
    var t,
        x = this,
        Big = x.constructor,
        a = x.s,
        b = (y = new Big(y)).s;
    // Signs differ?
    if (a != b) {
        y.s = -b;
        return x.minus(y);
    }
    var xe = x.e,
        xc = x.c,
        ye = y.e,
        yc = y.c;
    // Either zero? y is non-zero? x is non-zero? Or both are zero.
    if (!xc[0] || !yc[0]) return yc[0] ? y : new Big(xc[0] ? x : a * 0);
    xc = xc.slice();
    // Prepend zeros to equalise exponents.
    // Note: reverse faster than unshifts.
    if (a = xe - ye) {
        if (a > 0) {
            ye = xe;
            t = yc;
        } else {
            a = -a;
            t = xc;
        }
        t.reverse();
        for (; a--;) {
            t.push(0);
        }t.reverse();
    }
    // Point xc to the longer array.
    if (xc.length - yc.length < 0) {
        t = yc;
        yc = xc;
        xc = t;
    }
    a = yc.length;
    // Only start adding at yc.length - 1 as the further digits of xc can be left as they are.
    for (b = 0; a; xc[a] %= 10) {
        b = (xc[--a] = xc[a] + yc[a] + b) / 10 | 0;
    } // No need to check for zero, as +x + +y != 0 && -x + -y != 0
    if (b) {
        xc.unshift(b);
        ++ye;
    }
    // Remove trailing zeros.
    for (a = xc.length; xc[--a] === 0;) {
        xc.pop();
    }y.c = xc;
    y.e = ye;
    return y;
};
/*
 * Return a Big whose value is the value of this Big raised to the power n.
 * If n is negative, round to a maximum of Big.DP decimal places using rounding
 * mode Big.RM.
 *
 * n {number} Integer, -MAX_POWER to MAX_POWER inclusive.
 */
P.pow = function (n) {
    var x = this,
        one = new x.constructor(1),
        y = one,
        isneg = n < 0;
    if (n !== ~~n || n < -MAX_POWER || n > MAX_POWER) throw Error(INVALID + "exponent");
    if (isneg) n = -n;
    for (;;) {
        if (n & 1) y = y.times(x);
        n >>= 1;
        if (!n) break;
        x = x.times(x);
    }
    return isneg ? one.div(y) : y;
};
/*
 * Return a new Big whose value is the value of this Big rounded using rounding mode rm
 * to a maximum of dp decimal places, or, if dp is negative, to an integer which is a
 * multiple of 10**-dp.
 * If dp is not specified, round to 0 decimal places.
 * If rm is not specified, use Big.RM.
 *
 * dp? {number} Integer, -MAX_DP to MAX_DP inclusive.
 * rm? 0, 1, 2 or 3 (ROUND_DOWN, ROUND_HALF_UP, ROUND_HALF_EVEN, ROUND_UP)
 */
P.round = function (dp, rm) {
    var Big = this.constructor;
    if (dp === UNDEFINED) dp = 0;else if (dp !== ~~dp || dp < -MAX_DP || dp > MAX_DP) throw Error(INVALID_DP);
    return round(new Big(this), dp, rm === UNDEFINED ? Big.RM : rm);
};
/*
 * Return a new Big whose value is the square root of the value of this Big, rounded, if
 * necessary, to a maximum of Big.DP decimal places using rounding mode Big.RM.
 */
P.sqrt = function () {
    var r,
        c,
        t,
        x = this,
        Big = x.constructor,
        s = x.s,
        e = x.e,
        half = new Big(0.5);
    // Zero?
    if (!x.c[0]) return new Big(x);
    // Negative?
    if (s < 0) throw Error(NAME + "No square root");
    // Estimate.
    s = Math.sqrt(x + "");
    // Math.sqrt underflow/overflow?
    // Re-estimate: pass x coefficient to Math.sqrt as integer, then adjust the result exponent.
    if (s === 0 || s === 1 / 0) {
        c = x.c.join("");
        if (!(c.length + e & 1)) c += "0";
        s = Math.sqrt(c);
        e = ((e + 1) / 2 | 0) - (e < 0 || e & 1);
        r = new Big((s == 1 / 0 ? "1e" : (s = s.toExponential()).slice(0, s.indexOf("e") + 1)) + e);
    } else {
        r = new Big(s);
    }
    e = r.e + (Big.DP += 4);
    // Newton-Raphson iteration.
    do {
        t = r;
        r = half.times(t.plus(x.div(t)));
    } while (t.c.slice(0, e).join("") !== r.c.slice(0, e).join(""));
    return round(r, Big.DP -= 4, Big.RM);
};
/*
 * Return a new Big whose value is the value of this Big times the value of Big y.
 */
P.times = P.mul = function (y) {
    var c,
        x = this,
        Big = x.constructor,
        xc = x.c,
        yc = (y = new Big(y)).c,
        a = xc.length,
        b = yc.length,
        i = x.e,
        j = y.e;
    // Determine sign of result.
    y.s = x.s == y.s ? 1 : -1;
    // Return signed 0 if either 0.
    if (!xc[0] || !yc[0]) return new Big(y.s * 0);
    // Initialise exponent of result as x.e + y.e.
    y.e = i + j;
    // If array xc has fewer digits than yc, swap xc and yc, and lengths.
    if (a < b) {
        c = xc;
        xc = yc;
        yc = c;
        j = a;
        a = b;
        b = j;
    }
    // Initialise coefficient array of result with zeros.
    for (c = new Array(j = a + b); j--;) {
        c[j] = 0;
    } // Multiply.
    // i is initially xc.length.
    for (i = b; i--;) {
        b = 0;
        // a is yc.length.
        for (j = a + i; j > i;) {
            // Current sum of products at this digit position, plus carry.
            b = c[j] + yc[i] * xc[j - i - 1] + b;
            c[j--] = b % 10;
            // carry
            b = b / 10 | 0;
        }
        c[j] = (c[j] + b) % 10;
    }
    // Increment result exponent if there is a final carry, otherwise remove leading zero.
    if (b) ++y.e;else c.shift();
    // Remove trailing zeros.
    for (i = c.length; !c[--i];) {
        c.pop();
    }y.c = c;
    return y;
};
/*
 * Return a string representing the value of this Big in exponential notation to dp fixed decimal
 * places and rounded using Big.RM.
 *
 * dp? {number} Integer, 0 to MAX_DP inclusive.
 */
P.toExponential = function (dp) {
    return stringify(this, 1, dp, dp);
};
/*
 * Return a string representing the value of this Big in normal notation to dp fixed decimal
 * places and rounded using Big.RM.
 *
 * dp? {number} Integer, 0 to MAX_DP inclusive.
 *
 * (-0).toFixed(0) is '0', but (-0.1).toFixed(0) is '-0'.
 * (-0).toFixed(1) is '0.0', but (-0.01).toFixed(1) is '-0.0'.
 */
P.toFixed = function (dp) {
    return stringify(this, 2, dp, this.e + dp);
};
/*
 * Return a string representing the value of this Big rounded to sd significant digits using
 * Big.RM. Use exponential notation if sd is less than the number of digits necessary to represent
 * the integer part of the value in normal notation.
 *
 * sd {number} Integer, 1 to MAX_DP inclusive.
 */
P.toPrecision = function (sd) {
    return stringify(this, 3, sd, sd - 1);
};
/*
 * Return a string representing the value of this Big.
 * Return exponential notation if this Big has a positive exponent equal to or greater than
 * Big.PE, or a negative exponent equal to or less than Big.NE.
 * Omit the sign for negative zero.
 */
P.toString = function () {
    return stringify(this);
};
/*
 * Return a string representing the value of this Big.
 * Return exponential notation if this Big has a positive exponent equal to or greater than
 * Big.PE, or a negative exponent equal to or less than Big.NE.
 * Include the sign for negative zero.
 */
P.valueOf = P.toJSON = function () {
    return stringify(this, 4);
};
// Export
var Big = _Big_();
/* harmony default export */ __webpack_exports__["a"] = (Big);

/***/ }),
/* 140 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export create */
/* harmony export (immutable) */ __webpack_exports__["a"] = escape;
/* unused harmony export unescape */
/* unused harmony export isMatch */
/* unused harmony export match */
/* unused harmony export matches */
/* unused harmony export options */
/* unused harmony export replace */
/* unused harmony export split */
function create(pattern, options) {
    // Supported RegexOptions
    // * IgnoreCase:  0x0001
    // * Multiline:   0x0002
    // * ECMAScript:  0x0100 (ignored)
    if ((options & ~(1 ^ 2 ^ 256)) !== 0) {
        throw new Error("RegexOptions only supports: IgnoreCase, Multiline and ECMAScript");
    }
    var flags = "g";
    flags += options & 1 ? "i" : ""; // 0x0001 RegexOptions.IgnoreCase
    flags += options & 2 ? "m" : "";
    return new RegExp(pattern, flags);
}
// From http://stackoverflow.com/questions/3446170/escape-string-for-use-in-javascript-regex
function escape(str) {
    return str.replace(/[\-\[\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
}
function unescape(str) {
    return str.replace(/\\([\-\[\/\{\}\(\)\*\+\?\.\\\^\$\|])/g, "$1");
}
function isMatch(str, pattern) {
    var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0;

    var reg = void 0;
    reg = str instanceof RegExp ? (reg = str, str = pattern, reg.lastIndex = options, reg) : reg = create(pattern, options);
    return reg.test(str);
}
function match(str, pattern) {
    var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0;

    var reg = void 0;
    reg = str instanceof RegExp ? (reg = str, str = pattern, reg.lastIndex = options, reg) : reg = create(pattern, options);
    return reg.exec(str);
}
function matches(str, pattern) {
    var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0;

    var reg = void 0;
    reg = str instanceof RegExp ? (reg = str, str = pattern, reg.lastIndex = options, reg) : reg = create(pattern, options);
    if (!reg.global) {
        throw new Error("Non-global RegExp"); // Prevent infinite loop
    }
    var m = reg.exec(str);
    var matches = [];
    while (m !== null) {
        matches.push(m);
        m = reg.exec(str);
    }
    return matches;
}
function options(reg) {
    var options = 256; // ECMAScript
    options |= reg.ignoreCase ? 1 : 0;
    options |= reg.multiline ? 2 : 0;
    return options;
}
function replace(reg, input, replacement, limit) {
    var offset = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : 0;

    function replacer() {
        var res = arguments[0];
        if (limit !== 0) {
            limit--;
            var _match = [];
            var len = arguments.length;
            for (var i = 0; i < len - 2; i++) {
                _match.push(arguments[i]);
            }
            _match.index = arguments[len - 2];
            _match.input = arguments[len - 1];
            res = replacement(_match);
        }
        return res;
    }
    if (typeof reg === "string") {
        var tmp = reg;
        reg = create(input, limit);
        input = tmp;
        limit = undefined;
    }
    if (typeof replacement === "function") {
        limit = limit == null ? -1 : limit;
        return input.substring(0, offset) + input.substring(offset).replace(reg, replacer);
    } else {
        // $0 doesn't work with JS regex, see #1155
        replacement = replacement.replace(/\$0/g, function (s) {
            return "$&";
        });
        if (limit != null) {
            var m = void 0;
            var sub1 = input.substring(offset);
            var _matches = matches(reg, sub1);
            var sub2 = matches.length > limit ? (m = _matches[limit - 1], sub1.substring(0, m.index + m[0].length)) : sub1;
            return input.substring(0, offset) + sub2.replace(reg, replacement) + input.substring(offset + sub2.length);
        } else {
            return input.replace(reg, replacement);
        }
    }
}
function split(reg, input, limit) {
    var offset = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 0;

    if (typeof reg === "string") {
        var tmp = reg;
        reg = create(input, limit);
        input = tmp;
        limit = undefined;
    }
    input = input.substring(offset);
    return input.split(reg, limit);
}

/***/ }),
/* 141 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export head */
/* unused harmony export tryHead */
/* harmony export (immutable) */ __webpack_exports__["f"] = tail;
/* unused harmony export last */
/* unused harmony export tryLast */
/* unused harmony export compareWith */
/* unused harmony export foldIndexedAux */
/* unused harmony export foldIndexed */
/* unused harmony export fold */
/* unused harmony export reverse */
/* unused harmony export foldBack */
/* unused harmony export toSeq */
/* harmony export (immutable) */ __webpack_exports__["e"] = ofSeq;
/* unused harmony export concat */
/* unused harmony export foldIndexed2Aux */
/* unused harmony export foldIndexed2 */
/* unused harmony export fold2 */
/* unused harmony export foldBack2 */
/* unused harmony export unfold */
/* unused harmony export foldIndexed3Aux */
/* unused harmony export foldIndexed3 */
/* unused harmony export fold3 */
/* unused harmony export scan */
/* unused harmony export scanBack */
/* unused harmony export length */
/* unused harmony export append */
/* unused harmony export collect */
/* harmony export (immutable) */ __webpack_exports__["c"] = map;
/* unused harmony export mapIndexed */
/* unused harmony export indexed */
/* unused harmony export map2 */
/* unused harmony export mapIndexed2 */
/* unused harmony export map3 */
/* unused harmony export mapIndexed3 */
/* unused harmony export mapFold */
/* unused harmony export mapFoldBack */
/* unused harmony export iterate */
/* unused harmony export iterate2 */
/* unused harmony export iterateIndexed */
/* unused harmony export iterateIndexed2 */
/* harmony export (immutable) */ __webpack_exports__["d"] = ofArray;
/* unused harmony export empty */
/* unused harmony export isEmpty */
/* unused harmony export tryPickIndexedAux */
/* unused harmony export tryPickIndexed */
/* unused harmony export tryPick */
/* unused harmony export pick */
/* unused harmony export tryFindIndexed */
/* unused harmony export tryFind */
/* unused harmony export findIndexed */
/* unused harmony export find */
/* unused harmony export findBack */
/* unused harmony export tryFindBack */
/* unused harmony export tryFindIndex */
/* unused harmony export tryFindIndexBack */
/* unused harmony export findIndex */
/* unused harmony export findIndexBack */
/* unused harmony export item */
/* unused harmony export tryItem */
/* unused harmony export filter */
/* unused harmony export partition */
/* unused harmony export choose */
/* harmony export (immutable) */ __webpack_exports__["a"] = contains;
/* unused harmony export except */
/* unused harmony export initialize */
/* unused harmony export replicate */
/* unused harmony export reduce */
/* unused harmony export reduceBack */
/* unused harmony export forAll */
/* unused harmony export forAll2 */
/* harmony export (immutable) */ __webpack_exports__["b"] = exists;
/* unused harmony export exists2 */
/* unused harmony export unzip */
/* unused harmony export unzip3 */
/* unused harmony export zip */
/* unused harmony export zip3 */
/* unused harmony export sort */
/* unused harmony export sortBy */
/* unused harmony export sortDescending */
/* unused harmony export sortByDescending */
/* unused harmony export sortWith */
/* unused harmony export sum */
/* unused harmony export sumBy */
/* unused harmony export maxBy */
/* unused harmony export max */
/* unused harmony export minBy */
/* unused harmony export min */
/* unused harmony export average */
/* unused harmony export averageBy */
/* unused harmony export permute */
/* unused harmony export skip */
/* unused harmony export skipWhile */
/* unused harmony export takeSplitAux */
/* unused harmony export take */
/* unused harmony export takeWhile */
/* unused harmony export truncate */
/* unused harmony export splitAt */
/* unused harmony export slice */
/* unused harmony export distinctBy */
/* unused harmony export distinct */
/* unused harmony export groupBy */
/* unused harmony export countBy */
/* unused harmony export where */
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__Option__ = __webpack_require__(22);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__Types__ = __webpack_require__(16);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__Seq__ = __webpack_require__(32);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__Array__ = __webpack_require__(79);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__Util__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__Set__ = __webpack_require__(81);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__Map__ = __webpack_require__(80);








function head(_arg1) {
  if (_arg1.tail != null) {
    var x = _arg1.head;
    return x;
  } else {
    throw new Error("List was empty");
  }
}
function tryHead(_arg1$$1) {
  if (_arg1$$1.tail != null) {
    var x$$1 = _arg1$$1.head;
    return Object(__WEBPACK_IMPORTED_MODULE_0__Option__["c" /* some */])(x$$1);
  } else {
    return null;
  }
}
function tail(_arg1$$2) {
  if (_arg1$$2.tail != null) {
    var xs = _arg1$$2.tail;
    return xs;
  } else {
    throw new Error("List was empty");
  }
}
function last(_arg1$$3) {
  last: while (true) {
    if (_arg1$$3.tail != null) {
      if (_arg1$$3.tail.tail == null) {
        return _arg1$$3.head;
      } else {
        var $_arg1$$3$$2 = _arg1$$3;
        _arg1$$3 = $_arg1$$3$$2.tail;
        continue last;
      }
    } else {
      throw new Error("List was empty");
    }

    break;
  }
}
function tryLast(_arg1$$4) {
  tryLast: while (true) {
    if (_arg1$$4.tail != null) {
      if (_arg1$$4.tail.tail == null) {
        return Object(__WEBPACK_IMPORTED_MODULE_0__Option__["c" /* some */])(_arg1$$4.head);
      } else {
        var $_arg1$$4$$3 = _arg1$$4;
        _arg1$$4 = $_arg1$$4$$3.tail;
        continue tryLast;
      }
    } else {
      return null;
    }

    break;
  }
}
function compareWith(comparer, xs$$3, ys) {
  if (xs$$3 === ys) {
    return 0;
  } else {
    var loop = function loop(xs$$4, ys$$1) {
      loop: while (true) {
        var matchValue = [xs$$4, ys$$1];

        if (matchValue[0].tail != null) {
          if (matchValue[1].tail != null) {
            var matchValue$$1 = comparer(matchValue[0].head, matchValue[1].head) | 0;

            if (matchValue$$1 === 0) {
              xs$$4 = matchValue[0].tail;
              ys$$1 = matchValue[1].tail;
              continue loop;
            } else {
              var res = matchValue$$1 | 0;
              return res | 0;
            }
          } else {
            return 1;
          }
        } else if (matchValue[1].tail == null) {
          return 0;
        } else {
          return -1 | 0;
        }

        break;
      }
    };

    return loop(xs$$3, ys) | 0;
  }
}
function foldIndexedAux($arg$$7, $arg$$8, $arg$$9, $arg$$10) {
  foldIndexedAux: while (true) {
    var f = $arg$$7,
        i = $arg$$8,
        acc = $arg$$9,
        _arg1$$5 = $arg$$10;

    if (_arg1$$5.tail != null) {
      var xs$$6 = _arg1$$5.tail;
      var x$$5 = _arg1$$5.head;
      $arg$$7 = f;
      $arg$$8 = i + 1;
      $arg$$9 = f(i, acc, x$$5);
      $arg$$10 = xs$$6;
      continue foldIndexedAux;
    } else {
      return acc;
    }

    break;
  }
}
function foldIndexed(f$$1, state, xs$$7) {
  return foldIndexedAux(f$$1, 0, state, xs$$7);
}
function fold($arg$$14, $arg$$15, $arg$$16) {
  fold: while (true) {
    var f$$2 = $arg$$14,
        state$$1 = $arg$$15,
        xs$$8 = $arg$$16;

    if (xs$$8.tail != null) {
      var t = xs$$8.tail;
      var h = xs$$8.head;
      $arg$$14 = f$$2;
      $arg$$15 = f$$2(state$$1, h);
      $arg$$16 = t;
      continue fold;
    } else {
      return state$$1;
    }

    break;
  }
}
function reverse(xs$$9) {
  return fold(function (acc$$1, x$$6) {
    return new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](x$$6, acc$$1);
  }, new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](), xs$$9);
}
function foldBack(f$$3, xs$$10, state$$2) {
  return fold(function (acc$$2, x$$7) {
    return f$$3(x$$7, acc$$2);
  }, state$$2, reverse(xs$$10));
}
function toSeq(xs$$11) {
  return Object(__WEBPACK_IMPORTED_MODULE_2__Seq__["h" /* map */])(function (x$$8) {
    return x$$8;
  }, xs$$11);
}
function ofSeq(xs$$12) {
  return reverse(Object(__WEBPACK_IMPORTED_MODULE_2__Seq__["c" /* fold */])(function (acc$$3, x$$9) {
    return new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](x$$9, acc$$3);
  }, new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](), xs$$12));
}
function concat(lists) {
  return reverse(Object(__WEBPACK_IMPORTED_MODULE_2__Seq__["c" /* fold */])(function (state$$3, xs$$14) {
    return fold(function f$$4(acc$$4, x$$10) {
      return new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](x$$10, acc$$4);
    }, state$$3, xs$$14);
  }, new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](), lists));
}
function foldIndexed2Aux($arg$$20, $arg$$21, $arg$$22, $arg$$23, $arg$$24) {
  foldIndexed2Aux: while (true) {
    var f$$5 = $arg$$20,
        i$$1 = $arg$$21,
        acc$$5 = $arg$$22,
        bs = $arg$$23,
        cs = $arg$$24;
    var matchValue$$2 = [bs, cs];
    var $target$$25, x$$11, xs$$16, y$$1, ys$$3;

    if (matchValue$$2[0].tail != null) {
      if (matchValue$$2[1].tail != null) {
        $target$$25 = 1;
        x$$11 = matchValue$$2[0].head;
        xs$$16 = matchValue$$2[0].tail;
        y$$1 = matchValue$$2[1].head;
        ys$$3 = matchValue$$2[1].tail;
      } else {
        $target$$25 = 2;
      }
    } else if (matchValue$$2[1].tail == null) {
      $target$$25 = 0;
    } else {
      $target$$25 = 2;
    }

    switch ($target$$25) {
      case 0:
        {
          return acc$$5;
        }

      case 1:
        {
          $arg$$20 = f$$5;
          $arg$$21 = i$$1 + 1;
          $arg$$22 = f$$5(i$$1, acc$$5, x$$11, y$$1);
          $arg$$23 = xs$$16;
          $arg$$24 = ys$$3;
          continue foldIndexed2Aux;
        }

      case 2:
        {
          throw new Error("Lists had different lengths");
        }
    }

    break;
  }
}
function foldIndexed2(f$$6, state$$4, xs$$17, ys$$4) {
  return foldIndexed2Aux(f$$6, 0, state$$4, xs$$17, ys$$4);
}
function fold2(f$$7, state$$5, xs$$18, ys$$5) {
  return Object(__WEBPACK_IMPORTED_MODULE_2__Seq__["d" /* fold2 */])(f$$7, state$$5, xs$$18, ys$$5);
}
function foldBack2(f$$8, xs$$19, ys$$6, state$$6) {
  return Object(__WEBPACK_IMPORTED_MODULE_2__Seq__["e" /* foldBack2 */])(f$$8, xs$$19, ys$$6, state$$6);
}
function unfold(f$$9, state$$7) {
  var unfoldInner = function unfoldInner(acc$$6, state$$8) {
    unfoldInner: while (true) {
      var matchValue$$3 = f$$9(state$$8);

      if (matchValue$$3 != null) {
        var x$$12 = matchValue$$3[0];
        var state$$9 = matchValue$$3[1];
        var $acc$$6$$40 = acc$$6;
        acc$$6 = new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](x$$12, $acc$$6$$40);
        state$$8 = state$$9;
        continue unfoldInner;
      } else {
        return reverse(acc$$6);
      }

      break;
    }
  };

  return unfoldInner(new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](), state$$7);
}
function foldIndexed3Aux($arg$$41, $arg$$42, $arg$$43, $arg$$44, $arg$$45, $arg$$46) {
  foldIndexed3Aux: while (true) {
    var f$$10 = $arg$$41,
        i$$2 = $arg$$42,
        acc$$7 = $arg$$43,
        bs$$1 = $arg$$44,
        cs$$1 = $arg$$45,
        ds = $arg$$46;
    var matchValue$$4 = [bs$$1, cs$$1, ds];
    var $target$$47, x$$13, xs$$20, y$$2, ys$$7, z, zs;

    if (matchValue$$4[0].tail != null) {
      if (matchValue$$4[1].tail != null) {
        if (matchValue$$4[2].tail != null) {
          $target$$47 = 1;
          x$$13 = matchValue$$4[0].head;
          xs$$20 = matchValue$$4[0].tail;
          y$$2 = matchValue$$4[1].head;
          ys$$7 = matchValue$$4[1].tail;
          z = matchValue$$4[2].head;
          zs = matchValue$$4[2].tail;
        } else {
          $target$$47 = 2;
        }
      } else {
        $target$$47 = 2;
      }
    } else if (matchValue$$4[1].tail == null) {
      if (matchValue$$4[2].tail == null) {
        $target$$47 = 0;
      } else {
        $target$$47 = 2;
      }
    } else {
      $target$$47 = 2;
    }

    switch ($target$$47) {
      case 0:
        {
          return acc$$7;
        }

      case 1:
        {
          $arg$$41 = f$$10;
          $arg$$42 = i$$2 + 1;
          $arg$$43 = f$$10(i$$2, acc$$7, x$$13, y$$2, z);
          $arg$$44 = xs$$20;
          $arg$$45 = ys$$7;
          $arg$$46 = zs;
          continue foldIndexed3Aux;
        }

      case 2:
        {
          throw new Error("Lists had different lengths");
        }
    }

    break;
  }
}
function foldIndexed3(f$$11, seed, xs$$21, ys$$8, zs$$1) {
  return foldIndexed3Aux(f$$11, 0, seed, xs$$21, ys$$8, zs$$1);
}
function fold3(f$$12, state$$10, xs$$22, ys$$9, zs$$2) {
  return foldIndexed3(function (_arg1$$6, acc$$8, x$$14, y$$3, z$$1) {
    return f$$12(acc$$8, x$$14, y$$3, z$$1);
  }, state$$10, xs$$22, ys$$9, zs$$2);
}
function scan(f$$13, state$$11, xs$$23) {
  return ofSeq(Object(__WEBPACK_IMPORTED_MODULE_2__Seq__["j" /* scan */])(f$$13, state$$11, xs$$23));
}
function scanBack(f$$14, xs$$25, state$$12) {
  return ofSeq(Object(__WEBPACK_IMPORTED_MODULE_2__Seq__["k" /* scanBack */])(f$$14, xs$$25, state$$12));
}
function length(xs$$27) {
  return fold(function (acc$$9, _arg1$$7) {
    return acc$$9 + 1;
  }, 0, xs$$27);
}
function append(xs$$28, ys$$10) {
  return fold(function (acc$$10, x$$15) {
    return new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](x$$15, acc$$10);
  }, ys$$10, reverse(xs$$28));
}
function collect(f$$15, xs$$29) {
  return ofSeq(Object(__WEBPACK_IMPORTED_MODULE_2__Seq__["a" /* collect */])(f$$15, xs$$29));
}
function map(f$$16, xs$$31) {
  return reverse(fold(function (acc$$11, x$$16) {
    return new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](f$$16(x$$16), acc$$11);
  }, new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](), xs$$31));
}
function mapIndexed(f$$17, xs$$33) {
  return reverse(foldIndexed(function (i$$3, acc$$12, x$$17) {
    return new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](f$$17(i$$3, x$$17), acc$$12);
  }, new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](), xs$$33));
}
function indexed(xs$$35) {
  return mapIndexed(function (i$$4, x$$18) {
    return [i$$4, x$$18];
  }, xs$$35);
}
function map2(f$$18, xs$$36, ys$$11) {
  return reverse(fold2(function (acc$$13, x$$19, y$$4) {
    return new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](f$$18(x$$19, y$$4), acc$$13);
  }, new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](), xs$$36, ys$$11));
}
function mapIndexed2(f$$19, xs$$38, ys$$12) {
  return reverse(foldIndexed2(function (i$$5, acc$$14, x$$20, y$$5) {
    return new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](f$$19(i$$5, x$$20, y$$5), acc$$14);
  }, new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](), xs$$38, ys$$12));
}
function map3(f$$20, xs$$40, ys$$13, zs$$3) {
  return reverse(fold3(function (acc$$15, x$$21, y$$6, z$$2) {
    return new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](f$$20(x$$21, y$$6, z$$2), acc$$15);
  }, new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](), xs$$40, ys$$13, zs$$3));
}
function mapIndexed3(f$$21, xs$$42, ys$$14, zs$$4) {
  return reverse(foldIndexed3(function (i$$6, acc$$16, x$$22, y$$7, z$$3) {
    return new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](f$$21(i$$6, x$$22, y$$7, z$$3), acc$$16);
  }, new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](), xs$$42, ys$$14, zs$$4));
}
function mapFold(f$$22, s, xs$$44) {
  var foldFn = function foldFn(tupledArg, x$$23) {
    var patternInput = f$$22(tupledArg[1], x$$23);
    return [new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](patternInput[0], tupledArg[0]), patternInput[1]];
  };

  var patternInput$$1 = fold(foldFn, [new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](), s], xs$$44);
  return [reverse(patternInput$$1[0]), patternInput$$1[1]];
}
function mapFoldBack(f$$23, xs$$45, s$$2) {
  return mapFold(function (s$$3, v) {
    return f$$23(v, s$$3);
  }, s$$2, reverse(xs$$45));
}
function iterate(f$$24, xs$$46) {
  fold(function (unitVar0, x$$24) {
    f$$24(x$$24);
  }, null, xs$$46);
}
function iterate2(f$$25, xs$$47, ys$$15) {
  fold2(function (unitVar0$$1, x$$25, y$$8) {
    f$$25(x$$25, y$$8);
  }, null, xs$$47, ys$$15);
}
function iterateIndexed(f$$26, xs$$48) {
  foldIndexed(function (i$$7, unitVar1, x$$26) {
    f$$26(i$$7, x$$26);
  }, null, xs$$48);
}
function iterateIndexed2(f$$27, xs$$49, ys$$16) {
  foldIndexed2(function (i$$8, unitVar1$$1, x$$27, y$$9) {
    f$$27(i$$8, x$$27, y$$9);
  }, null, xs$$49, ys$$16);
}
function ofArray(xs$$50) {
  return Object(__WEBPACK_IMPORTED_MODULE_3__Array__["b" /* foldBack */])(function (x$$28, acc$$17) {
    return new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](x$$28, acc$$17);
  }, xs$$50, new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */]());
}
function empty() {
  return new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */]();
}
function isEmpty(_arg1$$8) {
  if (_arg1$$8.tail == null) {
    return true;
  } else {
    return false;
  }
}
function tryPickIndexedAux($arg$$100, $arg$$101, $arg$$102) {
  tryPickIndexedAux: while (true) {
    var f$$28 = $arg$$100,
        i$$9 = $arg$$101,
        _arg1$$9 = $arg$$102;

    if (_arg1$$9.tail != null) {
      var xs$$51 = _arg1$$9.tail;
      var x$$29 = _arg1$$9.head;
      var result = f$$28(i$$9, x$$29);

      if (result == null) {
        $arg$$100 = f$$28;
        $arg$$101 = i$$9 + 1;
        $arg$$102 = xs$$51;
        continue tryPickIndexedAux;
      } else {
        return result;
      }
    } else {
      return null;
    }

    break;
  }
}
function tryPickIndexed(f$$29, xs$$52) {
  return tryPickIndexedAux(f$$29, 0, xs$$52);
}
function tryPick(f$$30, xs$$53) {
  return tryPickIndexed(function (_arg1$$10, x$$30) {
    return f$$30(x$$30);
  }, xs$$53);
}
function pick(f$$31, xs$$54) {
  var matchValue$$5 = tryPick(f$$31, xs$$54);

  if (matchValue$$5 != null) {
    var x$$31 = Object(__WEBPACK_IMPORTED_MODULE_0__Option__["d" /* value */])(matchValue$$5);
    return x$$31;
  } else {
    throw new Error("List did not contain any matching elements");
  }
}
function tryFindIndexed(f$$32, xs$$55) {
  return tryPickIndexed(function (i$$10, x$$32) {
    return f$$32(i$$10, x$$32) ? Object(__WEBPACK_IMPORTED_MODULE_0__Option__["c" /* some */])(x$$32) : null;
  }, xs$$55);
}
function tryFind(f$$33, xs$$56) {
  return tryPickIndexed(function (_arg1$$11, x$$33) {
    return f$$33(x$$33) ? Object(__WEBPACK_IMPORTED_MODULE_0__Option__["c" /* some */])(x$$33) : null;
  }, xs$$56);
}
function findIndexed(f$$34, xs$$57) {
  var matchValue$$6 = tryFindIndexed(f$$34, xs$$57);

  if (matchValue$$6 != null) {
    var x$$34 = Object(__WEBPACK_IMPORTED_MODULE_0__Option__["d" /* value */])(matchValue$$6);
    return x$$34;
  } else {
    throw new Error("List did not contain any matching elements");
  }
}
function find(f$$35, xs$$58) {
  return findIndexed(function (_arg1$$12, x$$35) {
    return f$$35(x$$35);
  }, xs$$58);
}
function findBack(f$$36, xs$$59) {
  return find(f$$36, reverse(xs$$59));
}
function tryFindBack(f$$37, xs$$62) {
  return tryFind(f$$37, reverse(xs$$62));
}
function tryFindIndex(f$$38, xs$$65) {
  return tryPickIndexed(function (i$$11, x$$36) {
    return f$$38(x$$36) ? i$$11 : null;
  }, xs$$65);
}
function tryFindIndexBack(f$$39, xs$$66) {
  return Object(__WEBPACK_IMPORTED_MODULE_3__Array__["e" /* tryFindIndexBack */])(f$$39, Object(__WEBPACK_IMPORTED_MODULE_3__Array__["c" /* ofList */])(xs$$66, Array));
}
function findIndex(f$$40, xs$$67) {
  var matchValue$$7 = tryFindIndex(f$$40, xs$$67);

  if (matchValue$$7 != null) {
    var x$$37 = matchValue$$7 | 0;
    return x$$37 | 0;
  } else {
    throw new Error("List did not contain any matching elements");
  }
}
function findIndexBack(f$$41, xs$$68) {
  return Object(__WEBPACK_IMPORTED_MODULE_3__Array__["a" /* findIndexBack */])(f$$41, Object(__WEBPACK_IMPORTED_MODULE_3__Array__["c" /* ofList */])(xs$$68, Array));
}
function item(n, xs$$69) {
  return findIndexed(function (i$$12, _arg1$$13) {
    return n === i$$12;
  }, xs$$69);
}
function tryItem(n$$1, xs$$70) {
  return tryFindIndexed(function (i$$13, _arg1$$14) {
    return n$$1 === i$$13;
  }, xs$$70);
}
function filter(f$$42, xs$$71) {
  return foldBack(function (x$$38, acc$$18) {
    return f$$42(x$$38) ? new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](x$$38, acc$$18) : acc$$18;
  }, xs$$71, new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */]());
}
function partition(f$$43, xs$$72) {
  return fold(function (tupledArg$$1, x$$39) {
    return f$$43(x$$39) ? [new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](x$$39, tupledArg$$1[0]), tupledArg$$1[1]] : [tupledArg$$1[0], new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](x$$39, tupledArg$$1[1])];
  }, [new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](), new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */]()], reverse(xs$$72));
}
function choose(f$$44, xs$$73) {
  return reverse(fold(function (acc$$19, x$$40) {
    var matchValue$$8 = f$$44(x$$40);

    if (matchValue$$8 == null) {
      return acc$$19;
    } else {
      var y$$10 = Object(__WEBPACK_IMPORTED_MODULE_0__Option__["d" /* value */])(matchValue$$8);
      return new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](y$$10, acc$$19);
    }
  }, new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](), xs$$73));
}
function contains(value, list, eq) {
  var loop$$1 = function loop$$1(xs$$75) {
    loop$$1: while (true) {
      if (xs$$75.tail != null) {
        var v$$1 = xs$$75.head;
        var rest = xs$$75.tail;

        if (eq.Equals(value, v$$1)) {
          return true;
        } else {
          xs$$75 = rest;
          continue loop$$1;
        }
      } else {
        return false;
      }

      break;
    }
  };

  return loop$$1(list);
}
function except(itemsToExclude, array$$2, eq$$1) {
  if (isEmpty(array$$2)) {
    return array$$2;
  } else {
    var cached = Object(__WEBPACK_IMPORTED_MODULE_5__Set__["a" /* createMutable */])(itemsToExclude, Object(__WEBPACK_IMPORTED_MODULE_4__Util__["g" /* comparerFromEqualityComparer */])(eq$$1));
    return filter(function f$$45(arg00) {
      return Object(__WEBPACK_IMPORTED_MODULE_4__Util__["a" /* addToSet */])(arg00, cached);
    }, array$$2);
  }
}
function initialize(n$$2, f$$46) {
  var xs$$77 = new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */]();

  for (var i$$14 = 1; i$$14 <= n$$2; i$$14++) {
    xs$$77 = new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](f$$46(n$$2 - i$$14), xs$$77);
  }

  return xs$$77;
}
function replicate(n$$3, x$$41) {
  return initialize(n$$3, function (_arg1$$15) {
    return x$$41;
  });
}
function reduce(f$$47, _arg1$$16) {
  if (_arg1$$16.tail != null) {
    var t$$1 = _arg1$$16.tail;
    var h$$1 = _arg1$$16.head;
    return fold(f$$47, h$$1, t$$1);
  } else {
    throw new Error("List was empty");
  }
}
function reduceBack(f$$48, _arg1$$17) {
  if (_arg1$$17.tail != null) {
    var t$$2 = _arg1$$17.tail;
    var h$$2 = _arg1$$17.head;
    return foldBack(f$$48, t$$2, h$$2);
  } else {
    throw new Error("List was empty");
  }
}
function forAll(f$$49, xs$$78) {
  return fold(function (acc$$20, x$$42) {
    return acc$$20 ? f$$49(x$$42) : false;
  }, true, xs$$78);
}
function forAll2(f$$50, xs$$79, ys$$17) {
  return fold2(function (acc$$21, x$$43, y$$11) {
    return acc$$21 ? f$$50(x$$43, y$$11) : false;
  }, true, xs$$79, ys$$17);
}
function exists($arg$$146, $arg$$147) {
  exists: while (true) {
    var f$$51 = $arg$$146,
        _arg1$$18 = $arg$$147;

    if (_arg1$$18.tail != null) {
      var xs$$80 = _arg1$$18.tail;
      var x$$44 = _arg1$$18.head;

      if (f$$51(x$$44)) {
        return true;
      } else {
        $arg$$146 = f$$51;
        $arg$$147 = xs$$80;
        continue exists;
      }
    } else {
      return false;
    }

    break;
  }
}
function exists2($arg$$148, $arg$$149, $arg$$150) {
  exists2: while (true) {
    var f$$52 = $arg$$148,
        bs$$2 = $arg$$149,
        cs$$2 = $arg$$150;
    var matchValue$$9 = [bs$$2, cs$$2];
    var $target$$151, x$$45, xs$$81, y$$12, ys$$18;

    if (matchValue$$9[0].tail != null) {
      if (matchValue$$9[1].tail != null) {
        $target$$151 = 1;
        x$$45 = matchValue$$9[0].head;
        xs$$81 = matchValue$$9[0].tail;
        y$$12 = matchValue$$9[1].head;
        ys$$18 = matchValue$$9[1].tail;
      } else {
        $target$$151 = 2;
      }
    } else if (matchValue$$9[1].tail == null) {
      $target$$151 = 0;
    } else {
      $target$$151 = 2;
    }

    switch ($target$$151) {
      case 0:
        {
          return false;
        }

      case 1:
        {
          if (f$$52(x$$45, y$$12)) {
            return true;
          } else {
            $arg$$148 = f$$52;
            $arg$$149 = xs$$81;
            $arg$$150 = ys$$18;
            continue exists2;
          }
        }

      case 2:
        {
          throw new Error("Lists had different lengths");
        }
    }

    break;
  }
}
function unzip(xs$$82) {
  return foldBack(function (tupledArg$$2, tupledArg$$3) {
    return [new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](tupledArg$$2[0], tupledArg$$3[0]), new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](tupledArg$$2[1], tupledArg$$3[1])];
  }, xs$$82, [new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](), new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */]()]);
}
function unzip3(xs$$83) {
  return foldBack(function (tupledArg$$4, tupledArg$$5) {
    return [new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](tupledArg$$4[0], tupledArg$$5[0]), new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](tupledArg$$4[1], tupledArg$$5[1]), new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](tupledArg$$4[2], tupledArg$$5[2])];
  }, xs$$83, [new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](), new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](), new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */]()]);
}
function zip(xs$$84, ys$$19) {
  return map2(function (x$$48, y$$15) {
    return [x$$48, y$$15];
  }, xs$$84, ys$$19);
}
function zip3(xs$$85, ys$$20, zs$$5) {
  return map3(function (x$$49, y$$16, z$$5) {
    return [x$$49, y$$16, z$$5];
  }, xs$$85, ys$$20, zs$$5);
}
function sort(xs$$86, comparer$$1) {
  var xs$$87;
  return ofArray((xs$$87 = Object(__WEBPACK_IMPORTED_MODULE_3__Array__["c" /* ofList */])(xs$$86, Array), (xs$$87.sort(function comparer$$2(x$$50, y$$17) {
    return comparer$$1.Compare(x$$50, y$$17);
  }), xs$$87)));
}
function sortBy(projection, xs$$89, comparer$$3) {
  var xs$$90;
  return ofArray((xs$$90 = Object(__WEBPACK_IMPORTED_MODULE_3__Array__["c" /* ofList */])(xs$$89, Array), (xs$$90.sort(function comparer$$4(x$$51, y$$18) {
    return comparer$$3.Compare(projection(x$$51), projection(y$$18));
  }), xs$$90)));
}
function sortDescending(xs$$92, comparer$$5) {
  var xs$$93;
  return ofArray((xs$$93 = Object(__WEBPACK_IMPORTED_MODULE_3__Array__["c" /* ofList */])(xs$$92, Array), (xs$$93.sort(function comparer$$6(x$$52, y$$19) {
    return comparer$$5.Compare(x$$52, y$$19) * -1;
  }), xs$$93)));
}
function sortByDescending(projection$$1, xs$$95, comparer$$7) {
  var xs$$96;
  return ofArray((xs$$96 = Object(__WEBPACK_IMPORTED_MODULE_3__Array__["c" /* ofList */])(xs$$95, Array), (xs$$96.sort(function comparer$$8(x$$53, y$$20) {
    return comparer$$7.Compare(projection$$1(x$$53), projection$$1(y$$20)) * -1;
  }), xs$$96)));
}
function sortWith(comparer$$9, xs$$98) {
  var xs$$99;
  return ofArray((xs$$99 = Object(__WEBPACK_IMPORTED_MODULE_3__Array__["c" /* ofList */])(xs$$98, Array), (xs$$99.sort(comparer$$9), xs$$99)));
}
function sum(xs$$101, adder) {
  return fold(function (acc$$22, x$$54) {
    return adder.Add(acc$$22, x$$54);
  }, adder.GetZero(), xs$$101);
}
function sumBy(f$$53, xs$$102, adder$$1) {
  return fold(function (acc$$23, x$$55) {
    return adder$$1.Add(acc$$23, f$$53(x$$55));
  }, adder$$1.GetZero(), xs$$102);
}
function maxBy(projection$$2, xs$$103, comparer$$11) {
  return reduce(function (x$$56, y$$21) {
    return comparer$$11.Compare(projection$$2(y$$21), projection$$2(x$$56)) > 0 ? y$$21 : x$$56;
  }, xs$$103);
}
function max(li, comparer$$12) {
  return reduce(function (x$$57, y$$22) {
    return comparer$$12.Compare(y$$22, x$$57) > 0 ? y$$22 : x$$57;
  }, li);
}
function minBy(projection$$3, xs$$104, comparer$$13) {
  return reduce(function (x$$58, y$$23) {
    return comparer$$13.Compare(projection$$3(y$$23), projection$$3(x$$58)) > 0 ? x$$58 : y$$23;
  }, xs$$104);
}
function min(xs$$105, comparer$$14) {
  return reduce(function (x$$59, y$$24) {
    return comparer$$14.Compare(y$$24, x$$59) > 0 ? x$$59 : y$$24;
  }, xs$$105);
}
function average(xs$$106, averager) {
  var total = fold(function (acc$$24, x$$60) {
    return averager.Add(acc$$24, x$$60);
  }, averager.GetZero(), xs$$106);
  return averager.DivideByInt(total, length(xs$$106));
}
function averageBy(f$$54, xs$$107, averager$$1) {
  var total$$1 = fold(function (acc$$25, x$$61) {
    return averager$$1.Add(acc$$25, f$$54(x$$61));
  }, averager$$1.GetZero(), xs$$107);
  return averager$$1.DivideByInt(total$$1, length(xs$$107));
}
function permute(f$$55, xs$$108) {
  return ofArray(Object(__WEBPACK_IMPORTED_MODULE_3__Array__["d" /* permute */])(f$$55, Object(__WEBPACK_IMPORTED_MODULE_3__Array__["c" /* ofList */])(xs$$108, Array)));
}
function skip(i$$15, xs$$110) {
  var skipInner = function skipInner(i$$16, xs$$111) {
    skipInner: while (true) {
      var matchValue$$10 = [i$$16, xs$$111];

      if (matchValue$$10[0] === 0) {
        return xs$$111;
      } else if (matchValue$$10[1].tail != null) {
        var xs$$112 = matchValue$$10[1].tail;
        var $i$$16$$174 = i$$16;
        i$$16 = $i$$16$$174 - 1;
        xs$$111 = xs$$112;
        continue skipInner;
      } else {
        throw new Error("The input sequence has an insufficient number of elements.");
      }

      break;
    }
  };

  var matchValue$$11 = [i$$15, xs$$110];

  if (matchValue$$11[0] < 0) {
    throw new Error("The input must be non-negative.");
  } else {
    var $target$$175, i$$19, xs$$114;

    if (matchValue$$11[0] === 0) {
      $target$$175 = 0;
    } else if (matchValue$$11[0] === 1) {
      if (matchValue$$11[1].tail != null) {
        $target$$175 = 1;
      } else {
        $target$$175 = 2;
        i$$19 = matchValue$$11[0];
        xs$$114 = matchValue$$11[1];
      }
    } else {
      $target$$175 = 2;
      i$$19 = matchValue$$11[0];
      xs$$114 = matchValue$$11[1];
    }

    switch ($target$$175) {
      case 0:
        {
          return xs$$110;
        }

      case 1:
        {
          var xs$$113 = matchValue$$11[1].tail;
          return xs$$113;
        }

      case 2:
        {
          return skipInner(i$$19, xs$$114);
        }
    }
  }
}
function skipWhile($arg$$176, $arg$$177) {
  var t$$3, h$$3;

  skipWhile: while (true) {
    var predicate = $arg$$176,
        xs$$115 = $arg$$177;
    var $target$$178, h$$4, t$$4;

    if (xs$$115.tail != null) {
      if (t$$3 = xs$$115.tail, (h$$3 = xs$$115.head, predicate(h$$3))) {
        $target$$178 = 0;
        h$$4 = xs$$115.head;
        t$$4 = xs$$115.tail;
      } else {
        $target$$178 = 1;
      }
    } else {
      $target$$178 = 1;
    }

    switch ($target$$178) {
      case 0:
        {
          $arg$$176 = predicate;
          $arg$$177 = t$$4;
          continue skipWhile;
        }

      case 1:
        {
          return xs$$115;
        }
    }

    break;
  }
}
function takeSplitAux(error, i$$20, acc$$26, xs$$116) {
  takeSplitAux: while (true) {
    var matchValue$$12 = [i$$20, xs$$116];

    if (matchValue$$12[0] === 0) {
      return [reverse(acc$$26), xs$$116];
    } else if (matchValue$$12[1].tail != null) {
      var xs$$117 = matchValue$$12[1].tail;
      var x$$62 = matchValue$$12[1].head;
      var $acc$$26$$181 = acc$$26;
      var $error$$179 = error;
      var $i$$20$$180 = i$$20;
      error = $error$$179;
      i$$20 = $i$$20$$180 - 1;
      acc$$26 = new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](x$$62, $acc$$26$$181);
      xs$$116 = xs$$117;
      continue takeSplitAux;
    } else {
      if (error) {
        throw new Error("The input sequence has an insufficient number of elements.");
      } else {
        return [reverse(acc$$26), xs$$116];
      }
    }

    break;
  }
}
function take(i$$21, xs$$118) {
  var matchValue$$13 = [i$$21, xs$$118];

  if (matchValue$$13[0] < 0) {
    throw new Error("The input must be non-negative.");
  } else {
    var $target$$182, i$$24, xs$$119;

    if (matchValue$$13[0] === 0) {
      $target$$182 = 0;
    } else if (matchValue$$13[0] === 1) {
      if (matchValue$$13[1].tail != null) {
        $target$$182 = 1;
      } else {
        $target$$182 = 2;
        i$$24 = matchValue$$13[0];
        xs$$119 = matchValue$$13[1];
      }
    } else {
      $target$$182 = 2;
      i$$24 = matchValue$$13[0];
      xs$$119 = matchValue$$13[1];
    }

    switch ($target$$182) {
      case 0:
        {
          return new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */]();
        }

      case 1:
        {
          var x$$63 = matchValue$$13[1].head;
          return new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](x$$63, new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */]());
        }

      case 2:
        {
          return takeSplitAux(true, i$$24, new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](), xs$$119)[0];
        }
    }
  }
}
function takeWhile(predicate$$1, xs$$120) {
  if (xs$$120.tail != null) {
    if (xs$$120.tail.tail == null) {
      if (predicate$$1(xs$$120.head)) {
        return xs$$120;
      } else {
        return xs$$120.tail;
      }
    } else {
      if (!predicate$$1(xs$$120.head)) {
        return new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */]();
      } else {
        return new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](xs$$120.head, takeWhile(predicate$$1, xs$$120.tail));
      }
    }
  } else {
    return xs$$120;
  }
}
function truncate(i$$25, xs$$122) {
  var matchValue$$14 = [i$$25, xs$$122];

  if (matchValue$$14[0] < 0) {
    throw new Error("The input must be non-negative.");
  } else {
    var $target$$185, i$$28, xs$$123;

    if (matchValue$$14[0] === 0) {
      $target$$185 = 0;
    } else if (matchValue$$14[0] === 1) {
      if (matchValue$$14[1].tail != null) {
        $target$$185 = 1;
      } else {
        $target$$185 = 2;
        i$$28 = matchValue$$14[0];
        xs$$123 = matchValue$$14[1];
      }
    } else {
      $target$$185 = 2;
      i$$28 = matchValue$$14[0];
      xs$$123 = matchValue$$14[1];
    }

    switch ($target$$185) {
      case 0:
        {
          return new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */]();
        }

      case 1:
        {
          var x$$66 = matchValue$$14[1].head;
          return new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](x$$66, new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */]());
        }

      case 2:
        {
          return takeSplitAux(false, i$$28, new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](), xs$$123)[0];
        }
    }
  }
}
function splitAt(i$$29, xs$$124) {
  var matchValue$$15 = [i$$29, xs$$124];

  if (matchValue$$15[0] < 0) {
    throw new Error("The input must be non-negative.");
  } else {
    var $target$$186, i$$32, xs$$126;

    if (matchValue$$15[0] === 0) {
      $target$$186 = 0;
    } else if (matchValue$$15[0] === 1) {
      if (matchValue$$15[1].tail != null) {
        $target$$186 = 1;
      } else {
        $target$$186 = 2;
        i$$32 = matchValue$$15[0];
        xs$$126 = matchValue$$15[1];
      }
    } else {
      $target$$186 = 2;
      i$$32 = matchValue$$15[0];
      xs$$126 = matchValue$$15[1];
    }

    switch ($target$$186) {
      case 0:
        {
          return [new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](), xs$$124];
        }

      case 1:
        {
          var xs$$125 = matchValue$$15[1].tail;
          var x$$67 = matchValue$$15[1].head;
          return [new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](x$$67, new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */]()), xs$$125];
        }

      case 2:
        {
          return takeSplitAux(true, i$$32, new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](), xs$$126);
        }
    }
  }
}
function slice(lower, upper, xs$$127) {
  var lower$$1 = Object(__WEBPACK_IMPORTED_MODULE_0__Option__["b" /* defaultArg */])(lower, -1) | 0;
  var upper$$1 = Object(__WEBPACK_IMPORTED_MODULE_0__Option__["b" /* defaultArg */])(upper, -1) | 0;
  return reverse(foldIndexed(function f$$56(i$$33, acc$$27, x$$68) {
    if ((lower$$1 === -1 ? true : lower$$1 <= i$$33) ? upper$$1 === -1 ? true : i$$33 <= upper$$1 : false) {
      return new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](x$$68, acc$$27);
    } else {
      return acc$$27;
    }
  }, new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](), xs$$127));
}
function distinctBy(projection$$4, xs$$130, eq$$2) {
  var hashSet = Object(__WEBPACK_IMPORTED_MODULE_5__Set__["a" /* createMutable */])([], Object(__WEBPACK_IMPORTED_MODULE_4__Util__["g" /* comparerFromEqualityComparer */])(eq$$2));
  return filter(function f$$57($arg$$1) {
    return Object(__WEBPACK_IMPORTED_MODULE_4__Util__["a" /* addToSet */])(projection$$4($arg$$1), hashSet);
  }, xs$$130);
}
function distinct(xs$$132, eq$$3) {
  return distinctBy(function (x$$69) {
    return x$$69;
  }, xs$$132, eq$$3);
}
function groupBy(projection$$5, xs$$133, eq$$4) {
  var dict = Object(__WEBPACK_IMPORTED_MODULE_6__Map__["a" /* createMutable */])([], Object(__WEBPACK_IMPORTED_MODULE_4__Util__["g" /* comparerFromEqualityComparer */])(eq$$4));
  Object(__WEBPACK_IMPORTED_MODULE_2__Seq__["g" /* iterate */])(function (v$$2) {
    var key = projection$$5(v$$2);

    if (dict.has(key)) {
      dict.set(key, new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](v$$2, dict.get(key)));
    } else {
      dict.set(key, new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */](v$$2, new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */]()));
    }
  }, xs$$133);
  return ofSeq(Object(__WEBPACK_IMPORTED_MODULE_2__Seq__["h" /* map */])(function mapping(kv) {
    return [kv[0], reverse(kv[1])];
  }, dict));
}
function countBy(projection$$6, xs$$135, eq$$5) {
  var dict$$1 = Object(__WEBPACK_IMPORTED_MODULE_6__Map__["a" /* createMutable */])([], Object(__WEBPACK_IMPORTED_MODULE_4__Util__["g" /* comparerFromEqualityComparer */])(eq$$5));
  iterate(function (v$$3) {
    var key$$1 = projection$$6(v$$3);
    var matchValue$$16 = Object(__WEBPACK_IMPORTED_MODULE_4__Util__["r" /* tryGetValue */])(dict$$1, key$$1, null);

    if (matchValue$$16[0]) {
      matchValue$$16[1].contents = matchValue$$16[1].contents + 1;
    } else {
      dict$$1.set(key$$1, new __WEBPACK_IMPORTED_MODULE_1__Types__["a" /* FSharpRef */](1));
    }
  }, xs$$135);
  var result$$1 = new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */]();
  Object(__WEBPACK_IMPORTED_MODULE_2__Seq__["g" /* iterate */])(function (group) {
    result$$1 = new __WEBPACK_IMPORTED_MODULE_1__Types__["b" /* List */]([group[0], group[1].contents], result$$1);
  }, dict$$1);
  return result$$1;
}
function where(predicate$$2, xs$$136) {
  return filter(predicate$$2, xs$$136);
}

/***/ }),
/* 142 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(143), __esModule: true };

/***/ }),
/* 143 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(144);
var $Object = __webpack_require__(0).Object;
module.exports = function create(P, D) {
  return $Object.create(P, D);
};


/***/ }),
/* 144 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(2);
// 19.1.2.2 / 15.2.3.5 Object.create(O [, Properties])
$export($export.S, 'Object', { create: __webpack_require__(38) });


/***/ }),
/* 145 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(146), __esModule: true };

/***/ }),
/* 146 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(147);
module.exports = __webpack_require__(0).Object.getPrototypeOf;


/***/ }),
/* 147 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.9 Object.getPrototypeOf(O)
var toObject = __webpack_require__(15);
var $getPrototypeOf = __webpack_require__(63);

__webpack_require__(55)('getPrototypeOf', function () {
  return function getPrototypeOf(it) {
    return $getPrototypeOf(toObject(it));
  };
});


/***/ }),
/* 148 */
/***/ (function(module, exports, __webpack_require__) {

/**
 * A simple persistent user settings framework for Electron.
 *
 * @module main
 * @author Nathan Buchar
 * @copyright 2016-2017 Nathan Buchar <hello@nathanbuchar.com>
 * @license ISC
 */

const Settings = __webpack_require__(149);

module.exports = new Settings();


/***/ }),
/* 149 */
/***/ (function(module, exports, __webpack_require__) {

/**
 * A module that handles read and writing to the disk.
 *
 * @module settings
 * @author Nathan Buchar
 * @copyright 2016-2017 Nathan Buchar <hello@nathanbuchar.com>
 * @license ISC
 */

const assert = __webpack_require__(57);
const electron = __webpack_require__(82);
const { EventEmitter } = __webpack_require__(150);
const fs = __webpack_require__(23);
const jsonfile = __webpack_require__(151);
const path = __webpack_require__(84);

const Helpers = __webpack_require__(158);
const Observer = __webpack_require__(159);

/**
 * The name of the settings file.
 *
 * @type {string}
 */
const defaultSettingsFileName = 'Settings';

/**
 * The electron-settings class.
 *
 * @extends EventEmitter
 * @class
 */
class Settings extends EventEmitter {

  constructor() {
    super();

    /**
     * The absolute path to the custom settings file on the disk.
     *
     * @type {string}
     * @default null
     * @private
     */
    this._customSettingsFilePath = null;

    /**
     * The FSWatcher instance. This will watch if the settings file and
     * notify key path observers.
     *
     * @type {FSWatcher}
     * @default null
     * @private
     */
    this._fsWatcher = null;

    /**
     * Called when the settings file is changed or renamed.
     *
     * @type {Object}
     * @private
     */
    this._handleSettingsFileChange = this._onSettingsFileChange.bind(this);
  }

  /**
   * Returns the settings file path.
   *
   * @returns {string}
   * @private
   */
  _getSettingsFilePath() {
    if (this._customSettingsFilePath) return this._customSettingsFilePath;

    const app = electron.app || electron.remote.app;
    const userDataPath = app.getPath('userData');
    const defaultSettingsFilePath = path.join(userDataPath, defaultSettingsFileName);

    return defaultSettingsFilePath;
  }

  /**
   * Sets a custom settings file path.
   *
   * @param {string} filePath
   * @private
   */
  _setSettingsFilePath(filePath) {
    this._customSettingsFilePath = filePath;

    // Reset FSWatcher.
    this._unwatchSettings(true);
  }

  /**
   * Clears the custom settings file path.
   *
   * @private
   */
  _clearSettingsFilePath() {
    this._setSettingsFilePath(null);
  }

  /**
   * Watches the settings file for changes using the native `FSWatcher`
   * class in case the settings file is changed outside of
   * ElectronSettings' jursidiction.
   *
   * @private
   */
  _watchSettings() {
    if (!this._fsWatcher) {
      try {
        this._fsWatcher = fs.watch(this._getSettingsFilePath(), this._handleSettingsFileChange);
      } catch (err) {
        // File may not exist yet or the user may not have permission to
        // access the file or directory. Fail gracefully.
      }
    }
  }

  /**
   * Unwatches the settings file by closing the FSWatcher and nullifying its
   * references. If the `reset` parameter is true, attempt to watch the
   * settings file again.
   *
   * @param {boolean} [reset=false]
   * @private
   */
  _unwatchSettings(reset = false) {
    if (this._fsWatcher) {
      this._fsWatcher.close();
      this._fsWatcher = null;

      if (reset) {
        this._watchSettings();
      }
    }
  }

  /**
   * Ensures that the settings file exists, then initializes the FSWatcher.
   *
   * @private
   */
  _ensureSettings() {
    const settingsFilePath = this._getSettingsFilePath();

    try {
      jsonfile.readFileSync(settingsFilePath);
    } catch (err) {
      try {
        jsonfile.writeFileSync(settingsFilePath, {});
      } catch (err) {
        // Cannot read or write file. The user may not have permission to
        // access the file or directory. Throw error.
        throw err;
      }
    }

    this._watchSettings();
  }

  /**
   * Writes the settings to the disk.
   *
   * @param {Object} [obj={}]
   * @param {Object} [opts={}]
   * @private
   */
  _writeSettings(obj = {}, opts = {}) {
    this._ensureSettings();

    try {
      const spaces = opts.prettify ? 2 : 0;

      jsonfile.writeFileSync(this._getSettingsFilePath(), obj, { spaces });
    } catch (err) {
      // Could not write the file. The user may not have permission to
      // access the file or directory. Throw error.
      throw err;
    }
  }

  /**
   * Returns the parsed contents of the settings file.
   *
   * @returns {Object}
   * @private
   */
  _readSettings() {
    this._ensureSettings();

    try {
      return jsonfile.readFileSync(this._getSettingsFilePath());
    } catch (err) {
      // Could not read the file. The user may not have permission to
      // access the file or directory. Throw error.
      throw err;
    }
  }

  /**
   * Called when the settings file has been changed or
   * renamed (moved/deleted).
   *
   * @type {string} eventType
   * @private
   */
  _onSettingsFileChange(eventType) {
    switch (eventType) {
      case Settings.FSWatcherEvents.CHANGE: {
        this._emitChangeEvent();
        break;
      }
      case Settings.FSWatcherEvents.RENAME: {
        this._unwatchSettings(true);
        break;
      }
    }
  }

  /**
   * Broadcasts the internal "change" event.
   *
   * @emits ElectronSettings:change
   * @private
   */
  _emitChangeEvent() {
    this.emit(Settings.Events.CHANGE);
  }

  /**
   * Returns a boolean indicating whether the settings object contains
   * the given key path.
   *
   * @param {string} keyPath
   * @returns {boolean}
   * @private
   */
  _checkKeyPathExists(keyPath) {
    const obj = this._readSettings();
    const exists = Helpers.hasKeyPath(obj, keyPath);

    return exists;
  }

  /**
   * Sets the value at the given key path, or the entire settings object if
   * an empty key path is given.
   *
   * @param {string} keyPath
   * @param {any} value
   * @param {Object} opts
   * @private
   */
  _setValueAtKeyPath(keyPath, value, opts) {
    let obj = value;

    if (keyPath !== '') {
      obj = this._readSettings();

      Helpers.setValueAtKeyPath(obj, keyPath, value);
    }

    this._writeSettings(obj, opts);
  }

  /**
   * Returns the value at the given key path, or sets the value at that key
   * path to the default value, if provided, if the key does not exist. If an
   * empty key path is given, the entire settings object will be returned.
   *
   * @param {string} keyPath
   * @param {any} defaultValue
   * @param {Object} opts
   * @returns {any}
   * @private
   */
  _getValueAtKeyPath(keyPath, defaultValue, opts) {
    const obj = this._readSettings();

    if (keyPath !== '') {
      const exists = Helpers.hasKeyPath(obj, keyPath);
      const value = Helpers.getValueAtKeyPath(obj, keyPath);

      // The key does not exist but a default value does. Set the value at the
      // key path to the default value and then get the new value.
      if (!exists && typeof defaultValue !== 'undefined') {
        this._setValueAtKeyPath(keyPath, defaultValue, opts);

        // Get the new value now that the default has been set.
        return this._getValueAtKeyPath(keyPath);
      }

      return value;
    }

    return obj;
  }

  /**
   * Deletes the key and value at the given key path, or clears the entire
   * settings object if an empty key path is given.
   *
   * @param {string} keyPath
   * @param {Object} opts
   * @private
   */
  _deleteValueAtKeyPath(keyPath, opts) {
    if (keyPath === '') {
      this._writeSettings({}, opts);
    } else {
      const obj = this._readSettings();
      const exists = Helpers.hasKeyPath(obj, keyPath);

      if (exists) {
        Helpers.deleteValueAtKeyPath(obj, keyPath);
        this._writeSettings(obj, opts);
      }
    }
  }

  /**
   * Watches the given key path for changes and calls the given handler
   * if the value changes. To unsubscribe from changes, call `dispose()`
   * on the Observer instance that is returned.
   *
   * @param {string} keyPath
   * @param {Function} handler
   * @returns {Observer}
   * @private
   */
  _watchValueAtKeyPath(keyPath, handler) {
    const currentValue = this._getValueAtKeyPath(keyPath);

    return new Observer(this, keyPath, handler, currentValue);
  }

  /**
   * Returns a boolean indicating whether the settings object contains
   * the given key path.
   *
   * @param {string} keyPath
   * @returns {boolean}
   * @public
   */
  has(keyPath) {
    assert.strictEqual(typeof keyPath, 'string', 'First parameter must be a string');

    return this._checkKeyPathExists(keyPath);
  }

  /**
   * Sets the value at the given key path.
   *
   * @param {string} keyPath
   * @param {any} value
   * @param {Object} [opts={}]
   * @param {boolean} [opts.prettify=false]
   * @returns {Settings}
   * @public
   */
  set(keyPath, value, opts = {}) {
    assert.strictEqual(typeof keyPath, 'string', 'First parameter must be a string. Did you mean to use `setAll()` instead?');
    assert.strictEqual(typeof opts, 'object', 'Second parameter must be an object');

    this._setValueAtKeyPath(keyPath, value, opts);

    return this;
  }

  /**
   * Sets all settings.
   *
   * @param {Object} obj
   * @param {Object} [opts={}]
   * @param {boolean} [opts.prettify=false]
   * @returns {Settings}
   * @public
   */
  setAll(obj, opts = {}) {
    assert.strictEqual(typeof obj, 'object', 'First parameter must be an object');
    assert.strictEqual(typeof opts, 'object', 'Second parameter must be an object');

    this._setValueAtKeyPath('', obj, opts);

    return this;
  }

  /**
   * Returns the value at the given key path, or sets the value at that key
   * path to the default value, if provided, if the key does not exist.
   *
   * @param {string} keyPath
   * @param {any} [defaultValue]
   * @param {Object} [opts={}]
   * @returns {any}
   * @public
   */
  get(keyPath, defaultValue, opts = {}) {
    assert.strictEqual(typeof keyPath, 'string', 'First parameter must be a string. Did you mean to use `getAll()` instead?');

    return this._getValueAtKeyPath(keyPath, defaultValue, opts);
  }

  /**
   * Returns all settings.
   *
   * @returns {Object}
   * @public
   */
  getAll() {
    return this._getValueAtKeyPath('');
  }

  /**
   * Deletes the key and value at the given key path.
   *
   * @param {string} keyPath
   * @param {Object} [opts={}]
   * @param {boolean} [opts.prettify=false]
   * @returns {Settings}
   * @public
   */
  delete(keyPath, opts = {}) {
    assert.strictEqual(typeof keyPath, 'string', 'First parameter must be a string. Did you mean to use `deleteAll()` instead?');
    assert.strictEqual(typeof opts, 'object', 'Second parameter must be an object');

    this._deleteValueAtKeyPath(keyPath, opts);

    return this;
  }

  /**
   * Deletes all settings.
   *
   * @param {Object} [opts={}]
   * @param {boolean} [opts.prettify=false]
   * @returns {Settings}
   * @public
   */
  deleteAll(opts = {}) {
    assert.strictEqual(typeof opts, 'object', 'First parameter must be an object');

    this._deleteValueAtKeyPath('', opts);

    return this;
  }

  /**
   * Watches the given key path for changes and calls the given handler
   * if the value changes. To unsubscribe from changes, call `dispose()`
   * on the Observer instance that is returned.
   *
   * @param {string} keyPath
   * @param {Function} handler
   * @returns {Observer}
   * @public
   */
  watch(keyPath, handler) {
    assert.strictEqual(typeof keyPath, 'string', 'First parameter must be a string');
    assert.strictEqual(typeof handler, 'function', 'Second parameter must be a function');

    return this._watchValueAtKeyPath(keyPath, handler);
  }

  /**
   * Sets a custom settings file path.
   *
   * @param {string} filePath
   * @returns {Settings}
   * @public
   */
  setPath(filePath) {
    assert.strictEqual(typeof filePath, 'string', 'First parameter must be a string');

    this._setSettingsFilePath(filePath);

    return this;
  }

  /**
   * Clears the custom settings file path.
   *
   * @returns {Settings}
   * @public
   */
  clearPath() {
    this._clearSettingsFilePath();

    return this;
  }

  /**
   * Returns the absolute path to where the settings file is or will be stored.
   *
   * @returns {string}
   * @public
   */
  file() {
    return this._getSettingsFilePath();
  }
}

/**
 * ElectronSettings event names.
 *
 * @enum {string}
 * @readonly
 */
Settings.FSWatcherEvents = {
  CHANGE: 'change',
  RENAME: 'rename'
};

/**
 * ElectronSettings event names.
 *
 * @enum {string}
 * @readonly
 */
Settings.Events = {
  CHANGE: 'change'
};

module.exports = Settings;


/***/ }),
/* 150 */
/***/ (function(module, exports) {

module.exports = require("events");

/***/ }),
/* 151 */
/***/ (function(module, exports, __webpack_require__) {

var _fs
try {
  _fs = __webpack_require__(152)
} catch (_) {
  _fs = __webpack_require__(23)
}

function readFile (file, options, callback) {
  if (callback == null) {
    callback = options
    options = {}
  }

  if (typeof options === 'string') {
    options = {encoding: options}
  }

  options = options || {}
  var fs = options.fs || _fs

  var shouldThrow = true
  // DO NOT USE 'passParsingErrors' THE NAME WILL CHANGE!!!, use 'throws' instead
  if ('passParsingErrors' in options) {
    shouldThrow = options.passParsingErrors
  } else if ('throws' in options) {
    shouldThrow = options.throws
  }

  fs.readFile(file, options, function (err, data) {
    if (err) return callback(err)

    data = stripBom(data)

    var obj
    try {
      obj = JSON.parse(data, options ? options.reviver : null)
    } catch (err2) {
      if (shouldThrow) {
        err2.message = file + ': ' + err2.message
        return callback(err2)
      } else {
        return callback(null, null)
      }
    }

    callback(null, obj)
  })
}

function readFileSync (file, options) {
  options = options || {}
  if (typeof options === 'string') {
    options = {encoding: options}
  }

  var fs = options.fs || _fs

  var shouldThrow = true
  // DO NOT USE 'passParsingErrors' THE NAME WILL CHANGE!!!, use 'throws' instead
  if ('passParsingErrors' in options) {
    shouldThrow = options.passParsingErrors
  } else if ('throws' in options) {
    shouldThrow = options.throws
  }

  var content = fs.readFileSync(file, options)
  content = stripBom(content)

  try {
    return JSON.parse(content, options.reviver)
  } catch (err) {
    if (shouldThrow) {
      err.message = file + ': ' + err.message
      throw err
    } else {
      return null
    }
  }
}

function writeFile (file, obj, options, callback) {
  if (callback == null) {
    callback = options
    options = {}
  }
  options = options || {}
  var fs = options.fs || _fs

  var spaces = typeof options === 'object' && options !== null
    ? 'spaces' in options
    ? options.spaces : this.spaces
    : this.spaces

  var str = ''
  try {
    str = JSON.stringify(obj, options ? options.replacer : null, spaces) + '\n'
  } catch (err) {
    if (callback) return callback(err, null)
  }

  fs.writeFile(file, str, options, callback)
}

function writeFileSync (file, obj, options) {
  options = options || {}
  var fs = options.fs || _fs

  var spaces = typeof options === 'object' && options !== null
    ? 'spaces' in options
    ? options.spaces : this.spaces
    : this.spaces

  var str = JSON.stringify(obj, options.replacer, spaces) + '\n'
  // not sure if fs.writeFileSync returns anything, but just in case
  return fs.writeFileSync(file, str, options)
}

function stripBom (content) {
  // we do this because JSON.parse would convert it to a utf8 string if encoding wasn't specified
  if (Buffer.isBuffer(content)) content = content.toString('utf8')
  content = content.replace(/^\uFEFF/, '')
  return content
}

var jsonfile = {
  spaces: null,
  readFile: readFile,
  readFileSync: readFileSync,
  writeFile: writeFile,
  writeFileSync: writeFileSync
}

module.exports = jsonfile


/***/ }),
/* 152 */
/***/ (function(module, exports, __webpack_require__) {

var fs = __webpack_require__(23)
var polyfills = __webpack_require__(153)
var legacy = __webpack_require__(155)
var queue = []

var util = __webpack_require__(157)

function noop () {}

var debug = noop
if (util.debuglog)
  debug = util.debuglog('gfs4')
else if (/\bgfs4\b/i.test(process.env.NODE_DEBUG || ''))
  debug = function() {
    var m = util.format.apply(util, arguments)
    m = 'GFS4: ' + m.split(/\n/).join('\nGFS4: ')
    console.error(m)
  }

if (/\bgfs4\b/i.test(process.env.NODE_DEBUG || '')) {
  process.on('exit', function() {
    debug(queue)
    __webpack_require__(57).equal(queue.length, 0)
  })
}

module.exports = patch(__webpack_require__(83))
if (process.env.TEST_GRACEFUL_FS_GLOBAL_PATCH) {
  module.exports = patch(fs)
}

// Always patch fs.close/closeSync, because we want to
// retry() whenever a close happens *anywhere* in the program.
// This is essential when multiple graceful-fs instances are
// in play at the same time.
module.exports.close =
fs.close = (function (fs$close) { return function (fd, cb) {
  return fs$close.call(fs, fd, function (err) {
    if (!err)
      retry()

    if (typeof cb === 'function')
      cb.apply(this, arguments)
  })
}})(fs.close)

module.exports.closeSync =
fs.closeSync = (function (fs$closeSync) { return function (fd) {
  // Note that graceful-fs also retries when fs.closeSync() fails.
  // Looks like a bug to me, although it's probably a harmless one.
  var rval = fs$closeSync.apply(fs, arguments)
  retry()
  return rval
}})(fs.closeSync)

function patch (fs) {
  // Everything that references the open() function needs to be in here
  polyfills(fs)
  fs.gracefulify = patch
  fs.FileReadStream = ReadStream;  // Legacy name.
  fs.FileWriteStream = WriteStream;  // Legacy name.
  fs.createReadStream = createReadStream
  fs.createWriteStream = createWriteStream
  var fs$readFile = fs.readFile
  fs.readFile = readFile
  function readFile (path, options, cb) {
    if (typeof options === 'function')
      cb = options, options = null

    return go$readFile(path, options, cb)

    function go$readFile (path, options, cb) {
      return fs$readFile(path, options, function (err) {
        if (err && (err.code === 'EMFILE' || err.code === 'ENFILE'))
          enqueue([go$readFile, [path, options, cb]])
        else {
          if (typeof cb === 'function')
            cb.apply(this, arguments)
          retry()
        }
      })
    }
  }

  var fs$writeFile = fs.writeFile
  fs.writeFile = writeFile
  function writeFile (path, data, options, cb) {
    if (typeof options === 'function')
      cb = options, options = null

    return go$writeFile(path, data, options, cb)

    function go$writeFile (path, data, options, cb) {
      return fs$writeFile(path, data, options, function (err) {
        if (err && (err.code === 'EMFILE' || err.code === 'ENFILE'))
          enqueue([go$writeFile, [path, data, options, cb]])
        else {
          if (typeof cb === 'function')
            cb.apply(this, arguments)
          retry()
        }
      })
    }
  }

  var fs$appendFile = fs.appendFile
  if (fs$appendFile)
    fs.appendFile = appendFile
  function appendFile (path, data, options, cb) {
    if (typeof options === 'function')
      cb = options, options = null

    return go$appendFile(path, data, options, cb)

    function go$appendFile (path, data, options, cb) {
      return fs$appendFile(path, data, options, function (err) {
        if (err && (err.code === 'EMFILE' || err.code === 'ENFILE'))
          enqueue([go$appendFile, [path, data, options, cb]])
        else {
          if (typeof cb === 'function')
            cb.apply(this, arguments)
          retry()
        }
      })
    }
  }

  var fs$readdir = fs.readdir
  fs.readdir = readdir
  function readdir (path, options, cb) {
    var args = [path]
    if (typeof options !== 'function') {
      args.push(options)
    } else {
      cb = options
    }
    args.push(go$readdir$cb)

    return go$readdir(args)

    function go$readdir$cb (err, files) {
      if (files && files.sort)
        files.sort()

      if (err && (err.code === 'EMFILE' || err.code === 'ENFILE'))
        enqueue([go$readdir, [args]])
      else {
        if (typeof cb === 'function')
          cb.apply(this, arguments)
        retry()
      }
    }
  }

  function go$readdir (args) {
    return fs$readdir.apply(fs, args)
  }

  if (process.version.substr(0, 4) === 'v0.8') {
    var legStreams = legacy(fs)
    ReadStream = legStreams.ReadStream
    WriteStream = legStreams.WriteStream
  }

  var fs$ReadStream = fs.ReadStream
  ReadStream.prototype = Object.create(fs$ReadStream.prototype)
  ReadStream.prototype.open = ReadStream$open

  var fs$WriteStream = fs.WriteStream
  WriteStream.prototype = Object.create(fs$WriteStream.prototype)
  WriteStream.prototype.open = WriteStream$open

  fs.ReadStream = ReadStream
  fs.WriteStream = WriteStream

  function ReadStream (path, options) {
    if (this instanceof ReadStream)
      return fs$ReadStream.apply(this, arguments), this
    else
      return ReadStream.apply(Object.create(ReadStream.prototype), arguments)
  }

  function ReadStream$open () {
    var that = this
    open(that.path, that.flags, that.mode, function (err, fd) {
      if (err) {
        if (that.autoClose)
          that.destroy()

        that.emit('error', err)
      } else {
        that.fd = fd
        that.emit('open', fd)
        that.read()
      }
    })
  }

  function WriteStream (path, options) {
    if (this instanceof WriteStream)
      return fs$WriteStream.apply(this, arguments), this
    else
      return WriteStream.apply(Object.create(WriteStream.prototype), arguments)
  }

  function WriteStream$open () {
    var that = this
    open(that.path, that.flags, that.mode, function (err, fd) {
      if (err) {
        that.destroy()
        that.emit('error', err)
      } else {
        that.fd = fd
        that.emit('open', fd)
      }
    })
  }

  function createReadStream (path, options) {
    return new ReadStream(path, options)
  }

  function createWriteStream (path, options) {
    return new WriteStream(path, options)
  }

  var fs$open = fs.open
  fs.open = open
  function open (path, flags, mode, cb) {
    if (typeof mode === 'function')
      cb = mode, mode = null

    return go$open(path, flags, mode, cb)

    function go$open (path, flags, mode, cb) {
      return fs$open(path, flags, mode, function (err, fd) {
        if (err && (err.code === 'EMFILE' || err.code === 'ENFILE'))
          enqueue([go$open, [path, flags, mode, cb]])
        else {
          if (typeof cb === 'function')
            cb.apply(this, arguments)
          retry()
        }
      })
    }
  }

  return fs
}

function enqueue (elem) {
  debug('ENQUEUE', elem[0].name, elem[1])
  queue.push(elem)
}

function retry () {
  var elem = queue.shift()
  if (elem) {
    debug('RETRY', elem[0].name, elem[1])
    elem[0].apply(null, elem[1])
  }
}


/***/ }),
/* 153 */
/***/ (function(module, exports, __webpack_require__) {

var fs = __webpack_require__(83)
var constants = __webpack_require__(154)

var origCwd = process.cwd
var cwd = null

var platform = process.env.GRACEFUL_FS_PLATFORM || process.platform

process.cwd = function() {
  if (!cwd)
    cwd = origCwd.call(process)
  return cwd
}
try {
  process.cwd()
} catch (er) {}

var chdir = process.chdir
process.chdir = function(d) {
  cwd = null
  chdir.call(process, d)
}

module.exports = patch

function patch (fs) {
  // (re-)implement some things that are known busted or missing.

  // lchmod, broken prior to 0.6.2
  // back-port the fix here.
  if (constants.hasOwnProperty('O_SYMLINK') &&
      process.version.match(/^v0\.6\.[0-2]|^v0\.5\./)) {
    patchLchmod(fs)
  }

  // lutimes implementation, or no-op
  if (!fs.lutimes) {
    patchLutimes(fs)
  }

  // https://github.com/isaacs/node-graceful-fs/issues/4
  // Chown should not fail on einval or eperm if non-root.
  // It should not fail on enosys ever, as this just indicates
  // that a fs doesn't support the intended operation.

  fs.chown = chownFix(fs.chown)
  fs.fchown = chownFix(fs.fchown)
  fs.lchown = chownFix(fs.lchown)

  fs.chmod = chmodFix(fs.chmod)
  fs.fchmod = chmodFix(fs.fchmod)
  fs.lchmod = chmodFix(fs.lchmod)

  fs.chownSync = chownFixSync(fs.chownSync)
  fs.fchownSync = chownFixSync(fs.fchownSync)
  fs.lchownSync = chownFixSync(fs.lchownSync)

  fs.chmodSync = chmodFixSync(fs.chmodSync)
  fs.fchmodSync = chmodFixSync(fs.fchmodSync)
  fs.lchmodSync = chmodFixSync(fs.lchmodSync)

  fs.stat = statFix(fs.stat)
  fs.fstat = statFix(fs.fstat)
  fs.lstat = statFix(fs.lstat)

  fs.statSync = statFixSync(fs.statSync)
  fs.fstatSync = statFixSync(fs.fstatSync)
  fs.lstatSync = statFixSync(fs.lstatSync)

  // if lchmod/lchown do not exist, then make them no-ops
  if (!fs.lchmod) {
    fs.lchmod = function (path, mode, cb) {
      if (cb) process.nextTick(cb)
    }
    fs.lchmodSync = function () {}
  }
  if (!fs.lchown) {
    fs.lchown = function (path, uid, gid, cb) {
      if (cb) process.nextTick(cb)
    }
    fs.lchownSync = function () {}
  }

  // on Windows, A/V software can lock the directory, causing this
  // to fail with an EACCES or EPERM if the directory contains newly
  // created files.  Try again on failure, for up to 60 seconds.

  // Set the timeout this long because some Windows Anti-Virus, such as Parity
  // bit9, may lock files for up to a minute, causing npm package install
  // failures. Also, take care to yield the scheduler. Windows scheduling gives
  // CPU to a busy looping process, which can cause the program causing the lock
  // contention to be starved of CPU by node, so the contention doesn't resolve.
  if (platform === "win32") {
    fs.rename = (function (fs$rename) { return function (from, to, cb) {
      var start = Date.now()
      var backoff = 0;
      fs$rename(from, to, function CB (er) {
        if (er
            && (er.code === "EACCES" || er.code === "EPERM")
            && Date.now() - start < 60000) {
          setTimeout(function() {
            fs.stat(to, function (stater, st) {
              if (stater && stater.code === "ENOENT")
                fs$rename(from, to, CB);
              else
                cb(er)
            })
          }, backoff)
          if (backoff < 100)
            backoff += 10;
          return;
        }
        if (cb) cb(er)
      })
    }})(fs.rename)
  }

  // if read() returns EAGAIN, then just try it again.
  fs.read = (function (fs$read) { return function (fd, buffer, offset, length, position, callback_) {
    var callback
    if (callback_ && typeof callback_ === 'function') {
      var eagCounter = 0
      callback = function (er, _, __) {
        if (er && er.code === 'EAGAIN' && eagCounter < 10) {
          eagCounter ++
          return fs$read.call(fs, fd, buffer, offset, length, position, callback)
        }
        callback_.apply(this, arguments)
      }
    }
    return fs$read.call(fs, fd, buffer, offset, length, position, callback)
  }})(fs.read)

  fs.readSync = (function (fs$readSync) { return function (fd, buffer, offset, length, position) {
    var eagCounter = 0
    while (true) {
      try {
        return fs$readSync.call(fs, fd, buffer, offset, length, position)
      } catch (er) {
        if (er.code === 'EAGAIN' && eagCounter < 10) {
          eagCounter ++
          continue
        }
        throw er
      }
    }
  }})(fs.readSync)
}

function patchLchmod (fs) {
  fs.lchmod = function (path, mode, callback) {
    fs.open( path
           , constants.O_WRONLY | constants.O_SYMLINK
           , mode
           , function (err, fd) {
      if (err) {
        if (callback) callback(err)
        return
      }
      // prefer to return the chmod error, if one occurs,
      // but still try to close, and report closing errors if they occur.
      fs.fchmod(fd, mode, function (err) {
        fs.close(fd, function(err2) {
          if (callback) callback(err || err2)
        })
      })
    })
  }

  fs.lchmodSync = function (path, mode) {
    var fd = fs.openSync(path, constants.O_WRONLY | constants.O_SYMLINK, mode)

    // prefer to return the chmod error, if one occurs,
    // but still try to close, and report closing errors if they occur.
    var threw = true
    var ret
    try {
      ret = fs.fchmodSync(fd, mode)
      threw = false
    } finally {
      if (threw) {
        try {
          fs.closeSync(fd)
        } catch (er) {}
      } else {
        fs.closeSync(fd)
      }
    }
    return ret
  }
}

function patchLutimes (fs) {
  if (constants.hasOwnProperty("O_SYMLINK")) {
    fs.lutimes = function (path, at, mt, cb) {
      fs.open(path, constants.O_SYMLINK, function (er, fd) {
        if (er) {
          if (cb) cb(er)
          return
        }
        fs.futimes(fd, at, mt, function (er) {
          fs.close(fd, function (er2) {
            if (cb) cb(er || er2)
          })
        })
      })
    }

    fs.lutimesSync = function (path, at, mt) {
      var fd = fs.openSync(path, constants.O_SYMLINK)
      var ret
      var threw = true
      try {
        ret = fs.futimesSync(fd, at, mt)
        threw = false
      } finally {
        if (threw) {
          try {
            fs.closeSync(fd)
          } catch (er) {}
        } else {
          fs.closeSync(fd)
        }
      }
      return ret
    }

  } else {
    fs.lutimes = function (_a, _b, _c, cb) { if (cb) process.nextTick(cb) }
    fs.lutimesSync = function () {}
  }
}

function chmodFix (orig) {
  if (!orig) return orig
  return function (target, mode, cb) {
    return orig.call(fs, target, mode, function (er) {
      if (chownErOk(er)) er = null
      if (cb) cb.apply(this, arguments)
    })
  }
}

function chmodFixSync (orig) {
  if (!orig) return orig
  return function (target, mode) {
    try {
      return orig.call(fs, target, mode)
    } catch (er) {
      if (!chownErOk(er)) throw er
    }
  }
}


function chownFix (orig) {
  if (!orig) return orig
  return function (target, uid, gid, cb) {
    return orig.call(fs, target, uid, gid, function (er) {
      if (chownErOk(er)) er = null
      if (cb) cb.apply(this, arguments)
    })
  }
}

function chownFixSync (orig) {
  if (!orig) return orig
  return function (target, uid, gid) {
    try {
      return orig.call(fs, target, uid, gid)
    } catch (er) {
      if (!chownErOk(er)) throw er
    }
  }
}


function statFix (orig) {
  if (!orig) return orig
  // Older versions of Node erroneously returned signed integers for
  // uid + gid.
  return function (target, cb) {
    return orig.call(fs, target, function (er, stats) {
      if (!stats) return cb.apply(this, arguments)
      if (stats.uid < 0) stats.uid += 0x100000000
      if (stats.gid < 0) stats.gid += 0x100000000
      if (cb) cb.apply(this, arguments)
    })
  }
}

function statFixSync (orig) {
  if (!orig) return orig
  // Older versions of Node erroneously returned signed integers for
  // uid + gid.
  return function (target) {
    var stats = orig.call(fs, target)
    if (stats.uid < 0) stats.uid += 0x100000000
    if (stats.gid < 0) stats.gid += 0x100000000
    return stats;
  }
}

// ENOSYS means that the fs doesn't support the op. Just ignore
// that, because it doesn't matter.
//
// if there's no getuid, or if getuid() is something other
// than 0, and the error is EINVAL or EPERM, then just ignore
// it.
//
// This specific case is a silent failure in cp, install, tar,
// and most other unix tools that manage permissions.
//
// When running as root, or if other types of errors are
// encountered, then it's strict.
function chownErOk (er) {
  if (!er)
    return true

  if (er.code === "ENOSYS")
    return true

  var nonroot = !process.getuid || process.getuid() !== 0
  if (nonroot) {
    if (er.code === "EINVAL" || er.code === "EPERM")
      return true
  }

  return false
}


/***/ }),
/* 154 */
/***/ (function(module, exports) {

module.exports = require("constants");

/***/ }),
/* 155 */
/***/ (function(module, exports, __webpack_require__) {

var Stream = __webpack_require__(156).Stream

module.exports = legacy

function legacy (fs) {
  return {
    ReadStream: ReadStream,
    WriteStream: WriteStream
  }

  function ReadStream (path, options) {
    if (!(this instanceof ReadStream)) return new ReadStream(path, options);

    Stream.call(this);

    var self = this;

    this.path = path;
    this.fd = null;
    this.readable = true;
    this.paused = false;

    this.flags = 'r';
    this.mode = 438; /*=0666*/
    this.bufferSize = 64 * 1024;

    options = options || {};

    // Mixin options into this
    var keys = Object.keys(options);
    for (var index = 0, length = keys.length; index < length; index++) {
      var key = keys[index];
      this[key] = options[key];
    }

    if (this.encoding) this.setEncoding(this.encoding);

    if (this.start !== undefined) {
      if ('number' !== typeof this.start) {
        throw TypeError('start must be a Number');
      }
      if (this.end === undefined) {
        this.end = Infinity;
      } else if ('number' !== typeof this.end) {
        throw TypeError('end must be a Number');
      }

      if (this.start > this.end) {
        throw new Error('start must be <= end');
      }

      this.pos = this.start;
    }

    if (this.fd !== null) {
      process.nextTick(function() {
        self._read();
      });
      return;
    }

    fs.open(this.path, this.flags, this.mode, function (err, fd) {
      if (err) {
        self.emit('error', err);
        self.readable = false;
        return;
      }

      self.fd = fd;
      self.emit('open', fd);
      self._read();
    })
  }

  function WriteStream (path, options) {
    if (!(this instanceof WriteStream)) return new WriteStream(path, options);

    Stream.call(this);

    this.path = path;
    this.fd = null;
    this.writable = true;

    this.flags = 'w';
    this.encoding = 'binary';
    this.mode = 438; /*=0666*/
    this.bytesWritten = 0;

    options = options || {};

    // Mixin options into this
    var keys = Object.keys(options);
    for (var index = 0, length = keys.length; index < length; index++) {
      var key = keys[index];
      this[key] = options[key];
    }

    if (this.start !== undefined) {
      if ('number' !== typeof this.start) {
        throw TypeError('start must be a Number');
      }
      if (this.start < 0) {
        throw new Error('start must be >= zero');
      }

      this.pos = this.start;
    }

    this.busy = false;
    this._queue = [];

    if (this.fd === null) {
      this._open = fs.open;
      this._queue.push([this._open, this.path, this.flags, this.mode, undefined]);
      this.flush();
    }
  }
}


/***/ }),
/* 156 */
/***/ (function(module, exports) {

module.exports = require("stream");

/***/ }),
/* 157 */
/***/ (function(module, exports) {

module.exports = require("util");

/***/ }),
/* 158 */
/***/ (function(module, exports) {

/**
 * A module that contains key path helpers. Adapted from atom/key-path-helpers.
 *
 * @module settings-helpers
 * @author Nathan Buchar
 * @copyright 2016-2017 Nathan Buchar <hello@nathanbuchar.com>
 * @license ISC
 */

/**
 * Checks if the given object contains the given key path.
 *
 * @param {Object} obj
 * @param {string} keyPath
 * @returns {boolean}
 */
module.exports.hasKeyPath = (obj, keyPath) => {
  const keys = keyPath.split(/\./);

  for (let i = 0, len = keys.length; i < len; i++) {
    const key = keys[i];

    if (Object.prototype.hasOwnProperty.call(obj, key)) {
      obj = obj[key];
    } else {
      return false;
    }
  }

  return true;
};

/**
 * Gets the value of the given object at the given key path.
 *
 * @param {Object} obj
 * @param {string} keyPath
 * @returns {any}
 */
module.exports.getValueAtKeyPath = (obj, keyPath) => {
  const keys = keyPath.split(/\./);

  for (let i = 0, len = keys.length; i < len; i++) {
    const key = keys[i];

    if (Object.prototype.hasOwnProperty.call(obj, key)) {
      obj = obj[key];
    } else {
      return undefined;
    }
  }

  return obj;
};

/**
 * Sets the value of the given object at the given key path.
 *
 * @param {Object} obj
 * @param {string} keyPath
 * @param {any} value
 */
module.exports.setValueAtKeyPath = (obj, keyPath, value) => {
  const keys = keyPath.split(/\./);

  while (keys.length > 1) {
    const key = keys.shift();

    if (!Object.prototype.hasOwnProperty.call(obj, key)) {
      obj[key] = {};
    }

    obj = obj[key];
  }

  obj[keys.shift()] = value;
};

/**
 * Deletes the value of the given object at the given key path.
 *
 * @param {Object} obj
 * @param {string} keyPath
 */
module.exports.deleteValueAtKeyPath = (obj, keyPath) => {
  const keys = keyPath.split(/\./);

  while (keys.length > 1) {
    const key = keys.shift();

    if (!Object.prototype.hasOwnProperty.call(obj, key)) {
      return;
    }

    obj = obj[key];
  }

  delete obj[keys.shift()];
};


/***/ }),
/* 159 */
/***/ (function(module, exports, __webpack_require__) {

/**
 * A module that delegates settings changes.
 *
 * @module settings-observer
 * @author Nathan Buchar
 * @copyright 2016-2017 Nathan Buchar <hello@nathanbuchar.com>
 * @license ISC
 */

const assert = __webpack_require__(57);

class SettingsObserver {

  constructor(settings, keyPath, handler, currentValue) {

    /**
     * A reference to the Settings instance.
     *
     * @type {Settings}
     * @private
     */
    this._settings = settings;

    /**
     * The key path that this observer instance is watching for changes.
     *
     * @type {string}
     * @private
     */
    this._keyPath = keyPath;

    /**
     * The handler function to be called when the value at the observed
     * key path is changed.
     *
     * @type {Function}
     * @private
     */
    this._handler = handler;

    /**
     * The current value of the setting at the given key path.
     *
     * @type {any}
     * @private
     */
    this._currentValue = currentValue;

    /**
     * Called when the settings file is changed.
     *
     * @type {Object}
     * @private
     */
    this._handleChange = this._onChange.bind(this);

    this._init();
  }

  /**
   * Initializes this instance.
   *
   * @private
   */
  _init() {
    this._settings.on('change', this._handleChange);
  }

  /**
   * Called when the settings file is changed.
   *
   * @private
   */
  _onChange() {
    const oldValue = this._currentValue;
    const newValue = this._settings.get(this._keyPath);

    try {
      assert.deepEqual(newValue, oldValue);
    } catch (err) {
      this._currentValue = newValue;

      // Call the watch handler and pass in the new and old values.
      this._handler.call(this, newValue, oldValue);
    }
  }

  /**
   * Disposes of this key path observer.
   *
   * @public
   */
  dispose() {
    this._settings.removeListener('change', this._handleChange);
  }
}

module.exports = SettingsObserver;


/***/ }),
/* 160 */
/***/ (function(module, exports) {

module.exports = require("url");

/***/ })
/******/ ]);