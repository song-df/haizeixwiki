/*************************************************************************
	> File Name: main.c
	> Author: hug
	> Mail: hug@haizeix.com
	> Created Time: 六  1/27 16:38:22 2024
 ************************************************************************/

#include <stdio.h>
#include <database.h>

int main() {
    run_database();
    return 0;
}
