/*************************************************************************
	> File Name: 11.XYOJ-9307.cpp
	> Author: hug
	> Mail: hug@haizeix.com
	> Created Time: 一  6/17 12:59:04 2024
 ************************************************************************/

#include <iostream>
using namespace std;

int main() {
    int m;
    cin >> m;
    if (m % 2) cout << "mg wins" << endl;
    else cout << "sMg wins" << endl;
    return 0;
}
