/*************************************************************************
	> File Name: 11.XYOJ-3567.cpp
	> Author: hug
	> Mail: hug@haizeix.com
	> Created Time: 日  6/16 14:46:40 2024
 ************************************************************************/

#include <iostream>
using namespace std;

int main() {
    double x;
    cin >> x;
    printf("%.3lf\n", x);
    return 0;
}
