/*************************************************************************
	> File Name: 4.XYOJ-8146.cpp
	> Author: hug
	> Mail: hug@haizeix.com
	> Created Time: 日  6/16 13:41:37 2024
 ************************************************************************/

#include <iostream>
using namespace std;

int main() {
    int a, b, c;
    cin >> a >> b >> c;
    cout << a * 0.2 + b * 0.3 + c * 0.5 << endl; 
    return 0;
}
