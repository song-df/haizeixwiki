/*************************************************************************
	> File Name: 5.XYOJ-9201.cpp
	> Author: hug
	> Mail: hug@haizeix.com
	> Created Time: 日  6/16 13:43:33 2024
 ************************************************************************/

#include <iostream>
using namespace std;

int main() {
    int a, h;
    cin >> a >> h;
    cout << a * h / 2 << endl;
    return 0;
}
