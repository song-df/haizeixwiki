/*************************************************************************
	> File Name: 14.XYOJ-9217.cpp
	> Author: hug
	> Mail: hug@haizeix.com
	> Created Time: 日  6/16 15:34:41 2024
 ************************************************************************/

#include <iostream>
using namespace std;

int main() {
    int a, B;
    cin >> a >> B;
    int x = B / a;
    int y = x / 3;
    cout << x + y << endl;
    return 0;
}
