/*************************************************************************
	> File Name: 16.XYOJ-3902.cpp
	> Author: hug
	> Mail: hug@haizeix.com
	> Created Time: 日  6/16 15:48:46 2024
 ************************************************************************/

#include <iostream>
using namespace std;

int main() {
    int n;
    cin >> n;
    double s = 1.0 * n / (n + 1);
    printf("%.2lf\n", s);
    return 0;
}
