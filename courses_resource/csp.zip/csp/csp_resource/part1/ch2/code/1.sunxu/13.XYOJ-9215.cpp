/*************************************************************************
	> File Name: 13.XYOJ-9215.cpp
	> Author: hug
	> Mail: hug@haizeix.com
	> Created Time: 日  6/16 14:56:24 2024
 ************************************************************************/

#include <iostream>
using namespace std;

int main() {
    int w;
    cin >> w;
    cout << (w / 2) * (w / 2) << endl;
    return 0;
}
