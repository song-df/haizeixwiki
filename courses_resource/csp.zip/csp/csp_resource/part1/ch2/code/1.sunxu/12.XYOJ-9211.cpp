/*************************************************************************
	> File Name: 12.XYOJ-9211.cpp
	> Author: hug
	> Mail: hug@haizeix.com
	> Created Time: 日  6/16 14:48:29 2024
 ************************************************************************/

#include <iostream>
#include <cmath>
using namespace std;

int main() {
    int a, b, c;
    cin >> a >> b;
    c = sqrt(a * a + b * b);
    cout << c << endl;
    return 0;
}
